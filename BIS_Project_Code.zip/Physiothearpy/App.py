from flask import Flask, jsonify, render_template, request, session, send_from_directory
from datetime import datetime, timedelta
from flask_migrate import Migrate
from models import clinic_db , Practitioner  , Patient , PractitionerRole , Appointment , UserAction  , DocumentReference, MedicalRecord
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from sqlalchemy import func
import json
import os
from werkzeug.utils import secure_filename
from flask_cors import CORS

app = Flask(__name__ , template_folder='Templates', static_folder='CSS_Java')
app.secret_key = 'mypro'
CORS(app)

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:ahmed5medo4/8@localhost/clinic_db?charset=utf8mb4'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
clinic_db.init_app(app) 

migrate = Migrate(app, clinic_db)

# Create tables when the application starts
with app.app_context():
    try:
        clinic_db.create_all()
        print("Database tables created successfully!")
    except Exception as e:
        print(f"Error creating tables: {str(e)}")

# Configure upload folder
UPLOAD_FOLDER = 'uploads/medical_images'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'dicom'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Create upload folder if it doesn't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Authentication decorator - checks if user is logged in
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Authentication required'}), 401
        return f(*args, **kwargs)
    return decorated_function

# Authentication endpoints
@app.route('/login')
def login_page():
    return render_template('login.html')

@app.route('/api/login', methods=['POST'])
def login():
    try:
        # Get the login data from the request
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')
        
        print(f"Login attempt for email: {email}")  # Debug log
        
        # Query the practitioner by email
        practitioner = Practitioner.query.filter_by(email=email).first()
        
        # Check if the practitioner exists and the password is correct
        if practitioner and check_password_hash(practitioner.password, password):
            # Get the practitioner's role
            role = PractitionerRole.query.filter_by(practitioner_id=practitioner.id, active=True).first()
            
            # Set session data
            session['user_id'] = practitioner.id
            session['user_name'] = practitioner.name
            session['user_email'] = practitioner.email
            session['user_role'] = role.role_code if role else 'doctor'
            
            print(f"Session data set: {session}")  # Debug log
            
            # Log the login action
            action = UserAction(
                user_id=practitioner.id,
                action_type='login',
                resource_type='Practitioner',
                resource_id=str(practitioner.id),
                description=f"User logged in"
            )
            clinic_db.session.add(action)
            clinic_db.session.commit()
            
            return jsonify({
                'message': 'Login successful',
                'user': {
                    'id': practitioner.id,
                    'name': practitioner.name,
                    'email': practitioner.email,
                    'role': role.role_code if role else 'doctor'
                }
            })
        
        print(f"Login failed for email: {email}")  # Debug log
        return jsonify({'error': 'Invalid credentials'}), 401
        
    except Exception as e:
        print(f"Login error: {str(e)}")  # Debug log
        return jsonify({'error': f'Login error: {str(e)}'}), 500

#logout endpoint
@app.route('/api/logout', methods=['POST'])
@login_required
def logout():
    session.clear()
    return jsonify({'message': 'Logged out successfully'})

#signup endpoint
@app.route('/api/signup', methods=['POST'])
def signup():
    try:
        data = request.get_json()
        print("Received signup data:", data)  # Debug log
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Validate required fields
        required_fields = ['name', 'email', 'password']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Missing required field: {field}'}), 400
        
        # Check if user exists
        existing_user = Practitioner.query.filter_by(email=data['email']).first()
        if existing_user:
            return jsonify({'error': 'Email already registered'}), 400
        
        try:
            # Create new practitioner
            new_practitioner = Practitioner(
                name=data['name'],
                email=data['email'],
                password=generate_password_hash(data['password']),
                contact_number=data.get('contact_number')
            )
            clinic_db.session.add(new_practitioner)
            clinic_db.session.commit()
            print(f"Created new practitioner with ID: {new_practitioner.id}")  # Debug log
            
            # Create role
            new_role = PractitionerRole(
                practitioner_id=new_practitioner.id,
                role_code=data.get('role_code', 'doctor'),
                active=True,
                start_date=datetime.utcnow()
            )
            clinic_db.session.add(new_role)
            
            # Log action
            action = UserAction(
                user_id=new_practitioner.id,
                action_type='create',
                resource_type='Practitioner',
                resource_id=str(new_practitioner.id),
                description=f"Registered new practitioner"
            )
            clinic_db.session.add(action)
            clinic_db.session.commit()
            print("Successfully created role and logged action")  # Debug log
            
            return jsonify({
                'message': 'Registration successful',
                'user_id': new_practitioner.id
            }), 201
            
        except Exception as db_error:
            print(f"Database error: {str(db_error)}")  # Debug log
            clinic_db.session.rollback()
            return jsonify({'error': f'Database error: {str(db_error)}'}), 500
        
    except Exception as e:
        print(f"Error during signup: {str(e)}")  # Debug log
        print(f"Error type: {type(e)}")  # Debug log
        print(f"Error details: {e.__dict__}")  # Debug log
        clinic_db.session.rollback()
        return jsonify({'error': f'An error occurred during registration: {str(e)}'}), 500

# Patient endpoints
@app.route('/api/patients', methods=['GET'])
@login_required
def get_patients():
    # Get all patients from the database
    patients = Patient.query.all()
    return jsonify([{
        'id': p.id,
        'name': p.name,
        'gender': p.gender.value if p.gender else None,
        'birthDate': p.birthDate.isoformat() if p.birthDate else None,
        'phone': p.phone,
        'email': p.email,
        'address': p.address,
        'occupation': p.occupation
    } for p in patients])

#get patient by id endpoint
@app.route('/api/patients/<int:patient_id>', methods=['GET'])
@login_required
def get_patient(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    return jsonify({
        'id': patient.id,
        'name': patient.name,
        'gender': patient.gender.value if patient.gender else None,
        'birthDate': patient.birthDate.isoformat() if patient.birthDate else None,
        'phone': patient.phone,
        'email': patient.email,
        'address': patient.address,
        'occupation': patient.occupation
    })

#create patient endpoint
@app.route('/api/patients', methods=['POST'])
@login_required
def create_patient():
    data = request.get_json()
    new_patient = Patient(
        # identifier = data.get(''),
        name=data['name'],
        gender=data.get('gender'),
        birthDate=datetime.strptime(data['birthDate'], '%Y-%m-%d').date() if data.get('birthDate') else None,
        phone=data.get('phone'),
        email=data.get('email'),
        address=data.get('address'),
        occupation=data.get('occupation')
    )
    clinic_db.session.add(new_patient)
    
    # Log action
    action = UserAction(
        user_id=session['user_id'],
        action_type='create',
        resource_type='Patient',
        resource_id=str(new_patient.id),
        description=f"Created new patient: {new_patient.name}"
    )
    clinic_db.session.add(action)
    clinic_db.session.commit()
    
    return jsonify({'message': 'Patient created successfully', 'id': new_patient.id}), 201

#update patient endpoint
@app.route('/api/patients/<int:patient_id>', methods=['PUT'])
@login_required
def update_patient(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    data = request.get_json()
    
    # Update patient fields
    if 'name' in data:
        patient.name = data['name']
    if 'gender' in data:
        patient.gender = data['gender']
    if 'birthDate' in data:
        patient.birthDate = datetime.strptime(data['birthDate'], '%Y-%m-%d').date()
    if 'phone' in data:
        patient.phone = data['phone']
    if 'email' in data:
        patient.email = data['email']
    if 'address' in data:
        patient.address = data['address']
    if 'occupation' in data:
        patient.occupation = data['occupation']
    
    # Log action
    action = UserAction(
        user_id=session['user_id'],
        action_type='update',
        resource_type='Patient',
        resource_id=str(patient_id),
        description=f"Updated patient: {patient.name}"
    )
    clinic_db.session.add(action)
    clinic_db.session.commit()
    
    return jsonify({'message': 'Patient updated successfully'})

# Appointment endpoints
@app.route('/api/appointments', methods=['GET'])
@login_required
def get_appointments():
    # Get all appointments from the database
    appointments = Appointment.query.all()
    return jsonify([{
        'id': a.id,
        'status': a.status.value,
        'start': a.start.isoformat(),
        'end': a.end.isoformat(),
        'reason': a.reason,
        'patient_id': a.patient_id,
        'practitioner_id': a.practitioner_id
    } for a in appointments])

@app.route('/api/appointments/date/<date>', methods=['GET'])
@login_required
def get_appointments_by_date(date):
    # Convert date string to datetime
    try:
        target_date = datetime.strptime(date, '%Y-%m-%d').date()
    except ValueError:
        return jsonify({'error': 'Invalid date format'}), 400

    # Get appointments for the specified date
    appointments = Appointment.query.filter(
        func.date(Appointment.created) == target_date
    ).all()

    return jsonify([{
        'id': a.id,
        'status': a.status.value,
        'start': a.start.isoformat(),
        'end': a.end.isoformat(),
        'reason': a.reason,
        'patient_id': a.patient_id,
        'practitioner_id': a.practitioner_id,
        'patient_name': a.patient.name if a.patient else 'Unknown'
    } for a in appointments])

#get appointment by id endpoint
@app.route('/api/appointments/<int:appointment_id>', methods=['GET'])
@login_required
def get_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    return jsonify({
        'id': appointment.id,
        'status': appointment.status.value,
        'start': appointment.start.isoformat(),
        'end': appointment.end.isoformat(),
        'reason': appointment.reason,
        'patient_id': appointment.patient_id,
        'practitioner_id': appointment.practitioner_id
    })

#create appointment endpoint
@app.route('/api/appointments', methods=['POST'])
@login_required
def create_appointment():
    data = request.get_json()
    
    new_appointment = Appointment(
        status=data.get('status', 'booked'),
        start=datetime.strptime(data['start'], '%H:%M').time(),
        end=datetime.strptime(data['end'], '%H:%M').time(),
        reason=data.get('reason'),
        patient_id=data['patient_id'],
        practitioner_id=data['practitioner_id']
    )
    
    clinic_db.session.add(new_appointment)
    
    # Log actio n
    action = UserAction(
        user_id=session['user_id'],
        action_type='create',
        resource_type='Appointment',
        resource_id=str(new_appointment.id),
        description=f"Created new appointment for patient {new_appointment.patient_id}"
    )
    clinic_db.session.add(action)
    clinic_db.session.commit()
    
    return jsonify({'message': 'Appointment created successfully', 'id': new_appointment.id}), 201

@app.route('/api/appointments/<int:appointment_id>', methods=['PUT'])
@login_required
def update_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    data = request.get_json()
    
    # Update appointment fields
    if 'status' in data:
        appointment.status = data['status']
    if 'start' in data:
        appointment.start = datetime.strptime(data['start'], '%H:%M').time()
    if 'end' in data:
        appointment.end = datetime.strptime(data['end'], '%H:%M').time()
    if 'reason' in data:
        appointment.reason = data['reason']
    if 'patient_id' in data:
        appointment.patient_id = data['patient_id']
    if 'practitioner_id' in data:
        appointment.practitioner_id = data['practitioner_id']
    
    # Log action
    action = UserAction(
        user_id=session['user_id'],
        action_type='update',
        resource_type='Appointment',
        resource_id=str(appointment_id),
        description=f"Updated appointment {appointment_id}"
    )
    clinic_db.session.add(action)
    clinic_db.session.commit()
    
    return jsonify({'message': 'Appointment updated successfully'})

@app.route('/api/appointments/<int:appointment_id>', methods=['DELETE'])
@login_required
def delete_appointment(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    
    # Log action before deletion
    action = UserAction(
        user_id=session['user_id'],
        action_type='delete',
        resource_type='Appointment',
        resource_id=str(appointment_id),
        description=f"Deleted appointment {appointment_id}"
    )
    clinic_db.session.add(action)
    
    clinic_db.session.delete(appointment)
    clinic_db.session.commit()
    
    return jsonify({'message': 'Appointment deleted successfully'})

# Statistics endpoint
@app.route('/api/statistics/active-patients', methods=['GET'])
@login_required
def get_active_patients():
    # Count patients with appointments in the last 30 days
    thirty_days_ago = datetime.utcnow() - timedelta(days=30)
    active_patients = clinic_db.session.query(func.count(distinct(Appointment.patient_id)))\
        .filter(Appointment.created >= thirty_days_ago)\
        .scalar()
    
    return jsonify({
        'active_patients': active_patients,
        'period': 'last 30 days'
    })

@app.route('/')
def index():
    return render_template('sign up page.html')

# @app.route('/Login')
# def Login():
#     return render_template('login.html')

@app.route('/sign')
def SignUP():
    return render_template('sign up page.html')

@app.route('/patients')
def patients_Info():
    return render_template('Patients.html')

@app.route('/add_patient')
def add_patient():
    return render_template('AdPatient.html')

@app.route('/Patient_Dashboard')
def Patient_Dash():
    return render_template('Patient_Dash.html')

@app.route('/Schedule')
def Schedule():
    return render_template('Schedule_Dash.html')

@app.route('/Appointment')
def add_appointment_page():
    return render_template('addappointment.html')

@app.route('/view_data')
@login_required
def view_data():
    # Get all practitioners with their roles
    practitioners = []
    for p in Practitioner.query.all():
        role = PractitionerRole.query.filter_by(practitioner_id=p.id, active=True).first()
        practitioners.append({
            'id': p.id,
            'name': p.name,
            'email': p.email,
            'contact_number': p.contact_number,
            'role': role.role_code if role else 'doctor'
        })
    
    # Get all patients
    patients = Patient.query.all()
    
    # Get all appointments
    appointments = Appointment.query.all()
    
    return render_template('view_data.html',
                         practitioners=practitioners,
                         patients=patients,
                         appointments=appointments)

@app.route('/General_Dash')
@login_required
def General_Dash():
    return render_template('General_Dash.html', user_name=session.get('user_name', 'Doctor'))

@app.route('/medical-records')
@login_required
def medical_records():
    return render_template('MedicalRecord.html')

# Practitioner endpoints
@app.route('/api/practitioners', methods=['GET'])
@login_required
def get_practitioners():
    # Get all practitioners with their roles
    practitioners = []
    for p in Practitioner.query.all():
        role = PractitionerRole.query.filter_by(practitioner_id=p.id, active=True).first()
        practitioners.append({
            'id': p.id,
            'name': p.name,
            'email': p.email,
            'contact_number': p.contact_number,
            'role': role.role_code if role else 'doctor'
        })
    return jsonify(practitioners)

@app.route('/api/patients/<int:patient_id>/documents', methods=['GET'])
@login_required
def get_patient_documents(patient_id):
    # Get all document references for the patient
    documents = DocumentReference.query.filter_by(patient_id=patient_id).all()
    return jsonify([{
        'id': doc.id,
        'type': doc.type,
        'content': doc.content,
        'description': doc.description,
        'date': doc.date.isoformat(),
        'content_type': doc.content_type
    } for doc in documents])

@app.route('/api/patients/<int:patient_id>/details', methods=['GET'])
@login_required
def get_patient_details(patient_id):
    try:
        patient = Patient.query.get_or_404(patient_id)
        
        # Get the primary provider (doctor) from the most recent appointment
        latest_appointment = Appointment.query.filter_by(patient_id=patient_id)\
            .order_by(Appointment.created.desc())\
            .first()
        
        primary_provider = None
        if latest_appointment and latest_appointment.practitioner:
            primary_provider = latest_appointment.practitioner.name

        # Get the last and next visit
        last_visit = None
        next_visit = None
        
        if latest_appointment:
            last_visit = latest_appointment.start.isoformat()
            next_visit = latest_appointment.end.isoformat()

        # Get visit history
        appointments = Appointment.query.filter_by(patient_id=patient_id)\
            .order_by(Appointment.created.desc())\
            .all()
        
        visit_history = [{
            'id': apt.id,
            'date': apt.created.isoformat(),
            'practitioner_id': apt.practitioner_id,
            'status': apt.status.value,
            'reason': apt.reason
        } for apt in appointments]

        # Get documents (medication and diagnosis)
        documents = DocumentReference.query.filter_by(patient_id=patient_id).all()
        medication = next((doc for doc in documents if doc.type == 'Medication'), None)
        diagnosis = next((doc for doc in documents if doc.type == 'Diagnosis'), None)

        return jsonify({
            'id': patient.id,
            'name': patient.name,
            'gender': patient.gender.value if patient.gender else None,
            'birthDate': patient.birthDate.isoformat() if patient.birthDate else None,
            'phone': patient.phone,
            'email': patient.email,
            'address': patient.address,
            'occupation': patient.occupation,
            'primaryProvider': primary_provider,
            'lastVisit': last_visit,
            'nextVisit': next_visit,
            'visitHistory': visit_history,
            'medication': {
                'content': medication.content if medication else None,
                'date': medication.date.isoformat() if medication else None
            } if medication else None,
            'diagnosis': {
                'content': diagnosis.content if diagnosis else None,
                'date': diagnosis.date.isoformat() if diagnosis else None
            } if diagnosis else None
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/patients/<int:patient_id>/attachments', methods=['GET'])
@login_required
def get_patient_attachments(patient_id):
    # Get all document references for the patient
    documents = DocumentReference.query.filter_by(patient_id=patient_id).all()
    return jsonify([{
        'id': doc.id,
        'type': doc.type,
        'description': doc.description,
        'date': doc.date.isoformat(),
        'content_type': doc.content_type
    } for doc in documents])

@app.route('/api/patients/<int:patient_id>/attachments', methods=['POST'])
@login_required
def add_patient_attachment(patient_id):
    try:
        data = request.get_json()
        
        new_document = DocumentReference(
            type=data.get('type', 'Attachment'),
            content_type=data.get('content_type', 'text/plain'),
            content=data.get('content', ''),
            description=data.get('description', ''),
            patient_id=patient_id
        )
        
        clinic_db.session.add(new_document)
        
        # Log action
        action = UserAction(
            user_id=session['user_id'],
            action_type='create',
            resource_type='DocumentReference',
            resource_id=str(new_document.id),
            description=f"Added attachment for patient {patient_id}"
        )
        clinic_db.session.add(action)
        clinic_db.session.commit()
        
        return jsonify({
            'message': 'Attachment added successfully',
            'id': new_document.id
        }), 201
        
    except Exception as e:
        clinic_db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/patient-medical-record.html')
@login_required
def patient_medical_record():
    return render_template('patient-medical-record.html')

# Medical Record endpoints
@app.route('/api/patients/<int:patient_id>/medical-records', methods=['GET'])
@login_required
def get_patient_medical_records(patient_id):
    try:
        records = MedicalRecord.query.filter_by(patient_id=patient_id)\
            .order_by(MedicalRecord.created_at.desc())\
            .all()
        
        return jsonify([{
            'id': record.id,
            'created_at': record.created_at.isoformat(),
            'updated_at': record.updated_at.isoformat(),
            'practitioner_id': record.practitioner_id,
            'subjective': {
                'patient_report': record.patient_report,
                'primary_concern': record.primary_concern,
                'condition_history': record.condition_history,
                'diagnosis_date': record.diagnosis_date.isoformat() if record.diagnosis_date else None,
                'injury_date': record.injury_date.isoformat() if record.injury_date else None,
                'care_start_date': record.care_start_date.isoformat() if record.care_start_date else None,
                'surgery_related': record.surgery_related
            },
            'objective': {
                'medical_images': json.loads(record.medical_images) if record.medical_images else [],
                'image_description': record.image_description,
                'annotations': json.loads(record.annotations) if record.annotations else []
            },
            'treatment': {
                'approach': record.treatment_approach,
                'frequency': record.treatment_frequency,
                'duration': record.treatment_duration,
                'planned_procedures': record.planned_procedures,
                'additional_comments': record.additional_comments
            }
        } for record in records])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/patients/<int:patient_id>/medical-records', methods=['POST'])
@login_required
def create_medical_record(patient_id):
    try:
        data = request.get_json()
        
        new_record = MedicalRecord(
            patient_id=patient_id,
            practitioner_id=session['user_id'],
            # Subjective Data
            patient_report=data.get('subjective', {}).get('patient_report'),
            primary_concern=data.get('subjective', {}).get('primary_concern'),
            condition_history=data.get('subjective', {}).get('condition_history'),
            diagnosis_date=datetime.strptime(data['subjective']['diagnosis_date'], '%Y-%m-%d').date() if data.get('subjective', {}).get('diagnosis_date') else None,
            injury_date=datetime.strptime(data['subjective']['injury_date'], '%Y-%m-%d').date() if data.get('subjective', {}).get('injury_date') else None,
            care_start_date=datetime.strptime(data['subjective']['care_start_date'], '%Y-%m-%d').date() if data.get('subjective', {}).get('care_start_date') else None,
            surgery_related=data.get('subjective', {}).get('surgery_related'),
            # Objective Data
            medical_images=json.dumps(data.get('objective', {}).get('medical_images', [])),
            image_description=data.get('objective', {}).get('image_description'),
            annotations=json.dumps(data.get('objective', {}).get('annotations', [])),
            # Treatment Data
            treatment_approach=data.get('treatment', {}).get('approach'),
            treatment_frequency=data.get('treatment', {}).get('frequency'),
            treatment_duration=data.get('treatment', {}).get('duration'),
            planned_procedures=data.get('treatment', {}).get('planned_procedures'),
            additional_comments=data.get('treatment', {}).get('additional_comments')
        )
        
        clinic_db.session.add(new_record)
        
        # Log action
        action = UserAction(
            user_id=session['user_id'],
            action_type='create',
            resource_type='MedicalRecord',
            resource_id=str(new_record.id),
            description=f"Created medical record for patient {patient_id}"
        )
        clinic_db.session.add(action)
        clinic_db.session.commit()
        
        return jsonify({
            'message': 'Medical record created successfully',
            'id': new_record.id
        }), 201
        
    except Exception as e:
        clinic_db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/api/medical-records/<int:record_id>', methods=['PUT'])
@login_required
def update_medical_record(record_id):
    try:
        record = MedicalRecord.query.get_or_404(record_id)
        data = request.get_json()
        
        # Update fields if provided
        if 'subjective' in data:
            subjective = data['subjective']
            record.patient_report = subjective.get('patient_report', record.patient_report)
            record.primary_concern = subjective.get('primary_concern', record.primary_concern)
            record.condition_history = subjective.get('condition_history', record.condition_history)
            if 'diagnosis_date' in subjective:
                record.diagnosis_date = datetime.strptime(subjective['diagnosis_date'], '%Y-%m-%d').date()
            if 'injury_date' in subjective:
                record.injury_date = datetime.strptime(subjective['injury_date'], '%Y-%m-%d').date()
            if 'care_start_date' in subjective:
                record.care_start_date = datetime.strptime(subjective['care_start_date'], '%Y-%m-%d').date()
            record.surgery_related = subjective.get('surgery_related', record.surgery_related)
        
        if 'objective' in data:
            objective = data['objective']
            record.medical_images = json.dumps(objective.get('medical_images', json.loads(record.medical_images or '[]')))
            record.image_description = objective.get('image_description', record.image_description)
            record.annotations = json.dumps(objective.get('annotations', json.loads(record.annotations or '[]')))
        
        if 'treatment' in data:
            treatment = data['treatment']
            record.treatment_approach = treatment.get('approach', record.treatment_approach)
            record.treatment_frequency = treatment.get('frequency', record.treatment_frequency)
            record.treatment_duration = treatment.get('duration', record.treatment_duration)
            record.planned_procedures = treatment.get('planned_procedures', record.planned_procedures)
            record.additional_comments = treatment.get('additional_comments', record.additional_comments)
        
        # Log action
        action = UserAction(
            user_id=session['user_id'],
            action_type='update',
            resource_type='MedicalRecord',
            resource_id=str(record_id),
            description=f"Updated medical record {record_id}"
        )
        clinic_db.session.add(action)
        clinic_db.session.commit()
        
        return jsonify({'message': 'Medical record updated successfully'})
        
    except Exception as e:
        clinic_db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/api/medical-records/<int:record_id>', methods=['DELETE'])
@login_required
def delete_medical_record(record_id):
    try:
        record = MedicalRecord.query.get_or_404(record_id)
        
        # Log action before deletion
        action = UserAction(
            user_id=session['user_id'],
            action_type='delete',
            resource_type='MedicalRecord',
            resource_id=str(record_id),
            description=f"Deleted medical record {record_id}"
        )
        clinic_db.session.add(action)
        
        clinic_db.session.delete(record)
        clinic_db.session.commit()
        
        return jsonify({'message': 'Medical record deleted successfully'})
        
    except Exception as e:
        clinic_db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/api/patients/<int:patient_id>/images', methods=['GET'])
@login_required
def get_patient_images(patient_id):
    try:
        # Get all document references for the patient that are images
        documents = DocumentReference.query.filter_by(
            patient_id=patient_id,
            content_type='image'
        ).order_by(DocumentReference.date.desc()).all()
        
        return jsonify([{
            'id': doc.id,
            'type': doc.type,
            'description': doc.description,
            'date': doc.date.isoformat(),
            'fileUrl': f'/uploads/medical_images/{doc.content}',
            'content_type': doc.content_type
        } for doc in documents])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/patients/images/upload', methods=['POST'])
@login_required
def upload_patient_image():
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file part'}), 400
            
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No selected file'}), 400
            
        if not allowed_file(file.filename):
            return jsonify({'error': 'File type not allowed'}), 400
            
        # Get form data
        patient_id = request.form.get('patientId')
        image_type = request.form.get('type', 'X-ray')
        description = request.form.get('description', '')
        
        if not patient_id:
            return jsonify({'error': 'Patient ID is required'}), 400
            
        # Secure the filename and save the file
        filename = secure_filename(file.filename)
        timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        unique_filename = f"{timestamp}_{filename}"
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        file.save(file_path)
        
        # Create document reference
        new_document = DocumentReference(
            type=image_type,
            content_type='image',
            content=unique_filename,  # Store the filename
            description=description,
            patient_id=patient_id,
            date=datetime.utcnow()
        )
        
        clinic_db.session.add(new_document)
        
        # Log action
        action = UserAction(
            user_id=session['user_id'],
            action_type='create',
            resource_type='DocumentReference',
            resource_id=str(new_document.id),
            description=f"Uploaded medical image for patient {patient_id}"
        )
        clinic_db.session.add(action)
        clinic_db.session.commit()
        
        return jsonify({
            'message': 'Image uploaded successfully',
            'id': new_document.id,
            'fileUrl': f'/uploads/medical_images/{unique_filename}'
        }), 201
        
    except Exception as e:
        clinic_db.session.rollback()
        return jsonify({'error': str(e)}), 500

@app.route('/uploads/medical_images/<filename>')
@login_required
def serve_medical_image(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/api/patients/images/<int:image_id>', methods=['DELETE'])
@login_required
def delete_patient_image(image_id):
    try:
        document = DocumentReference.query.get_or_404(image_id)
        
        # Delete the file
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], document.content)
        if os.path.exists(file_path):
            os.remove(file_path)
        
        # Log action before deletion
        action = UserAction(
            user_id=session['user_id'],
            action_type='delete',
            resource_type='DocumentReference',
            resource_id=str(image_id),
            description=f"Deleted medical image {image_id}"
        )
        clinic_db.session.add(action)
        
        clinic_db.session.delete(document)
        clinic_db.session.commit()
        
        return jsonify({'message': 'Image deleted successfully'})
        
    except Exception as e:
        clinic_db.session.rollback()
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True , port=5000)