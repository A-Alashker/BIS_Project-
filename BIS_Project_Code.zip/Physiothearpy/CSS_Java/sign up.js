﻿// Signup form submit event
document.getElementById('signupForm').addEventListener('submit', async function(event) {
    event.preventDefault();

    const name = document.getElementById('signup-name').value.trim();
    const email = document.getElementById('signup-email').value.trim();
    const phone = document.getElementById('contactNumber').value.trim();
    const password = document.getElementById('signup-password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    // Validate role selection
    const roleInput = document.querySelector('input[name="role"]:checked');
    if (!roleInput) {
        alert('Please select a role!');
        return;
    }
    const role = roleInput.value;

    // Validate password confirmation
    if (password !== confirmPassword) {
        alert('Passwords do not match!');
        return;
    }

    const signupData = { 
        name, 
        email, 
        phone, 
        password, 
        role_code: role.toLowerCase() === 'nurse/secretary' ? 'nurse/secretary' : 'doctor' 
    };

    try {
        const response = await fetch('/api/signup', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(signupData),
            credentials: 'include'  // Important for session cookies
        });

        const result = await response.json();
        console.log('Signup response:', result);  // Debug log

        if (response.ok) {
            alert('Signup successful! Please login.');
            // Switch to login form after successful signup
            switchAuthForm('signin');
            // Clear the signup form
            document.getElementById('signupFormElement').reset();
        } else {
            alert('Signup failed: ' + (result.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Signup error:', error);
        alert('Network error: Please check your internet connection and try again.');
    }
});

// Signin form submit event
document.getElementById('signinForm').addEventListener('submit', async function(event) {
    event.preventDefault();

    const email = document.getElementById('signin-email').value.trim();
    const password = document.getElementById('signin-password').value;

    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                email: email,
                password: password
            }),
            credentials: 'include'  // Important for session cookies
        });

        const data = await response.json();
        console.log('Login response:', data);  // Debug log

        if (response.ok) {
            // Redirect based on user role
            const role = data.user.role || 'doctor';
            switch(role.toLowerCase()) {
                case 'doctor':
                    window.location.href = '/General_Dash';
                    break;
                case 'nurse/secretary':
                    window.location.href = '/Schedule';
                    break;
                default:
                    window.location.href = '/Patient_Dashboard';
            }
        } else {
            alert(data.error || 'Login failed. Please check your credentials.');
        }
    } catch (error) {
        console.error('Login error:', error);
        alert('Network error: Please check your internet connection and try again.');
    }
});

