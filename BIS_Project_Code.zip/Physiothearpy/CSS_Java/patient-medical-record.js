// Tab switching logic
const tabs = document.querySelectorAll('.tab');
tabs.forEach(tab => {
    tab.addEventListener('click', function() {
        tabs.forEach(t => t.classList.remove('active'));
        this.classList.add('active');
        // Add logic to show/hide tab content if needed
    });
});

// Edit icon click handlers
const editIcons = document.querySelectorAll('.edit-icon');
editIcons.forEach(icon => {
    icon.addEventListener('click', function() {
        alert('Edit functionality coming soon!');
    });
});

document.addEventListener('DOMContentLoaded', async () => {
    console.log('DOM Content Loaded');
    try {
        await loadPatientFromURL();
    } catch (error) {
        console.error('Error initializing medical records:', error);
        showNotification('Error loading patient data', 'error');
    }
});

// Global variables
let currentPatientId = null;
let attachments = [];
let currentZoom = 1;
let currentEditType = null;

// Sample patient data - this will be replaced with real data from URL params
const samplePatientData = {
    id: "PAT001",
    name: "John Doe",
    phone: "+1 (555) 123-4567",
    address: "123 Main St, City, State",
    birthDate: "1985-03-15",
    gender: "Male",
    primaryProvider: "Dr. Wilson",
    lastVisit: "2024-12-10T14:30:00",
    nextVisit: "2025-01-15T10:00:00",
    visitHistory: [
        {
            date: "2024-12-10",
            doctor: "Dr. Wilson",
            status: "Completed",
            treatment: "Physical Therapy"
        },
        {
            date: "2024-11-15",
            doctor: "Dr. Smith",
            status: "Completed",
            treatment: "Consultation"
        },
        {
            date: "2024-10-20",
            doctor: "Dr. Wilson",
            status: "In Progress",
            treatment: "Follow-up"
        }
    ],
    medication: {
        content: "Ibuprofen 400mg - Take twice daily with food for pain management. Continue for 2 weeks.",
        date: "2024-12-10T14:30:00"
    },
    diagnosis: {
        content: "Lower back strain due to muscle tension. Recommended physical therapy and rest.",
        date: "2024-12-10T14:25:00"
    }
};

// DOM Elements and Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM Content Loaded');
    initializeMedicalRecords();
    loadPatientFromURL();
    loadPatientImages();
});

function initializeMedicalRecords() {
    console.log('Initializing medical records');
    // Initialize with sample data
    displayPatientDetails(samplePatientData);
    displayVisitHistory(samplePatientData.visitHistory);
    displayMedication(samplePatientData.medication);
    displayDiagnosis(samplePatientData.diagnosis);
    loadPatientAttachments();
}

async function loadPatientFromURL() {
    // Get patient ID from URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const patientId = urlParams.get('patientId');
    
    if (patientId) {
        currentPatientId = patientId;
        console.log('Loading patient data for ID:', currentPatientId);
        
        try {
            // Fetch real patient data from backend
            const response = await fetch(`/api/patients/${patientId}/details`);
            if (!response.ok) {
                throw new Error('Failed to fetch patient data');
            }
            const patientData = await response.json();
            
            // Display the real patient data
            displayPatientDetails(patientData);
            displayVisitHistory(patientData.visitHistory || []);
            displayMedication(patientData.medication || { content: '', date: '' });
            displayDiagnosis(patientData.diagnosis || { content: '', date: '' });
            
            showNotification(`Patient ${patientId} loaded successfully`, 'success');
        } catch (error) {
            console.error('Error loading patient data:', error);
            showNotification('Error loading patient data', 'error');
            // Fallback to sample data if fetch fails
            displayPatientDetails(samplePatientData);
        }
    } else {
        console.log('No patient ID in URL, using default data');
        currentPatientId = samplePatientData.id;
        displayPatientDetails(samplePatientData);
    }
}

function displayPatientDetails(patientData) {
    console.log('Displaying patient details:', patientData);
    
    // Update patient info card
    const infoId = document.querySelector('.info-id');
    if (infoId) infoId.textContent = patientData.name;
    
    const providerValue = document.querySelector('.info-provider .info-value');
    if (providerValue) providerValue.textContent = patientData.primaryProvider || 'Not assigned';
    
    const dobValue = document.querySelector('.info-dob .info-value');
    if (dobValue) dobValue.textContent = formatDate(patientData.birthDate);
    
    const visitValues = document.querySelectorAll('.info-visit .info-value');
    if (visitValues.length >= 2) {
        visitValues[0].textContent = formatDateTime(patientData.lastVisit);
        visitValues[1].textContent = formatDateTime(patientData.nextVisit);
    }
    
    // Update patient details card
    const detailsId = document.querySelector('.patient-details-id');
    if (detailsId) detailsId.textContent = `ID: ${patientData.id}`;
    
    const detailsName = document.querySelector('.patient-details-name');
    if (detailsName) detailsName.textContent = patientData.name;
    
    const phone = document.querySelector('.patient-phone');
    if (phone) phone.textContent = patientData.phone || 'Not provided';
    
    const address = document.querySelector('.patient-address');
    if (address) address.textContent = patientData.address || 'Not provided';
    
    const birthdate = document.querySelector('.patient-birthdate');
    if (birthdate) birthdate.textContent = formatDate(patientData.birthDate);
    
    const gender = document.querySelector('.patient-gender');
    if (gender) gender.textContent = patientData.gender || 'Not provided';
    
    const assignee = document.querySelector('.patient-assignee');
    if (assignee) assignee.textContent = patientData.primaryProvider || 'Not assigned';
}

function displayVisitHistory(visitHistory) {
    console.log('Displaying visit history:', visitHistory);
    const tbody = document.querySelector('.visit-history-table tbody');
    if (!tbody) return;
    
    if (visitHistory.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; color: #8a8fa3;">No visits found</td></tr>';
        return;
    }
    
    tbody.innerHTML = visitHistory.map((visit, index) => `
        <tr>
            <td>${formatDate(visit.date)}</td>
            <td><span class="doctor-badge">${visit.doctor}</span></td>
            <td><span class="status-badge ${visit.status.toLowerCase().replace(' ', '-')}">${visit.status}</span></td>
            <td>${visit.treatment}</td>
        </tr>
    `).join('');
}

function displayMedication(medication) {
    console.log('Displaying medication:', medication);
    const content = document.querySelector('.medication-content');
    if (content) content.textContent = medication.content;
    
    const date = document.querySelector('.medication-date');
    if (date) date.textContent = `Prescribed: ${formatDateTime(medication.date)}`;
}

function displayDiagnosis(diagnosis) {
    console.log('Displaying diagnosis:', diagnosis);
    const content = document.querySelector('.diagnosis-content');
    if (content) content.textContent = diagnosis.content;
    
    const date = document.querySelector('.diagnosis-date');
    if (date) date.textContent = `Diagnosed: ${formatDateTime(diagnosis.date)}`;
}

function loadPatientAttachments() {
    console.log('Loading patient attachments');
    // Simulate loading attachments
    attachments = [
        {
            type: "X-ray",
            description: "Chest X-ray - Dec 2024",
            date: "2024-12-10",
            filename: "/lovable-uploads/72f5530d-01d7-4203-bb85-75c3cdc7aa87.png"
        },
        {
            type: "MRI",
            description: "MRI Scan - Nov 2024",
            date: "2024-11-15",
            filename: "/lovable-uploads/72f5530d-01d7-4203-bb85-75c3cdc7aa87.png"
        }
    ];
    displayPatientAttachments(attachments);
}

function displayPatientAttachments(attachments) {
    const container = document.querySelector('.attachments-list');
    if (!container) return;
    
    if (attachments.length === 0) {
        container.innerHTML = '<div style="color: #8a8fa3; font-style: italic;">No attachments available</div>';
        return;
    }
    
    container.innerHTML = attachments.map((att, index) => `
        <div class="attachment-item" onclick="openXrayViewer('${att.filename}', '${att.description}', '${att.date}', '${att.type}')">
            <span class="material-icons">description</span>
            ${att.description}
        </div>
    `).join('');
}

// Navigation handlers
function handleNavClick(section) {
    console.log('Navigation clicked:', section);
    
    // Remove active class from all nav items
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Add active class to clicked item
    event.target.classList.add('active');
    
    // Navigate to the appropriate page based on the section
    const pageUrls = {
        'Dashboard': '/General_Dash',
        'Reservation': '/Schedule',
        'Patients': '/patients',
        'Treatments': '/medical-records'
    };
    
    const targetUrl = pageUrls[section];
    if (targetUrl) {
        window.location.href = targetUrl;
    } else {
        showNotification(`Navigation to ${section} not implemented yet`, 'warning');
    }
}

function handleNotificationClick() {
    console.log('Notification clicked');
    showNotification('No new notifications', 'info');
}

function handleMessageClick() {
    console.log('Message clicked');
    showNotification('Opening messages...', 'info');
}

function handleAvatarClick() {
    console.log('Avatar clicked');
    showNotification('User profile clicked', 'info');
}

function handleCalendarClick() {
    console.log('Calendar clicked');
    showNotification('Opening calendar...', 'info');
}

function handleCallClick() {
    console.log('Call clicked');
    showNotification('Initiating call...', 'info');
}

function handlePrintClick() {
    console.log('Print clicked');
    showNotification('Preparing to print...', 'info');
    setTimeout(() => {
        window.print();
    }, 500);
}

function handleDownloadClick() {
    console.log('Download clicked');
    showNotification('Downloading medical record...', 'info');
}

function handleSearchClick() {
    console.log('Search clicked');
    const searchTerm = document.querySelector('.search-bar input').value;
    if (searchTerm) {
        showNotification(`Searching for: ${searchTerm}`, 'info');
    } else {
        showNotification('Please enter a search term', 'warning');
    }
}

// Tab switching
function switchTab(tabName) {
    console.log('Switching to tab:', tabName);
    
    // Remove active class from all tabs
    document.querySelectorAll('.tab').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Add active class to clicked tab
    event.target.classList.add('active');
    
    // Hide all tab content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // Show selected tab content
    let contentId;
    switch(tabName) {
        case 'General':
            contentId = 'generalContent';
            break;
        case 'X-ray & Images':
            contentId = 'xrayImagesContent';
            break;
        case '3D Model':
            contentId = 'modelContent';
            break;
        case 'Documents':
            contentId = 'documentsContent';
            break;
    }
    
    const targetContent = document.getElementById(contentId);
    if (targetContent) {
        targetContent.classList.add('active');
    }
    
    showNotification(`Switched to ${tabName} tab`, 'info');
}

// X-ray viewer functions
function openXrayViewer(imageSrc, description = '', date = '', type = '') {
    console.log('Opening X-ray viewer for:', imageSrc);
    const modal = document.getElementById('xrayModal');
    const image = document.getElementById('xrayImage');
    const analysis = document.getElementById('xrayAnalysis');
    const xrayDate = document.getElementById('xrayDate');
    const xrayType = document.getElementById('xrayType');
    
    if (modal && image) {
        // Load image with loading state
        image.src = '';
        image.style.opacity = '0';
        
        // Create a new image object to preload
        const img = new Image();
        img.onload = function() {
            image.src = this.src;
            image.style.opacity = '1';
        };
        img.onerror = function() {
            image.src = '/static/placeholder-image.png';
            image.style.opacity = '1';
            showNotification('Error loading image', 'error');
        };
        img.src = imageSrc;
        
        // Update modal information
        analysis.textContent = "Analyzing image...";
        xrayDate.textContent = formatDate(date);
        xrayType.textContent = type || 'Medical Image';
        modal.style.display = 'block';
        currentZoom = 1;
        image.style.transform = 'scale(1)';
        
        // Add drag functionality
        let isDragging = false;
        let startX, startY, initialX = 0, initialY = 0;
        
        image.addEventListener('mousedown', (e) => {
            isDragging = true;
            startX = e.clientX - initialX;
            startY = e.clientY - initialY;
        });
        
        document.addEventListener('mousemove', (e) => {
            if (isDragging) {
                initialX = e.clientX - startX;
                initialY = e.clientY - startY;
                image.style.transform = `scale(${currentZoom}) translate(${initialX}px, ${initialY}px)`;
            }
        });
        
        document.addEventListener('mouseup', () => {
            isDragging = false;
        });
        
        // Simulate AI analysis
        setTimeout(() => {
            analysis.textContent = "AI Analysis: No significant findings detected";
        }, 1500);
    }
}

function closeXrayViewer() {
    console.log('Closing X-ray viewer');
    const modal = document.getElementById('xrayModal');
    if (modal) {
        modal.style.display = 'none';
        currentZoom = 1;
    }
}

function zoomIn() {
    currentZoom = Math.min(currentZoom + 0.25, 3);
    const image = document.getElementById('xrayImage');
    if (image) {
        image.style.transform = `scale(${currentZoom})`;
    }
    showNotification(`Zoom: ${Math.round(currentZoom * 100)}%`, 'info');
}

function zoomOut() {
    currentZoom = Math.max(currentZoom - 0.25, 0.5);
    const image = document.getElementById('xrayImage');
    if (image) {
        image.style.transform = `scale(${currentZoom})`;
    }
    showNotification(`Zoom: ${Math.round(currentZoom * 100)}%`, 'info');
}

function resetZoom() {
    currentZoom = 1;
    const image = document.getElementById('xrayImage');
    if (image) {
        image.style.transform = 'scale(1) translate(0, 0)';
    }
    showNotification('Zoom reset to 100%', 'info');
}

// Edit functions
function editMedication() {
    console.log('Edit medication clicked');
    currentEditType = 'medication';
    const currentContent = document.querySelector('.medication-content').textContent;
    openEditModal('Edit Medication', currentContent);
}

function editDiagnosis() {
    console.log('Edit diagnosis clicked');
    currentEditType = 'diagnosis';
    const currentContent = document.querySelector('.diagnosis-content').textContent;
    openEditModal('Edit Diagnosis', currentContent);
}

function openEditModal(title, content) {
    const modal = document.getElementById('editModal');
    const modalTitle = document.getElementById('editModalTitle');
    const editContent = document.getElementById('editContent');
    
    if (modal && modalTitle && editContent) {
        modalTitle.textContent = title;
        editContent.value = content;
        modal.style.display = 'block';
    }
}

function closeEditModal() {
    const modal = document.getElementById('editModal');
    if (modal) {
        modal.style.display = 'none';
        currentEditType = null;
    }
}

function saveEdit() {
    const editContent = document.getElementById('editContent');
    const newContent = editContent.value.trim();
    
    if (!newContent) {
        showNotification('Please enter content', 'error');
        return;
    }
    
    const currentDateTime = new Date().toISOString();
    
    if (currentEditType === 'medication') {
        samplePatientData.medication.content = newContent;
        samplePatientData.medication.date = currentDateTime;
        displayMedication(samplePatientData.medication);
        showNotification('Medication updated successfully', 'success');
    } else if (currentEditType === 'diagnosis') {
        samplePatientData.diagnosis.content = newContent;
        samplePatientData.diagnosis.date = currentDateTime;
        displayDiagnosis(samplePatientData.diagnosis);
        showNotification('Diagnosis updated successfully', 'success');
    }
    
    closeEditModal();
}

// Attachment modal functions
function showAddAttachmentModal() {
    console.log('Show add attachment modal');
    const modal = document.getElementById('attachmentModal');
    if (modal) {
        modal.style.display = 'block';
    }
}

function closeAttachmentModal() {
    console.log('Close attachment modal');
    const modal = document.getElementById('attachmentModal');
    if (modal) {
        modal.style.display = 'none';
        // Clear form
        document.getElementById('attachmentType').value = 'report';
        document.getElementById('attachmentDescription').value = '';
        document.getElementById('attachmentFile').value = '';
    }
}

async function saveAttachment() {
    console.log('Saving attachment');
    const type = document.getElementById('attachmentType').value;
    const description = document.getElementById('attachmentDescription').value;
    const fileInput = document.getElementById('attachmentFile');
    
    if (!description.trim()) {
        showNotification('Please enter a description', 'error');
        return;
    }
    
    if (!fileInput.files.length) {
        showNotification('Please select a file', 'error');
        return;
    }
    
    try {
        const formData = new FormData();
        formData.append('type', type);
        formData.append('description', description);
        formData.append('file', fileInput.files[0]);
        formData.append('patientId', currentPatientId);
        
        const response = await fetch('/api/patients/images/upload', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            const error = await response.json();
            throw new Error(error.error || 'Failed to upload image');
        }
        
        const result = await response.json();
        
        // Refresh the images display
        await loadPatientImages();
        
        closeAttachmentModal();
        showNotification('Image uploaded successfully', 'success');
    } catch (error) {
        console.error('Error uploading image:', error);
        showNotification(error.message || 'Error uploading image', 'error');
    }
}

// Utility functions
function formatDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function formatDateTime(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function showNotification(message, type = 'info') {
    console.log(`Notification [${type}]:`, message);
    
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(n => n.remove());
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : type === 'warning' ? '#f59e0b' : '#6c47ff'};
        color: white;
        padding: 16px 24px;
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        z-index: 10000;
        font-weight: 600;
        max-width: 300px;
        transform: translateX(100%);
        transition: transform 0.3s ease;
    `;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

// Close modals when clicking outside
window.onclick = function(event) {
    const attachmentModal = document.getElementById('attachmentModal');
    const xrayModal = document.getElementById('xrayModal');
    const editModal = document.getElementById('editModal');
    const addPatientModal = document.getElementById('addPatientModal');
    
    if (event.target === attachmentModal) {
        closeAttachmentModal();
    }
    if (event.target === xrayModal) {
        closeXrayViewer();
    }
    if (event.target === editModal) {
        closeEditModal();
    }
    if (event.target === addPatientModal) {
        closeAddPatientModal();
    }
}

// Prevent form submission on enter in search
document.addEventListener('keydown', function(event) {
    if (event.target.matches('.search-bar input') && event.key === 'Enter') {
        event.preventDefault();
        handleSearchClick();
    }
});

// Add some sample console logs for debugging
console.log('Medical Record Dashboard Script Loaded');
console.log('Sample Patient Data:', samplePatientData);

// Add Patient Modal Functions
function openAddPatientModal() {
    console.log('Opening add patient modal');
    const modal = document.getElementById('addPatientModal');
    if (modal) {
        modal.style.display = 'block';
        
        // Reset all form fields
        document.getElementById('chief-complaint').value = '';
        document.getElementById('history').value = '';
        document.getElementById('past-history').value = '';
        document.getElementById('blood-pressure').value = '';
        document.getElementById('heart-rate').value = '';
        document.getElementById('temperature').value = '';
        document.getElementById('respiratory-rate').value = '';
        document.getElementById('physical-exam').value = '';
        document.getElementById('diagnosis').value = '';
        document.getElementById('treatment-plan').value = '';
        document.getElementById('medications').value = '';
        
        // Reset all sections to show only the first one
        document.querySelectorAll('.form-section').forEach(section => {
            section.classList.remove('active');
        });
        document.querySelector('.form-section[data-section="1"]').classList.add('active');
        
        // Reset progress indicators to show only first step active
        document.querySelectorAll('.step').forEach(step => {
            step.classList.remove('active');
        });
        document.querySelector('.step[data-section="1"]').classList.add('active');
        
        // Reset progress line
        const progressLine = document.querySelector('.progress-line');
        progressLine.style.width = '0%';
        
        // Show Next button, hide Save button
        const nextButton = document.querySelector('.next-button');
        const saveButton = document.querySelector('.save-button');
        nextButton.style.display = 'block';
        saveButton.style.display = 'none';

        // Scroll to top of the modal
        modal.scrollTop = 0;
    }
}

function closeAddPatientModal() {
    console.log('Closing add patient modal');
    const modal = document.getElementById('addPatientModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

function nextSection() {
    console.log('Next section clicked');
    const currentSection = document.querySelector('.form-section.active');
    const currentSectionNum = parseInt(currentSection.dataset.section);
    
    if (currentSectionNum < 3) {
        // Hide current section
        currentSection.classList.remove('active');
        // Show next section
        document.querySelector(`.form-section[data-section="${currentSectionNum + 1}"]`).classList.add('active');
        
        // Update progress indicators
        document.querySelector(`.step[data-section="${currentSectionNum}"]`).classList.remove('active');
        document.querySelector(`.step[data-section="${currentSectionNum + 1}"]`).classList.add('active');
        
        // Update progress line
        const progressLine = document.querySelector('.progress-line');
        progressLine.style.width = `${(currentSectionNum / 2) * 100}%`;
        
        // If we're moving to the last section, show Save button and hide Next button
        if (currentSectionNum + 1 === 3) {
            const nextButton = document.querySelector('.next-button');
            const saveButton = document.querySelector('.save-button');
            nextButton.style.display = 'none';
            saveButton.style.display = 'block';
        }

        // Scroll to top of the new section
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    }
}

function previousSection() {
    console.log('Previous section clicked');
    const currentSection = document.querySelector('.form-section.active');
    const currentSectionNum = parseInt(currentSection.dataset.section);
    
    if (currentSectionNum > 1) {
        // Hide current section
        currentSection.classList.remove('active');
        // Show previous section
        document.querySelector(`.form-section[data-section="${currentSectionNum - 1}"]`).classList.add('active');
        
        // Update progress indicators
        document.querySelector(`.step[data-section="${currentSectionNum}"]`).classList.remove('active');
        document.querySelector(`.step[data-section="${currentSectionNum - 1}"]`).classList.add('active');
        
        // Update progress line
        const progressLine = document.querySelector('.progress-line');
        progressLine.style.width = `${((currentSectionNum - 2) / 2) * 100}%`;
        
        // Show Next button, hide Save button
        const nextButton = document.querySelector('.next-button');
        const saveButton = document.querySelector('.save-button');
        nextButton.style.display = 'block';
        saveButton.style.display = 'none';
    }
}

function savePatientForm() {
    console.log('Saving patient form');
    const chiefComplaint = document.getElementById('chief-complaint').value;
    const history = document.getElementById('history').value;
    const pastHistory = document.getElementById('past-history').value;
    const bloodPressure = document.getElementById('blood-pressure').value;
    const heartRate = document.getElementById('heart-rate').value;
    const temperature = document.getElementById('temperature').value;
    const respiratoryRate = document.getElementById('respiratory-rate').value;
    const physicalExam = document.getElementById('physical-exam').value;
    const diagnosis = document.getElementById('diagnosis').value;
    const treatmentPlan = document.getElementById('treatment-plan').value;
    const medications = document.getElementById('medications').value;

    // Validate required fields
    if (!chiefComplaint || !history || !physicalExam || !diagnosis || !treatmentPlan) {
        showNotification('Please fill in all required fields', 'error');
        return;
    }

    // Create patient data object
    const patientData = {
        subjective: {
            chiefComplaint,
            history,
            pastHistory
        },
        objective: {
            vitals: {
                bloodPressure,
                heartRate,
                temperature,
                respiratoryRate
            },
            physicalExam
        },
        treatment: {
            diagnosis,
            treatmentPlan,
            medications
        }
    };

    // Here you would typically send this data to your backend
    console.log('Patient data to save:', patientData);
    
    // Simulate successful save
    showNotification('Patient information updated successfully', 'success');
    closeAddPatientModal();
}

// Add event listeners for form inputs to enable Next button
document.addEventListener('DOMContentLoaded', function() {
    // Add event listeners to all required inputs in each section
    const requiredInputs = document.querySelectorAll('.form-section input[required], .form-section select[required]');
    requiredInputs.forEach(input => {
        input.addEventListener('input', function() {
            const section = this.closest('.form-section');
            const sectionNum = parseInt(section.dataset.section);
            const nextButton = document.querySelector('.next-button');
            
            // Check if all required fields in this section are filled
            const allFilled = Array.from(section.querySelectorAll('input[required], select[required]'))
                .every(field => field.value.trim() !== '');
            
            // Enable/disable Next button based on whether all required fields are filled
            if (sectionNum < 4) {
                nextButton.disabled = !allFilled;
            }
        });
    });
});

function saveSubjective() {
    console.log('Saving subjective information');
    const patientReport = document.getElementById('patient-report').value;
    const primaryConcern = document.getElementById('primary-concern').value;
    const conditionHistory = document.getElementById('condition-history').value;
    const diagnosisDate = document.getElementById('diagnosis-date').value;
    const injuryDate = document.getElementById('injury-date').value;
    const careStart = document.getElementById('care-start').value;
    const surgeryRelated = document.querySelector('input[name="surgery-related"]:checked')?.value;

    // Create subjective data object
    const subjectiveData = {
        patientReport,
        primaryConcern,
        conditionHistory,
        diagnosisDate,
        injuryDate,
        careStart,
        surgeryRelated,
        lastUpdated: new Date().toISOString()
    };

    // Here you would typically send this data to your backend
    console.log('Subjective data to save:', subjectiveData);
    
    // Update the display
    const cardDate = document.querySelector('.info-card:nth-child(1) .card-date');
    cardDate.textContent = `Last Updated: ${formatDateTime(subjectiveData.lastUpdated)}`;
    
    showNotification('Subjective information updated successfully', 'success');
}

function saveObjective() {
    console.log('Saving objective information');
    const medicalImages = document.getElementById('medical-images').value;
    const imageDescription = document.querySelector('#medical-images + textarea').value;
    const annotations = document.getElementById('annotations-list').innerHTML;

    // Create objective data object
    const objectiveData = {
        medicalImages,
        imageDescription,
        annotations,
        lastUpdated: new Date().toISOString()
    };

    // Here you would typically send this data to your backend
    console.log('Objective data to save:', objectiveData);
    
    // Update the display
    const cardDate = document.querySelector('.info-card:nth-child(2) .card-date');
    cardDate.textContent = `Last Updated: ${formatDateTime(objectiveData.lastUpdated)}`;
    
    showNotification('Objective information updated successfully', 'success');
}

function savePlannedTreatment() {
    console.log('Saving planned treatment');
    const approach = document.getElementById('treatment-approach').value;
    const frequency = document.getElementById('treatment-frequency').value;
    const duration = document.getElementById('treatment-duration').value;
    const plannedProcedures = document.getElementById('planned-procedures').value;
    const additionalComments = document.getElementById('additional-comments').value;

    // Create treatment data object
    const treatmentData = {
        approach,
        frequency,
        duration,
        plannedProcedures,
        additionalComments,
        lastUpdated: new Date().toISOString()
    };

    // Here you would typically send this data to your backend
    console.log('Treatment data to save:', treatmentData);
    
    // Update the display
    const cardDate = document.querySelector('.info-card:nth-child(3) .card-date');
    cardDate.textContent = `Last Updated: ${formatDateTime(treatmentData.lastUpdated)}`;
    
    showNotification('Treatment plan updated successfully', 'success');
}

function addAnnotation() {
    console.log('Adding annotation');
    const annotation = prompt('Enter annotation:');
    if (annotation) {
        const annotationsList = document.getElementById('annotations-list');
        const annotationItem = document.createElement('div');
        annotationItem.className = 'annotation-item';
        annotationItem.innerHTML = `
            <span class="material-icons">label</span>
            <span>${annotation}</span>
            <button onclick="this.parentElement.remove()">
                <span class="material-icons">close</span>
            </button>
        `;
        annotationsList.appendChild(annotationItem);
    }
}

function clearAnnotations() {
    console.log('Clearing annotations');
    const annotationsList = document.getElementById('annotations-list');
    annotationsList.innerHTML = '';
}

// Medical Images Functions
async function loadPatientImages() {
    console.log('Loading patient medical images');
    try {
        const response = await fetch(`/api/patients/${currentPatientId}/images`);
        if (!response.ok) {
            throw new Error('Failed to fetch patient images');
        }
        const images = await response.json();
        displayPatientImages(images);
    } catch (error) {
        console.error('Error loading patient images:', error);
        showNotification('Error loading medical images', 'error');
    }
}

function displayPatientImages(images) {
    console.log('Displaying patient images:', images);
    const grid = document.querySelector('.xray-images-grid');
    if (!grid) return;
    
    if (images.length === 0) {
        grid.innerHTML = `
            <div class="no-images-message">
                <span class="material-icons" style="font-size: 48px; color: #6c47ff;">image_not_supported</span>
                <p>No medical images available</p>
            </div>
        `;
        return;
    }
    
    grid.innerHTML = images.map(image => `
        <div class="xray-image-item" onclick="openXrayViewer('${image.fileUrl}', '${image.description}', '${image.date}', '${image.type}')">
            <div class="xray-image-preview">
                <img src="${image.fileUrl}" alt="${image.description}" onerror="this.onerror=null; this.src='/static/placeholder-image.png';">
            </div>
            <div class="image-info">
                <div class="image-title">${image.description}</div>
                <div class="image-date">${formatDate(image.date)}</div>
                <div class="image-type">${image.type}</div>
            </div>
            <button class="delete-image-btn" onclick="deleteImage(${image.id}, event)">
                <span class="material-icons">delete</span>
            </button>
        </div>
    `).join('');
}

async function deleteImage(imageId, event) {
    event.stopPropagation(); // Prevent opening the viewer
    
    if (!confirm('Are you sure you want to delete this image?')) {
        return;
    }
    
    try {
        const response = await fetch(`/api/patients/images/${imageId}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            throw new Error('Failed to delete image');
        }
        
        await loadPatientImages();
        showNotification('Image deleted successfully', 'success');
    } catch (error) {
        console.error('Error deleting image:', error);
        showNotification('Error deleting image', 'error');
    }
}
