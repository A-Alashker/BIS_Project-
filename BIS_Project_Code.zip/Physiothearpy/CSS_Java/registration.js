// ===== DOM Elements =====
const addPatientBtn = document.getElementById('addPatientBtn');
const addPatientModal = document.getElementById('addPatientModal');
const closeModal = document.getElementById('closeModal');
const cancelAddPatient = document.getElementById('cancelAddPatient');
const addPatientForm = document.getElementById('addPatientForm');
const calendarViewBtn = document.getElementById('calendarViewBtn');
const listViewBtn = document.getElementById('listViewBtn');
const calendarView = document.getElementById('calendarView');
const listView = document.getElementById('listView');
const modalOverlay = document.querySelector('.modal-overlay');
const patientList = document.getElementById('patientList');
const calendarMonth = document.getElementById('calendarMonth');
const prevMonthBtn = document.getElementById('prevMonthBtn');
const nextMonthBtn = document.getElementById('nextMonthBtn');
const calendarGrid = document.getElementById('calendarGrid');

// ===== Initialization =====
document.addEventListener('DOMContentLoaded', () => {
  initializeView();
  initializeModalListeners();
  initializeViewToggle();
  initializeNav();
  initializeFilters();
  setMinDate();
  fetchPatients(); // Load patient data
  initializeCalendar();
  fetchDoctors(); // Add this line to fetch doctors when page loads
});

// ===== Modal Handlers =====
function initializeModalListeners() {
  addPatientBtn.addEventListener('click', openModal);
  closeModal.addEventListener('click', closeModalFunction);
  cancelAddPatient.addEventListener('click', closeModalFunction);
  modalOverlay.addEventListener('click', closeModalFunction);

  addPatientModal.querySelector('.modal-container').addEventListener('click', (e) => {
    e.stopPropagation();
  });

  addPatientForm.addEventListener('submit', handleFormSubmit);
}

function openModal() {
  addPatientModal.classList.add('active');
  document.body.style.overflow = 'hidden';
  // Accessibility: focus first input
  const firstInput = addPatientForm.querySelector('input, select, textarea');
  if (firstInput) firstInput.focus();
  addPatientModal.setAttribute('aria-modal', 'true');
  addPatientModal.setAttribute('role', 'dialog');
}

function closeModalFunction() {
  addPatientModal.classList.remove('active');
  document.body.style.overflow = '';
  addPatientForm.reset();
  addPatientModal.removeAttribute('aria-modal');
  addPatientModal.removeAttribute('role');
}

// ===== View Toggle =====
function initializeViewToggle() {
  calendarViewBtn.addEventListener('click', () => switchView('calendar'));
  listViewBtn.addEventListener('click', () => switchView('list'));
}

function switchView(view) {
  const isCalendar = view === 'calendar';
  calendarViewBtn.classList.toggle('active', isCalendar);
  listViewBtn.classList.toggle('active', !isCalendar);
  calendarView.classList.toggle('active', isCalendar);
  listView.classList.toggle('active', !isCalendar);
}

// ===== Navigation Buttons =====
function initializeNav() {
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (event) => {
      handleNavClick(item.dataset.section, event);
    });
  });
}

function handleNavClick(section, event) {
  const routes = {
    'Dashboard': '/General_Dash',
    'Reservation': '/Schedule',
    'Patients': '/patients',
    'Treatments': '/treatments',
    'Staff': '/staff'
  };
  if (routes[section]) {
    window.location.href = routes[section];
  }
  // Active state
  document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
  if (event && event.target) event.target.classList.add('active');
}

// ===== Filter Buttons =====
function initializeFilters() {
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      // You could re-fetch filtered data here
    });
  });
}

// ===== Form Handling =====
async function handleFormSubmit(e) {
  e.preventDefault();

  const formData = {
    patientName: document.getElementById('patientName').value,
    patientId: document.getElementById('patientId').value,
    doctor: document.getElementById('doctorSelect').value,
    appointmentTime: document.getElementById('appointmentTime').value,
    notes: document.getElementById('notes').value
  };

  try {
    const response = await fetch('/api/patients', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });

    if (response.ok) {
      showNotification('Patient added successfully!');
      fetchPatients(); // Refresh patient list
      closeModalFunction();
    } else {
      const errorMsg = (await response.json()).error || 'Failed to add patient.';
      showNotification(errorMsg, true);
    }
  } catch (error) {
    console.error(error);
    showNotification('Error connecting to server.', true);
  }
}

// ===== Backend Fetch Functions =====
async function fetchPatients() {
  showLoading(true);
  try {
    const res = await fetch('/api/patients');
    const patients = await res.json();
    renderPatients(patients);
  } catch (error) {
    console.error('Error fetching patients:', error);
    showNotification('Error fetching patients.', true);
  } finally {
    showLoading(false);
  }
}

function showLoading(isLoading) {
  let loading = document.getElementById('loadingSpinner');
  if (isLoading) {
    if (!loading) {
      loading = document.createElement('div');
      loading.id = 'loadingSpinner';
      loading.textContent = 'Loading...';
      loading.style = 'position:fixed;top:20px;right:20px;background:#333;color:#fff;padding:0.5rem 1rem;border-radius:0.5rem;z-index:1002;';
      document.body.appendChild(loading);
    }
  } else if (loading) {
    loading.remove();
  }
}

async function deletePatient(patientId) {
  if (!confirm('Are you sure you want to delete this patient?')) return;
  try {
    const res = await fetch(`/api/patients/${patientId}`, { method: 'DELETE' });
    if (res.ok) {
      showNotification('Patient deleted successfully.');
      fetchPatients();
    } else {
      showNotification('Failed to delete patient.', true);
    }
  } catch (err) {
    console.error(err);
    showNotification('Server error on delete.', true);
  }
}

function renderPatients(patients) {
  if (!patientList) return;
  patientList.innerHTML = '';
  patients.forEach(patient => {
    const item = document.createElement('div');
    item.className = 'patient-item';
    item.innerHTML = `
      <strong>${patient.patientName}</strong> — ${patient.doctor} at ${new Date(patient.appointmentTime).toLocaleString()}
      <div class="actions">
        <button class="edit-btn" data-id="${patient._id}">Edit</button>
        <button class="delete-btn" data-id="${patient._id}">Delete</button>
      </div>
    `;
    patientList.appendChild(item);
  });
  // Event delegation for edit/delete
  patientList.querySelectorAll('.edit-btn').forEach(btn => {
    btn.addEventListener('click', (e) => editPatient(btn.dataset.id));
  });
  patientList.querySelectorAll('.delete-btn').forEach(btn => {
    btn.addEventListener('click', (e) => deletePatient(btn.dataset.id));
  });
}

function editPatient(id) {
  showNotification('Edit feature coming soon.');
}

// ===== Notification System =====
function showNotification(message, isError = false) {
  const notification = document.createElement('div');
  notification.className = 'notification';
  notification.textContent = message;
  notification.style = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background: ${isError ? '#ef4444' : '#10b981'};
    color: white;
    padding: 1rem;
    border-radius: 0.5rem;
    box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    z-index: 1001;
    animation: fadeIn 0.3s ease-in;
  `;
  document.body.appendChild(notification);
  setTimeout(() => {
    notification.style.animation = 'fadeOut 0.3s ease-out';
    setTimeout(() => notification.remove(), 300);
  }, 3000);
}

// ===== Min Date for Appointment Input =====
function setMinDate() {
  const today = new Date();
  const formatted = today.toISOString().slice(0, 16);
  document.getElementById('appointmentTime').min = formatted;
}

// ===== Dynamic Calendar =====
function initializeCalendar() {
  if (!calendarMonth || !prevMonthBtn || !nextMonthBtn || !calendarGrid) return;
  let current = new Date();
  renderCalendar(current);

  prevMonthBtn.addEventListener('click', () => {
    current.setMonth(current.getMonth() - 1);
    renderCalendar(current);
  });
  nextMonthBtn.addEventListener('click', () => {
    current.setMonth(current.getMonth() + 1);
    renderCalendar(current);
  });
}

function renderCalendar(date) {
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const year = date.getFullYear();
  const month = date.getMonth();
  calendarMonth.textContent = `${monthNames[month]}, ${year}`;

  // First day of the month
  const firstDay = new Date(year, month, 1);
  const startDay = firstDay.getDay() || 7; // Make Sunday = 7
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const daysInPrevMonth = new Date(year, month, 0).getDate();

  // Clear grid
  calendarGrid.innerHTML = '';

  // Previous month's days
  for (let i = startDay - 1; i > 0; i--) {
    const d = document.createElement('div');
    d.className = 'day prev-month';
    d.textContent = daysInPrevMonth - i + 1;
    calendarGrid.appendChild(d);
  }
  // Current month's days
  for (let i = 1; i <= daysInMonth; i++) {
    const d = document.createElement('div');
    d.className = 'day';
    d.textContent = i;

    // Check if it's today
    const isToday = new Date().toDateString() === new Date(year, month, i).toDateString();
    if (isToday) {
      d.classList.add('today');
    }
    calendarGrid.appendChild(d);
  }
  // Next month's days to fill the grid
  const totalCells = startDay - 1 + daysInMonth;
  for (let i = 1; totalCells + i <= 35; i++) {
    const d = document.createElement('div');
    d.className = 'day next-month';
    d.textContent = i;
    calendarGrid.appendChild(d);
  }
}

// Calendar and Appointments functionality
let currentDate = new Date();
let selectedDate = new Date();
let currentView = 'day';
let selectedDoctor = 'all';
let currentDisplayMode = 'calendar'; // 'calendar' or 'list'

// Initialize calendar
document.addEventListener('DOMContentLoaded', () => {
  updateCalendar();
  fetchAppointments();
  updateMonthYearDisplay();
  setupEventListeners();
  fetchDoctors(); // Add this line to fetch doctors when page loads
});

// Setup event listeners
function setupEventListeners() {
  // Add Patient button
  document.getElementById('addPatientBtn').addEventListener('click', () => {
    document.getElementById('addPatientModal').classList.add('active');
  });

  // Close modal buttons
  document.getElementById('closeModal').addEventListener('click', () => {
    document.getElementById('addPatientModal').classList.remove('active');
  });

  document.getElementById('cancelAddPatient').addEventListener('click', () => {
    document.getElementById('addPatientModal').classList.remove('active');
  });

  // Form submission
  document.getElementById('addPatientForm').addEventListener('submit', handleAddPatient);
}

// Toggle between calendar and list views
function toggleView(view) {
  currentDisplayMode = view;
  
  // Update button states
  document.getElementById('calendarViewBtn').classList.toggle('active', view === 'calendar');
  document.getElementById('listViewBtn').classList.toggle('active', view === 'list');
  
  // Update view containers
  document.getElementById('calendarView').classList.toggle('active', view === 'calendar');
  document.getElementById('listView').classList.toggle('active', view === 'list');
  
  // Refresh data
  fetchAppointments();
}

// Handle add patient form submission
async function handleAddPatient(event) {
  event.preventDefault();
  
  const formData = {
    patientName: document.getElementById('patientName').value,
    patientId: document.getElementById('patientId').value,
    doctorId: document.getElementById('doctorSelect').value,
    appointmentTime: document.getElementById('appointmentTime').value,
    notes: document.getElementById('notes').value
  };

  try {
    const response = await fetch('/api/patients', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(formData)
    });

    if (!response.ok) {
      throw new Error('Failed to add patient');
    }

    // Close modal and refresh data
    document.getElementById('addPatientModal').classList.remove('active');
    document.getElementById('addPatientForm').reset();
    fetchAppointments();
    
    // Show success message
    showNotification('Patient added successfully', 'success');
  } catch (error) {
    console.error('Error adding patient:', error);
    showNotification('Failed to add patient', 'error');
  }
}

// Show notification
function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.className = `notification ${type}`;
  notification.textContent = message;
  
  document.body.appendChild(notification);
  
  // Remove notification after 3 seconds
  setTimeout(() => {
    notification.remove();
  }, 3000);
}

// Update month and year display
function updateMonthYearDisplay() {
  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                     'July', 'August', 'September', 'October', 'November', 'December'];
  document.getElementById('currentMonthYear').textContent = 
    `${monthNames[currentDate.getMonth()]}, ${currentDate.getFullYear()}`;
}

// Change month
function changeMonth(delta) {
  currentDate.setMonth(currentDate.getMonth() + delta);
  updateCalendar();
  updateMonthYearDisplay();
  fetchAppointments();
}

// Handle doctor selection change
function handleDoctorChange() {
  selectedDoctor = document.getElementById('doctor').value;
  fetchAppointments();
}

// Change view (day/week/month)
function changeView(view) {
  currentView = view;
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  event.target.classList.add('active');
  fetchAppointments();
}

// Update calendar grid
function updateCalendar() {
  const calendarBody = document.getElementById('calendarBody');
  if (!calendarBody) return;

  calendarBody.innerHTML = '';

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();
  
  // Get first day of month and total days
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const totalDays = lastDay.getDate();
  const startingDay = firstDay.getDay() || 7; // Convert Sunday (0) to 7
  
  // Get previous month's days
  const prevMonthLastDay = new Date(year, month, 0).getDate();
  
  let html = '';
  let day = 1;
  let nextMonthDay = 1;
  
  // Generate calendar grid
  for (let i = 0; i < 6; i++) {
    html += '<tr>';
    for (let j = 1; j <= 7; j++) {
      if (i === 0 && j < startingDay) {
        // Previous month's days
        const prevDay = prevMonthLastDay - startingDay + j + 1;
        html += `<td class="prev-month">${prevDay}</td>`;
      } else if (day > totalDays) {
        // Next month's days
        html += `<td class="next-month">${nextMonthDay}</td>`;
        nextMonthDay++;
      } else {
        // Current month's days
        const isToday = new Date().toDateString() === new Date(year, month, day).toDateString();
        const isSelected = selectedDate.toDateString() === new Date(year, month, day).toDateString();
        const classes = ['day'];
        if (isToday) classes.push('today');
        if (isSelected) classes.push('selected');
        
        html += `<td class="${classes.join(' ')}" data-date="${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}">${day}</td>`;
        day++;
      }
    }
    html += '</tr>';
    if (day > totalDays && nextMonthDay > 7) break;
  }
  
  calendarBody.innerHTML = html;

  // Add click event listeners to all calendar days
  const calendarDays = calendarBody.querySelectorAll('td');
  calendarDays.forEach(day => {
    // Single click handler
    day.addEventListener('click', function() {
      // Remove selected class from all days
      calendarDays.forEach(d => d.classList.remove('selected'));
      // Add selected class to clicked day
      this.classList.add('selected');
      // Update selected date
      const dateStr = this.dataset.date;
      if (dateStr) {
        selectedDate = new Date(dateStr);
        fetchAppointments();
      }
    });

    // Double click handler
    day.addEventListener('dblclick', function() {
      const dateStr = this.dataset.date;
      if (dateStr) {
        const date = new Date(dateStr);
        showAppointmentsForDay(date);
      }
    });
  });
}

// Show appointments for specific day
function showAppointmentsForDay(date) {
  const modal = document.getElementById('addAppointmentModal');
  modal.classList.add('active');
  
  // Update the modal title
  const modalTitle = modal.querySelector('.modal-header h2');
  if (modalTitle) {
    modalTitle.textContent = `Appointments for ${date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`;
  }
  
  // Set the selected date in the form
  document.getElementById('appointmentDate').valueAsDate = date;
  
  // Initialize patient type selection
  initializePatientTypeSelection();
  
  // Initialize doctor selection
  fetchDoctors();
  
  // Initialize available time slots
  updateAvailableTimeSlots();
  
  // Show existing appointments for the day
  fetchAppointmentsForDay(date).then(appointments => {
    const appointmentsList = document.createElement('div');
    appointmentsList.className = 'existing-appointments';
    
    if (!appointments || appointments.length === 0) {
      appointmentsList.innerHTML = `
        <div class="no-appointments">
          <i class="fas fa-calendar-times"></i>
          <p>No appointments scheduled for this day</p>
        </div>
      `;
    } else {
      appointmentsList.innerHTML = `
        <h3>Existing Appointments</h3>
        <div class="appointments-list">
          ${appointments.map(app => `
            <div class="appointment-item">
              <div class="appointment-time">${new Date(app.appointmentTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</div>
              <div class="appointment-details">
                <h4>${app.patientName}</h4>
                <p>Dr. ${app.doctorName}</p>
                <p>${app.appointmentType}</p>
              </div>
            </div>
          `).join('')}
        </div>
      `;
    }
    
    // Insert the appointments list before the form
    const form = document.getElementById('addAppointmentForm');
    form.insertBefore(appointmentsList, form.firstChild);

    // Add New Patient button directly under the modal title
    const newPatientBtn = document.createElement('button');
    newPatientBtn.type = 'button';
    newPatientBtn.className = 'new-patient-btn';
    newPatientBtn.innerHTML = `
      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"></path>
        <circle cx="9" cy="7" r="4"></circle>
        <line x1="19" y1="8" x2="19" y2="14"></line>
        <line x1="22" y1="11" x2="16" y2="11"></line>
      </svg>
      Add New Patient
    `;
    newPatientBtn.onclick = () => {
      document.getElementById('newPatientBtn').click();
    };
    // Insert the button after the modal title
    const modalHeader = modal.querySelector('.modal-header');
    if (modalHeader && modalTitle) {
      modalHeader.insertBefore(newPatientBtn, modalTitle.nextSibling);
    }
  }).catch(error => {
    console.error('Error fetching appointments:', error);
    showNotification('Error loading appointments', 'error');
  });
}

// Fetch appointments for specific day
async function fetchAppointmentsForDay(date) {
  try {
    const dateStr = date.toISOString().split('T')[0];
    const response = await fetch(`/api/appointments?date=${dateStr}`);
    if (!response.ok) {
      throw new Error('Failed to fetch appointments');
    }
    return await response.json();
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
}

// Fetch appointments
async function fetchAppointments() {
  try {
    const date = selectedDate.toISOString().split('T')[0];
    const response = await fetch(`/api/appointments?date=${date}&doctor=${selectedDoctor}&view=${currentView}&display=${currentDisplayMode}`);
    const appointments = await response.json();
    renderAppointments(appointments);
  } catch (error) {
    console.error('Error fetching appointments:', error);
    document.getElementById('appointmentsList').innerHTML = 
      '<p class="error-message">Error loading appointments. Please try again.</p>';
  }
}

// Render appointments
function renderAppointments(appointments) {
  const list = document.getElementById('appointmentsList');
  list.innerHTML = '';

  if (!appointments.length) {
    list.innerHTML = `
      <div class="no-appointments">
        <i class="fas fa-calendar-check"></i>
        <p>No appointments for this ${currentView}</p>
      </div>`;
    return;
  }

  appointments.forEach(app => {
    const div = document.createElement('div');
    div.className = 'appointment-card';
    div.innerHTML = `
      <div class="appointment-header">
        <h3>Patient #${app.patientId || app.patient_id || ''}</h3>
        <span class="status-badge ${app.status?.toLowerCase() || 'upcoming'}">${app.status || 'Upcoming'}</span>
      </div>
      <div class="appointment-body">
        <h4>${app.patientName || app.patient_name || ''}</h4>
        <p class="time-info">
          <i class="far fa-clock"></i>
          ${app.appointmentTime ? new Date(app.appointmentTime).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : (app.start ? app.start.slice(0,5) : '')} - ${app.end ? app.end.slice(0,5) : ''}
        </p>
      </div>
      <div class="appointment-footer">
        <button class="details-btn" onclick="showAppointmentDetails('${app.id}')">Details</button>
      </div>
    `;
    list.appendChild(div);
  });
}

// Show appointment details
function showAppointmentDetails(appointmentId) {
  // Implement appointment details modal or navigation
  console.log('Show details for appointment:', appointmentId);
}

// Fetch doctors from API
async function fetchDoctors() {
  try {
    console.log('Fetching doctors...');
    const response = await fetch('/api/practitioners');
    if (!response.ok) {
      console.error('Failed to fetch doctors:', response.status, response.statusText);
      throw new Error('Failed to fetch doctors');
    }
    const doctors = await response.json();
    console.log('Fetched doctors:', doctors);
    updateDoctorSelect(doctors);
  } catch (error) {
    console.error('Error fetching doctors:', error);
    showNotification('Error loading doctors', 'error');
  }
}

// Update doctor select dropdown
function updateDoctorSelect(doctors) {
  console.log('Updating doctor select with:', doctors);
  const doctorSelect = document.getElementById('doctor');
  const doctorSelectModal = document.getElementById('doctorSelect');
  
  if (!doctorSelect || !doctorSelectModal) {
    console.error('Could not find doctor select elements');
    return;
  }

  const options = `
    <option value="all">All Doctors</option>
    ${doctors.map(doctor => `
      <option value="${doctor.id}">Dr. ${doctor.name}</option>
    `).join('')}
  `;

  doctorSelect.innerHTML = options;
  doctorSelectModal.innerHTML = `
    <option value="">-- Select Doctor --</option>
    ${doctors.map(doctor => `
      <option value="${doctor.id}">Dr. ${doctor.name}</option>
    `).join('')}
  `;
  console.log('Updated doctor selects');
}

// Add Appointment Modal functionality
function openAddAppointmentModal() {
  const modal = document.getElementById('addAppointmentModal');
  modal.classList.add('active');
  
  // Set default date to today
  const today = new Date();
  document.getElementById('appointmentDate').valueAsDate = today;
  
  // Initialize patient type selection
  initializePatientTypeSelection();
  
  // Initialize doctor selection
  fetchDoctors();
  
  // Initialize available time slots
  updateAvailableTimeSlots();
}

function initializePatientTypeSelection() {
  const newPatientBtn = document.getElementById('newPatientBtn');
  const existingPatientBtn = document.getElementById('existingPatientBtn');
  const searchSection = document.getElementById('patientSearchSection');
  const newPatientForm = document.getElementById('newPatientForm');
  
  newPatientBtn.addEventListener('click', () => {
    newPatientBtn.classList.add('active');
    existingPatientBtn.classList.remove('active');
    searchSection.style.display = 'none';
    newPatientForm.style.display = 'block';
    // Clear any selected patient data
    document.getElementById('selectedPatientInfo').style.display = 'none';
  });
  
  existingPatientBtn.addEventListener('click', () => {
    existingPatientBtn.classList.add('active');
    newPatientBtn.classList.remove('active');
    searchSection.style.display = 'block';
    newPatientForm.style.display = 'none';
  });
}

// Search patients in database
async function searchPatient() {
  const searchInput = document.getElementById('patientSearchInput');
  const searchType = document.getElementById('searchType').value;
  const searchResults = document.getElementById('searchResults');
  
  if (!searchInput.value.trim()) {
    showNotification('Please enter a search term', 'error');
    return;
  }

  try {
    const response = await fetch(`/api/patients/search?${searchType}=${encodeURIComponent(searchInput.value)}`);
    if (!response.ok) {
      throw new Error('Failed to search patients');
    }
    
    const patients = await response.json();
    
    if (patients.length === 0) {
      searchResults.innerHTML = `
        <div class="no-results">
          <p>No patients found matching your search.</p>
          <button type="button" class="secondary-btn" onclick="switchToNewPatient()">
            Add New Patient
          </button>
        </div>
      `;
      return;
    }
    
    searchResults.innerHTML = patients.map(patient => `
      <div class="patient-result" onclick="selectPatient('${patient.id}')">
        <div class="patient-info">
          <h4>${patient.name}</h4>
          <p>ID: ${patient.id}</p>
          <p>Phone: ${patient.phone || 'N/A'}</p>
          <p>Email: ${patient.email || 'N/A'}</p>
        </div>
      </div>
    `).join('');
  } catch (error) {
    console.error('Error searching patients:', error);
    showNotification('Error searching patients', 'error');
  }
}

// Switch to new patient form
function switchToNewPatient() {
  document.getElementById('newPatientBtn').click();
}

// Handle new patient registration
async function handleNewPatientRegistration(event) {
  event.preventDefault();
  
  const formData = {
    name: document.getElementById('newPatientName').value,
    id: document.getElementById('newPatientId').value,
    phone: document.getElementById('newPatientPhone').value,
    email: document.getElementById('newPatientEmail').value,
    address: document.getElementById('newPatientAddress').value,
    dateOfBirth: document.getElementById('newPatientDOB').value,
    gender: document.getElementById('newPatientGender').value
  };

  try {
    const response = await fetch('/api/patients', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(formData)
    });

    if (!response.ok) {
      throw new Error('Failed to register new patient');
    }

    const newPatient = await response.json();
    showNotification('Patient registered successfully', 'success');
    
    // Select the newly registered patient
    selectPatient(newPatient.id);
  } catch (error) {
    console.error('Error registering new patient:', error);
    showNotification('Failed to register new patient', 'error');
  }
}

// Select patient from search results
async function selectPatient(patientId) {
  try {
    const response = await fetch(`/api/patients/${patientId}`);
    if (!response.ok) {
      throw new Error('Failed to fetch patient details');
    }
    
    const patient = await response.json();
    
    // Fill form with patient data
    document.getElementById('selectedPatientId').value = patient.id;
    document.getElementById('selectedPatientName').textContent = patient.name;
    document.getElementById('patientSearchSection').style.display = 'none';
    document.getElementById('selectedPatientInfo').style.display = 'block';
    
    // Update available time slots
    updateAvailableTimeSlots();
  } catch (error) {
    console.error('Error fetching patient details:', error);
    showNotification('Error loading patient details', 'error');
  }
}

// Fetch doctors from database
async function fetchDoctors() {
  try {
    const response = await fetch('/api/doctors');
    if (!response.ok) {
      throw new Error('Failed to fetch doctors');
    }
    
    const doctors = await response.json();
    const doctorSelect = document.getElementById('doctorSelect');
    
    doctorSelect.innerHTML = `
      <option value="">-- Select Doctor --</option>
      ${doctors.map(doctor => `
        <option value="${doctor.id}">Dr. ${doctor.name} - ${doctor.specialization}</option>
      `).join('')}
    `;
  } catch (error) {
    console.error('Error fetching doctors:', error);
    showNotification('Error loading doctors', 'error');
  }
}

// Update available time slots based on selected date and doctor
async function updateAvailableTimeSlots() {
  const date = document.getElementById('appointmentDate').value;
  const doctorId = document.getElementById('doctorSelect').value;
  
  if (!date || !doctorId) {
    return;
  }

  try {
    const response = await fetch(`/api/appointments/available-slots?date=${date}&doctor=${doctorId}`);
    if (!response.ok) {
      throw new Error('Failed to fetch available slots');
    }
    
    const slots = await response.json();
    const timeSelect = document.getElementById('appointmentTime');
    
    if (slots.length === 0) {
      timeSelect.innerHTML = '<option value="">No available slots for this date</option>';
      return;
    }
    
    timeSelect.innerHTML = `
      <option value="">-- Select Time --</option>
      ${slots.map(slot => `
        <option value="${slot.time}">${slot.time}</option>
      `).join('')}
    `;
  } catch (error) {
    console.error('Error fetching available slots:', error);
    showNotification('Error loading available time slots', 'error');
  }
}

// Event Listeners for Appointment Modal
document.addEventListener('DOMContentLoaded', function() {
  // Close modal when clicking overlay or close button
  const modal = document.getElementById('addAppointmentModal');
  const closeBtn = document.getElementById('closeModal');
  const cancelBtn = document.getElementById('cancelAddAppointment');
  const overlay = modal.querySelector('.modal-overlay');
  
  closeBtn.addEventListener('click', closeAddAppointmentModal);
  cancelBtn.addEventListener('click', closeAddAppointmentModal);
  overlay.addEventListener('click', closeAddAppointmentModal);
  
  // Handle form submissions
  document.getElementById('addAppointmentForm').addEventListener('submit', handleAddAppointment);
  document.getElementById('newPatientForm').addEventListener('submit', handleNewPatientRegistration);
  
  // Add event listeners for dynamic updates
  document.getElementById('appointmentDate').addEventListener('change', updateAvailableTimeSlots);
  document.getElementById('doctorSelect').addEventListener('change', updateAvailableTimeSlots);
  document.getElementById('searchPatientBtn').addEventListener('click', searchPatient);
  
  // Add debounced search for patient search input
  const searchInput = document.getElementById('patientSearchInput');
  let searchTimeout;
  searchInput.addEventListener('input', () => {
    clearTimeout(searchTimeout);
    searchTimeout = setTimeout(searchPatient, 500);
  });
});

// Handle Add Appointment
async function handleAddAppointment(event) {
  event.preventDefault();
  
  const isNewPatient = document.getElementById('newPatientBtn').classList.contains('active');
  const formData = {
    patientName: isNewPatient ? document.getElementById('newPatientName').value : document.getElementById('selectedPatientName').textContent,
    patientId: isNewPatient ? document.getElementById('newPatientId').value : document.getElementById('selectedPatientId').value,
    doctorId: document.getElementById('doctorSelect').value,
    appointmentDate: document.getElementById('appointmentDate').value,
    appointmentTime: document.getElementById('appointmentTime').value,
    appointmentType: document.getElementById('appointmentType').value,
    notes: document.getElementById('notes').value
  };

  try {
    const response = await fetch('/api/appointments', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(formData)
    });

    if (!response.ok) {
      throw new Error('Failed to add appointment');
    }

    // Close modal and refresh data
    closeAddAppointmentModal();
    fetchAppointments();
    
    // Show success message
    showNotification('Appointment scheduled successfully', 'success');
  } catch (error) {
    console.error('Error adding appointment:', error);
    showNotification('Failed to schedule appointment', 'error');
  }
}

function closeAddAppointmentModal() {
  const modal = document.getElementById('addAppointmentModal');
  modal.classList.remove('active');
  document.getElementById('addAppointmentForm').reset();
}
