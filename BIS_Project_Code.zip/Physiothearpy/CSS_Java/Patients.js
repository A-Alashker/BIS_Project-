// ===== DOM Elements =====
const newPatientBtn = document.querySelector('.patients-new-btn');
const filterBtn = document.querySelector('.patients-filter-btn');
const searchInput = document.querySelector('.patients-search');
const patientsTbody = document.getElementById('patients-tbody');
const navItems = document.querySelectorAll('.nav-item');
const notificationBtn = document.querySelector('.icon-button[onclick="handleNotificationClick()"]');
const messageBtn = document.querySelector('.icon-button[onclick="handleMessageClick()"]');
const avatarBtn = document.querySelector('.avatar');

// ===== Navigation Buttons =====
function initializeNav() {
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', (event) => {
        handleNavClick(item.dataset.section, event);
      });
    });
}
  
function handleNavClick(section, event) {
    const routes = {
      'Dashboard': '/General_Dash',
      'Reservation': '/Schedule',
      'Patients': '/patients',
      'Treatments': '/treatments',
      'Staff': '/staff'
    };
    if (routes[section]) {
      window.location.href = routes[section];
    }
    // Active state
    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
    if (event && event.target) event.target.classList.add('active');
}

// ===== Patient Management Functions =====
async function fetchPatients() {
    try {
        const response = await fetch('/api/patients');
        if (!response.ok) {
            throw new Error('Failed to fetch patients');
        }
        const patients = await response.json();
        renderPatients(patients);
    } catch (error) {
        console.error('Error fetching patients:', error);
        showNotification('Error loading patients', 'error');
    }
}

function renderPatients(patients) {
    const tbody = document.getElementById('patients-tbody');
    tbody.innerHTML = '';

    patients.forEach(patient => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${patient.name}</td>
            <td>${patient.id}</td>
            <td>${patient.phone || 'N/A'}</td>
            <td>${patient.email || 'N/A'}</td>
            <td>${getAppointmentType(patient)}</td>
            <td>
                <button class="view-details-btn" onclick="viewPatientDetails(${patient.id})">View</button>
                <button class="edit-btn" onclick="editPatient(${patient.id})">Edit</button>
                <button class="delete-btn" onclick="deletePatient(${patient.id})">Delete</button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

function getAppointmentType(patient) {
    // This would need to be implemented based on your appointment data structure
    return 'Regular Checkup';
}

async function viewPatientDetails(patientId) {
    try {
        // Navigate to the patient medical record page in the same directory
        window.location.href = 'patient-medical-record.html?patientId=' + patientId;
    } catch (error) {
        console.error('Error navigating to patient details:', error);
        showNotification('Error loading patient details', 'error');
    }
}

async function editPatient(patientId) {
    try {
        const response = await fetch(`/api/patients/${patientId}`);
        if (!response.ok) {
            throw new Error('Failed to fetch patient data');
        }
        const patient = await response.json();
        showEditPatientModal(patient);
    } catch (error) {
        console.error('Error fetching patient data:', error);
        showNotification('Error loading patient data', 'error');
    }
}

async function deletePatient(patientId) {
    if (!confirm('Are you sure you want to delete this patient?')) {
        return;
    }

    try {
        const response = await fetch(`/api/patients/${patientId}`, {
            method: 'DELETE'
        });
        
        if (!response.ok) {
            throw new Error('Failed to delete patient');
        }
        
        showNotification('Patient deleted successfully', 'success');
        fetchPatients(); // Refresh the patient list
    } catch (error) {
        console.error('Error deleting patient:', error);
        showNotification('Error deleting patient', 'error');
    }
}

// ===== Search and Filter Functions =====
function handleSearch() {
    const searchTerm = searchInput.value.toLowerCase();
    const rows = patientsTbody.getElementsByTagName('tr');

    for (let row of rows) {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    }
}

// ===== Modal Functions =====
function showPatientDetailsModal(patient) {
    // Implement your patient details modal logic here
    console.log('Show patient details:', patient);
}

function showEditPatientModal(patient) {
    // Implement your edit patient modal logic here
    console.log('Show edit patient:', patient);
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

function showAddPatientModal() {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h2>Add New Patient</h2>
                <button class="close-modal" onclick="closeAddPatientModal()">&times;</button>
            </div>
            <div class="modal-body">
                <form id="addPatientForm" novalidate>
                    <div class="form-section" data-section="1">
                        <div class="demographic-section">
                            <h2>Demographic</h2>
                            <div class="form-group">
                                <label for="first-name">First Name</label>
                                <input type="text" id="first-name" placeholder="Enter first name" required>
                                <div class="error-message"></div>
                            </div>
                            <div class="form-group">
                                <label for="last-name">Last Name</label>
                                <input type="text" id="last-name" placeholder="Enter last name" required>
                                <div class="error-message"></div>
                            </div>
                            <div class="form-group">
                                <label for="birth-date">Date of Birth</label>
                                <input type="date" id="birth-date" required>
                                <div class="error-message"></div>
                            </div>
                            <div class="form-group">
                                <label for="gender">Gender</label>
                                <select id="gender" required>
                                    <option value="">Select gender</option>
                                    <option value="male">Male</option>
                                    <option value="female">Female</option>
                                </select>
                                <div class="error-message"></div>
                            </div>
                        </div>
                        <div class="contact-info-section">
                            <h2>Contact Information</h2>
                            <div class="form-group">
                                <label for="address">Address</label>
                                <input type="text" id="address" placeholder="Enter patient street address" required>
                                <div class="error-message"></div>
                            </div>
                            <div class="form-group">
                                <label for="city">City</label>
                                <input type="text" id="city" placeholder="Enter city here" required>
                                <div class="error-message"></div>
                            </div>
                            <div class="form-group">
                                <label for="email">Email Address</label>
                                <input type="email" id="email" placeholder="Email" required>
                                <div class="error-message"></div>
                            </div>
                            <div class="form-group">
                                <label for="phone">Mobile Phone</label>
                                <input type="tel" id="phone" placeholder="000-000-0000" required pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}">
                                <div class="error-message"></div>
                            </div>
                        </div>
                    </div>
                    <div class="navigation-buttons">
                        <button type="submit" class="save-button">Save</button>
                    </div>
                </form>
            </div>
        </div>
    `;
    document.body.appendChild(modal);
    
    // Add form submission handler
    const form = modal.querySelector('#addPatientForm');
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        // Collect form data
        const firstName = form.querySelector('#first-name').value.trim();
        const lastName = form.querySelector('#last-name').value.trim();
        const name = `${firstName} ${lastName}`.trim();
        const gender = form.querySelector('#gender').value;
        const birthDate = form.querySelector('#birth-date').value;
        const phone = form.querySelector('#phone').value;
        const email = form.querySelector('#email').value;
        const address = `${form.querySelector('#address').value}, ${form.querySelector('#city').value}`.trim();

        // Validate required fields
        if (!firstName || !lastName || !gender || !birthDate || !phone || !email || !address) {
            showNotification('Please fill in all required fields.', 'error');
            return;
        }
        if (gender !== 'male' && gender !== 'female') {
            showNotification('Gender must be Male or Female.', 'error');
            return;
        }

        const data = { name, gender, birthDate, phone, email, address };
        try {
            const response = await fetch('/api/patients', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            if (!response.ok) {
                let errorMsg = 'Error adding patient';
                try {
                    const err = await response.json();
                    if (err && err.error) errorMsg = err.error;
                } catch {}
                showNotification(errorMsg, 'error');
                return;
            }
            showNotification('Patient added successfully', 'success');
            closeAddPatientModal();
            fetchPatients();
        } catch (error) {
            showNotification('Error connecting to server', 'error');
        }
    });
}

function closeAddPatientModal() {
    const modal = document.querySelector('.modal-overlay');
    if (modal) {
        modal.remove();
    }
}

function initializeDateInputs() {
    // Set max date for birth date to today
    const birthDateInput = document.getElementById('birth-date');
    const today = new Date().toISOString().split('T')[0];
    birthDateInput.max = today;

    // Set max date for other date inputs to today
    const dateInputs = ['diagnosis-date', 'injury-date', 'care-start'];
    dateInputs.forEach(id => {
        const input = document.getElementById(id);
        if (input) {
            input.max = today;
        }
    });
}

function validateInput(input) {
    // Only validate inputs in section 1 (Demographics)
    const section = input.closest('.form-section');
    if (section && section.dataset.section !== '1') {
        return true; // Skip validation for other sections
    }

    const errorElement = input.parentElement.querySelector('.error-message');
    let isValid = true;
    let errorMessage = '';

    // Skip validation for non-required fields if they're empty
    if (!input.required && !input.value) {
        if (errorElement) {
            errorElement.textContent = '';
            input.classList.remove('error');
        }
        return true;
    }

    // Required field validation
    if (input.required && !input.value.trim()) {
        isValid = false;
        errorMessage = 'This field is required';
    } 
    // Email validation
    else if (input.type === 'email' && input.value && !isValidEmail(input.value)) {
        isValid = false;
        errorMessage = 'Please enter a valid email address';
    } 
    // Phone validation
    else if (input.id === 'phone' && input.value && !isValidPhone(input.value)) {
        isValid = false;
        errorMessage = 'Please enter a valid phone number (000-000-0000)';
    }
    // Date validation
    else if (input.type === 'date' && input.value) {
        const selectedDate = new Date(input.value);
        const today = new Date();
        
        if (selectedDate > today) {
            isValid = false;
            errorMessage = 'Date cannot be in the future';
        }
    }

    if (errorElement) {
        errorElement.textContent = errorMessage;
        input.classList.toggle('error', !isValid);
    }

    return isValid;
}

function isValidEmail(email) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function isValidPhone(phone) {
    return /^\d{3}-\d{3}-\d{4}$/.test(phone);
}

function initializeFormNavigation() {
    let currentSection = 1;
    const totalSections = 4;
    const form = document.getElementById('addPatientForm');

    // Add input validation only for section 1
    form.querySelectorAll('[data-section="1"] input, [data-section="1"] select').forEach(input => {
        input.addEventListener('input', () => validateInput(input));
        input.addEventListener('blur', () => validateInput(input));
    });

    window.nextSection = function() {
        if (currentSection < totalSections) {
            // Only validate section 1
            if (currentSection === 1) {
                const currentSectionElement = document.querySelector(`[data-section="${currentSection}"]`);
                const inputs = currentSectionElement.querySelectorAll('input, select');
                let isValid = true;

                inputs.forEach(input => {
                    if (!validateInput(input)) {
                        isValid = false;
                    }
                });

                if (!isValid) {
                    showNotification('Please fill in all required fields correctly', 'error');
                    return;
                }
            }

            document.querySelector(`[data-section="${currentSection}"]`).style.display = 'none';
            currentSection++;
            document.querySelector(`[data-section="${currentSection}"]`).style.display = 'block';
            updateProgressIndicators();
        }
    };

    window.previousSection = function() {
        if (currentSection > 1) {
            document.querySelector(`[data-section="${currentSection}"]`).style.display = 'none';
            currentSection--;
            document.querySelector(`[data-section="${currentSection}"]`).style.display = 'block';
            updateProgressIndicators();
        }
    };

    function updateProgressIndicators() {
        document.querySelectorAll('.step').forEach(step => {
            const sectionNum = parseInt(step.dataset.section);
            step.classList.toggle('active', sectionNum === currentSection);
            step.classList.toggle('completed', sectionNum < currentSection);
        });
    }

    // Add form submission handler
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        
        // Only validate section 1
        const section1Inputs = form.querySelectorAll('[data-section="1"] input, [data-section="1"] select');
        let isValid = true;
        let firstInvalidInput = null;

        section1Inputs.forEach(input => {
            if (!validateInput(input)) {
                isValid = false;
                if (!firstInvalidInput) {
                    firstInvalidInput = input;
                }
            }
        });

        if (!isValid) {
            showNotification('Please fill in all required fields correctly', 'error');
            if (firstInvalidInput) {
                firstInvalidInput.focus();
            }
            return;
        }

        const formData = {
            name: `${document.getElementById('first-name').value} ${document.getElementById('last-name').value}`,
            gender: document.getElementById('gender').value,
            birthDate: document.getElementById('birth-date').value,
            phone: document.getElementById('phone').value,
            email: document.getElementById('email').value,
            address: `${document.getElementById('address').value}, ${document.getElementById('city').value}`,
            report: document.getElementById('report').value,
            primaryConcern: document.getElementById('primary-concern').value,
            history: document.getElementById('history').value,
            diagnosisDate: document.getElementById('diagnosis-date').value,
            injuryDate: document.getElementById('injury-date').value,
            careStart: document.getElementById('care-start').value,
            surgeryRelated: document.querySelector('input[name="surgery"]:checked')?.value,
            medicalImages: document.getElementById('medical-images').files[0],
            description: document.getElementById('description').value,
            approach: document.getElementById('approach').value,
            frequency: document.getElementById('frequency').value,
            duration: document.getElementById('duration').value,
            procedures: document.getElementById('procedures').value,
            comments: document.getElementById('comments').value
        };

        try {
            const response = await fetch('/api/patients', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formData)
            });

            if (!response.ok) {
                throw new Error('Failed to add patient');
            }

            showNotification('Patient added successfully', 'success');
            closeAddPatientModal();
            fetchPatients(); // Refresh the patient list
        } catch (error) {
            console.error('Error adding patient:', error);
            showNotification('Error adding patient', 'error');
        }
    });
}

// Add back the doctor-only functions
function navigateToMedicalRecord() {
    // Check if user is a doctor
    const isDoctor = checkUserRole(); // Implement this function based on your authentication system
    
    if (isDoctor) {
        window.location.href = '/medical-record'; // Update this path to your medical record page
    } else {
        showNotification('Only doctors can access medical records', 'error');
    }
}

function checkUserRole() {
    // Implement this function to check if the current user is a doctor
    // This should integrate with your authentication system
    return false; // Placeholder - replace with actual role check
}

// ===== Event Listeners =====
document.addEventListener('DOMContentLoaded', () => {
    initializeNav();
    fetchPatients();
    
    // Add search input listener
    searchInput.addEventListener('input', handleSearch);
    
    // Update new patient button listener to show modal instead of redirecting
    newPatientBtn.addEventListener('click', showAddPatientModal);
});