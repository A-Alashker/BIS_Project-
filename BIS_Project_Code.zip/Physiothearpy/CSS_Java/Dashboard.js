// Navigation handling
function handleNavClick(section) {
    // Remove active class from all nav items
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    
    // Add active class to clicked nav item
    event.target.classList.add('active');
    
    // Handle navigation based on section
    switch(section) {
        case 'Dashboard':
            window.location.href = '/General_Dash';
            break;
        case 'Reservation':
            window.location.href = 'Schedule';
            break;
        case 'Patients':
            window.location.href = '/patients';
            break;
        case 'Treatments':
            window.location.href = '/treatments';
            break;
        case 'Staff':
            window.location.href = '/staff';
            break;
        case 'Medical Records':
            window.location.href = '/medical-records';
            break;
    }
}

// Notification handling
function handleNotificationClick() {
    // Add notification handling logic here
    console.log('Notification clicked');
}

// Message handling
function handleMessageClick() {
    // Add message handling logic here
    console.log('Message clicked');
}

// Avatar handling
function handleAvatarClick() {
    // Add avatar handling logic here
    console.log('Avatar clicked');
}

// View all appointments
function handleViewAll() {
    window.location.href = '/Schedule';
}

// Date change handling
function handleDateChange(date) {
    // Add date change handling logic here
    console.log('Date changed:', date);
}

// Calendar functionality
function initializeCalendar() {
    const calendar = document.getElementById('calendar');
    const monthYearDisplay = document.querySelector('.calendar-card div[style*="font-size:1.2rem"]');
    const calendarTable = document.querySelector('.calendar table tbody');
    
    // Set current date in the date input
    const today = new Date();
    calendar.valueAsDate = today;
    
    // Update month and year display
    updateMonthYearDisplay(today);
    
    // Generate calendar days
    generateCalendarDays(today);
    
    // Add event listener for date changes
    calendar.addEventListener('change', function(e) {
        const selectedDate = new Date(e.target.value);
        updateMonthYearDisplay(selectedDate);
        generateCalendarDays(selectedDate);
        fetchAppointmentsForDate(e.target.value);
    });

    // Initial fetch for today's appointments
    fetchAppointmentsForDate(today.toISOString().split('T')[0]);
}

function updateMonthYearDisplay(date) {
    const monthYearDisplay = document.querySelector('.calendar-card div[style*="font-size:1.2rem"]');
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    monthYearDisplay.textContent = `${months[date.getMonth()]}, ${date.getFullYear()}`;
}

function generateCalendarDays(date) {
    const calendarTable = document.querySelector('.calendar table tbody');
    const year = date.getFullYear();
    const month = date.getMonth();
    
    // Get first day of month and total days
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const totalDays = lastDay.getDate();
    const startingDay = firstDay.getDay() || 7; // Convert Sunday (0) to 7
    
    // Get previous month's days
    const prevMonthLastDay = new Date(year, month, 0).getDate();
    
    let html = '';
    let day = 1;
    let nextMonthDay = 1;
    
    // Generate calendar grid
    for (let i = 0; i < 6; i++) {
        html += '<tr>';
        for (let j = 1; j <= 7; j++) {
            if (i === 0 && j < startingDay) {
                // Previous month's days
                const prevDay = prevMonthLastDay - startingDay + j + 1;
                const prevMonth = month === 0 ? 11 : month - 1;
                const prevYear = month === 0 ? year - 1 : year;
                const isToday = isCurrentDay(prevYear, prevMonth, prevDay);
                html += `<td class="other-month ${isToday ? 'today' : ''}" data-date="${prevYear}-${String(prevMonth + 1).padStart(2, '0')}-${String(prevDay).padStart(2, '0')}">${prevDay}</td>`;
            } else if (day > totalDays) {
                // Next month's days
                const nextMonth = month === 11 ? 0 : month + 1;
                const nextYear = month === 11 ? year + 1 : year;
                const isToday = isCurrentDay(nextYear, nextMonth, nextMonthDay);
                html += `<td class="other-month ${isToday ? 'today' : ''}" data-date="${nextYear}-${String(nextMonth + 1).padStart(2, '0')}-${String(nextMonthDay).padStart(2, '0')}">${nextMonthDay}</td>`;
                nextMonthDay++;
            } else {
                // Current month's days
                const isToday = isCurrentDay(year, month, day);
                const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                html += `<td class="${isToday ? 'today' : ''}" data-date="${dateStr}">${day}</td>`;
                day++;
            }
        }
        html += '</tr>';
        if (day > totalDays && nextMonthDay > 7) break;
    }
    
    calendarTable.innerHTML = html;

    // Add click event listeners to all calendar days
    const calendarDays = calendarTable.querySelectorAll('td');
    calendarDays.forEach(day => {
        day.addEventListener('click', function() {
            // Remove selected class from all days
            calendarDays.forEach(d => d.classList.remove('selected'));
            // Add selected class to clicked day
            this.classList.add('selected');
            // Update the date input
            const dateInput = document.getElementById('calendar');
            dateInput.value = this.dataset.date;
            // Trigger the date change event
            const event = new Event('change');
            dateInput.dispatchEvent(event);
        });
    });
}

function isCurrentDay(year, month, day) {
    const today = new Date();
    return today.getFullYear() === year &&
           today.getMonth() === month &&
           today.getDate() === day;
}

async function fetchAppointmentsForDate(date) {
    const appointmentsContainer = document.querySelector('.view-all');
    if (!appointmentsContainer) return;

    // Show loading state
    appointmentsContainer.innerHTML = '<div class="appointments-loading"></div>';

    try {
        const response = await fetch(`/api/appointments/date/${date}`);
        const appointments = await response.json();
        renderAppointments(appointments);
    } catch (error) {
        console.error('Error fetching appointments:', error);
        appointmentsContainer.innerHTML = `
            <div class="appointment-item no-appointments">
                Error loading appointments. Please try again.
            </div>
        `;
    }
}

function renderAppointments(appointments) {
    const appointmentsContainer = document.querySelector('.view-all');
    if (!appointmentsContainer) return;

    // Update the title to show the selected date
    const date = new Date(document.getElementById('calendar').value);
    const formattedDate = date.toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
    
    let html = `
        <a href="#" onclick="handleViewAll()">View all ➤</a>
        <h2>${formattedDate} appointments</h2>
    `;

    if (appointments.length === 0) {
        html += `
            <div class="appointment-item no-appointments">
                <i class="far fa-calendar-times"></i>
                No appointments scheduled for this date
            </div>
        `;
    } else {
        appointments.forEach(app => {
            const statusClass = app.status === 'completed' ? 'completed' : 
                              app.status === 'cancelled' ? 'cancelled' : 'upcoming';
            
            const statusText = app.status === 'completed' ? 'Completed' : 
                             app.status === 'cancelled' ? 'Cancelled' : 'Upcoming';
            
            html += `
                <div class="appointment-item">
                    <div class="patient-info">
                        <span class="patient-id">#${app.patient_id}</span>
                        <span class="patient-name">${app.patient_name}</span>
                    </div>
                    <div style="display: flex; align-items: center; gap: 1rem;">
                        <span class="time-info">
                            <i class="far fa-clock"></i>
                            ${app.start.slice(0,5)} - ${app.end.slice(0,5)}
                        </span>
                        <span class="status-badge ${statusClass}">
                            ${statusText}
                        </span>
                    </div>
                </div>
            `;
        });
    }

    html += `
        <div style="text-align:right;margin-top:1.5rem;">
            <a href="#" style="color:#60a5fa;text-decoration:underline;font-size:1rem;">
                View all appointments
            </a>
        </div>
    `;

    appointmentsContainer.innerHTML = html;
}

// Initialize calendar when the page loads
document.addEventListener('DOMContentLoaded', function() {
    // Initialize existing dashboard functionality
    // ... existing initialization code ...
    
    // Initialize calendar
    initializeCalendar();
});

// Patient dropdown functionality
async function populatePatientDropdown() {
    try {
        const response = await fetch('/api/patients');
        const patients = await response.json();
        const select = document.getElementById('patient-select');
        
        // Clear existing options except the first one
        while (select.options.length > 1) {
            select.remove(1);
        }
        
        // Add patient options
        patients.forEach(patient => {
            const option = document.createElement('option');
            option.value = patient.id;
            option.textContent = patient.name;
            select.appendChild(option);
        });
    } catch (error) {
        console.error('Error loading patients:', error);
    }
}

function openAddAppointmentModal() {
    const modal = document.getElementById('addAppointmentModal');
    modal.classList.add('active');
    populatePatientDropdown();
}

// Initialize event listeners
document.addEventListener('DOMContentLoaded', function() {
    const addAppointmentBtn = document.getElementById('addAppointmentBtn');
    if (addAppointmentBtn) {
        addAppointmentBtn.addEventListener('click', openAddAppointmentModal);
    }

    const closeModal = document.getElementById('closeModal');
    if (closeModal) {
        closeModal.addEventListener('click', function() {
            const modal = document.getElementById('addAppointmentModal');
            modal.classList.remove('active');
        });
    }
});

// Add notification function if not already present
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
} 