from App import app, clinic_db
from models import Patient, Practitioner, PractitionerRole, Appointment, UserAction, DocumentReference
import pymysql

def init_database():
    try:
        # First, try to create the database if it doesn't exist
        conn = pymysql.connect(
            host='localhost',
            user='root',
            password='4720622'
        )
        with conn.cursor() as cursor:
            cursor.execute("CREATE DATABASE IF NOT EXISTS clinic_db")
        conn.close()
        print("Database created or already exists")

        # Now create the tables
        with app.app_context():
            clinic_db.create_all()
            print("Tables created successfully!")

    except Exception as e:
        print(f"Error initializing database: {str(e)}")
        print(f"Error type: {type(e)}")
        if hasattr(e, '__dict__'):
            print(f"Error details: {e.__dict__}")

if __name__ == '__main__':
    init_database() 