from App import app, clinic_db
from models import Patient, Practitioner, PractitionerRole, Appointment, UserAction, DocumentReference

def check_database():
    with app.app_context():
        try:
            # Check if tables exist
            tables = clinic_db.engine.table_names()
            print("Existing tables:", tables)
            
            # Try to query each table
            print("\nChecking Practitioner table...")
            practitioners = Practitioner.query.all()
            print(f"Found {len(practitioners)} practitioners")
            
            print("\nChecking PractitionerRole table...")
            roles = PractitionerRole.query.all()
            print(f"Found {len(roles)} roles")
            
            print("\nChecking Patient table...")
            patients = Patient.query.all()
            print(f"Found {len(patients)} patients")
            
            print("\nChecking Appointment table...")
            appointments = Appointment.query.all()
            print(f"Found {len(appointments)} appointments")
            
            print("\nChecking UserAction table...")
            actions = UserAction.query.all()
            print(f"Found {len(actions)} actions")
            
            print("\nDatabase check completed successfully!")
            
        except Exception as e:
            print(f"Error checking database: {str(e)}")
            print(f"Error type: {type(e)}")
            print(f"Error details: {e.__dict__}")

if __name__ == '__main__':
    check_database() 