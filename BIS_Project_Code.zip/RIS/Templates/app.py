from flask import Flask, jsonify, render_template, request
from flask import Flask  
from datetime import datetime
from flask import session
from flask_migrate import Migrate
from models import Ris_db , User, Patient, ImagingStudy, Appointment
from sqlalchemy import func, or_
import requests

app = Flask(__name__ , template_folder='Templates', static_folder='CSS_Java')
app.secret_key = 'mypro'

FHIR_SERVER = "http://localhost:8080/fhir"
PACS_API = "http://localhost:5001"

# Update database connection settings
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:ahmed5medo4/8@localhost/Ris_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ECHO'] = True  # Enable SQL query logging

# Initialize database
Ris_db.init_app(app)
migrate = Migrate(app, Ris_db)

# Test database connection on startup
with app.app_context():
    try:
        Ris_db.engine.connect()
        print("Database connection successful!")
    except Exception as e:
        print(f"Database connection error: {str(e)}")

@app.route('/')
def dashboard():
    return render_template('dashboard.html')

@app.route('/patients')
def patients():
    return render_template('patients.html')

@app.route('/appointments')
def appointments():
    return render_template('appointments.html')

@app.route('/orders')
def orders():
    return render_template('orders.html')

@app.route('/imaging')
def imaging():
    return render_template('imaging.html')

@app.route('/reports')
def reports():
    return render_template('reports.html')

@app.route('/admin')
def admin():
    return render_template('admin.html')

# API Routes for Image Search and Display
@app.route('/api/search/images', methods=['POST'])
def search_images():
    try:
        data = request.get_json()
        
        # Build query based on search parameters
        query = ImagingStudy.query
        
        if data.get('imageId'):
            query = query.filter(ImagingStudy.id == data['imageId'])
        
        if data.get('modality'):
            query = query.filter(ImagingStudy.modality == data['modality'])
            
        if data.get('bodyPart'):
            query = query.filter(ImagingStudy.body_part.ilike(f"%{data['bodyPart']}%"))
            
        if data.get('studyDate'):
            study_date = datetime.strptime(data['studyDate'], '%Y-%m-%d')
            query = query.filter(ImagingStudy.study_date == study_date)
            
        if data.get('status'):
            query = query.filter(ImagingStudy.status == data['status'])
        
        # Execute query and get results
        studies = query.all()
        
        # Format results
        results = []
        for study in studies:
            study_data = {
                'id': study.id,
                'modality': study.modality,
                'body_part': study.body_part,
                'study_date': study.study_date.strftime('%Y-%m-%d'),
                'status': study.status,
                'patient': {
                    'id': study.patient.id,
                    'name': f"{study.patient.first_name} {study.patient.last_name}",
                    'mrn': study.patient.mrn
                }
            }
            results.append(study_data)
        
        return jsonify({
            'success': True,
            'data': results
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/images/<int:image_id>', methods=['GET'])
def get_image(image_id):
    try:
        study = ImagingStudy.query.get_or_404(image_id)
        
        # Get image data (in a real application, this would fetch the actual image file)
        image_data = {
            'id': study.id,
            'modality': study.modality,
            'body_part': study.body_part,
            'study_date': study.study_date.strftime('%Y-%m-%d'),
            'status': study.status,
            'description': study.description,
            'patient': {
                'id': study.patient.id,
                'name': f"{study.patient.first_name} {study.patient.last_name}",
                'mrn': study.patient.mrn,
                'dob': study.patient.dob.strftime('%Y-%m-%d'),
                'gender': study.patient.gender
            }
        }
        
        return jsonify({
            'success': True,
            'data': image_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/images/<int:image_id>/update', methods=['POST'])
def update_image_status(image_id):
    try:
        data = request.get_json()
        study = ImagingStudy.query.get_or_404(image_id)
        
        if 'status' in data:
            study.status = data['status']
            
        if 'description' in data:
            study.description = data['description']
            
        Ris_db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Image updated successfully'
        })
        
    except Exception as e:
        Ris_db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# API Routes for Patients
@app.route('/api/patients', methods=['GET'])
def get_patients():
    try:
        # Test database connection
        try:
            # Try to execute a simple query
            test_query = Patient.query.first()
            print("Database connection test successful")
        except Exception as db_error:
            print(f"Database connection error: {str(db_error)}")
            return jsonify({
                'success': False,
                'error': f'Database connection error: {str(db_error)}'
            }), 500

        # Get search parameters
        search_query = request.args.get('query', '').strip()
        mrn = request.args.get('mrn', '').strip()
        
        print(f"Search parameters - query: '{search_query}', mrn: '{mrn}'")
        
        # Build query
        query = Patient.query
        
        if search_query:
            # Split the search query into parts in case it's a full name
            search_parts = search_query.split()
            
            if len(search_parts) > 1:
                # If multiple words, search for first name and last name combinations
                query = query.filter(
                    (Patient.first_name.ilike(f'%{search_parts[0]}%') & 
                     Patient.last_name.ilike(f'%{search_parts[-1]}%')) |
                    (Patient.first_name.ilike(f'%{search_parts[-1]}%') & 
                     Patient.last_name.ilike(f'%{search_parts[0]}%'))
                )
            else:
                # If single word, search in all relevant fields
                query = query.filter(
                    (Patient.first_name.ilike(f'%{search_query}%')) |
                    (Patient.last_name.ilike(f'%{search_query}%')) |
                    (Patient.mrn.ilike(f'%{search_query}%'))
                )
            print(f"Applied search filter for: {search_query}")
        
        if mrn:
            query = query.filter(Patient.mrn == mrn)
            print(f"Applied MRN filter for: {mrn}")
        
        # Execute query
        patients = query.all()
        print(f"Found {len(patients)} patients matching the search criteria")
        
        # Format results
        results = []
        for patient in patients:
            patient_data = {
                'id': patient.id,
                'mrn': patient.mrn,
                'first_name': patient.first_name,
                'last_name': patient.last_name,
                'full_name': f"{patient.first_name} {patient.last_name}",
                'dob': patient.dob.strftime('%Y-%m-%d') if patient.dob else None,
                'gender': patient.gender,
                'phone': patient.phone
            }
            results.append(patient_data)
            print(f"Added patient to results: {patient_data['full_name']}")
        
        return jsonify({
            'success': True,
            'data': results
        })
        
    except Exception as e:
        print(f"Error in get_patients: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/patients/<int:patient_id>', methods=['GET'])
def get_patient_details(patient_id):
    try:
        # Log the patient_id received
        print(f"Received request for patient details with ID: {patient_id}")

        patient = Patient.query.get_or_404(patient_id)
        print(f"Found patient: {patient.id}")
        
        # Get patient's appointments
        appointments = Appointment.query.filter_by(patient_id=patient_id).all()
        print(f"Found {len(appointments)} appointments for patient {patient_id}")

        appointments_data = [{
            'id': apt.id,
            'date': apt.appointment_date.strftime('%Y-%m-%d'), # Use appointment_date field
            'time': apt.appointment_date.strftime('%H:%M'),     # Use appointment_date field for time part
            'status': apt.status,
            'type': apt.type
        } for apt in appointments]
        
        # Get patient's imaging studies
        studies = ImagingStudy.query.filter_by(patient_id=patient_id).all()
        print(f"Found {len(studies)} imaging studies for patient {patient_id}")

        studies_data = [{
            'id': study.id,
            'modality': study.modality,
            'body_part': study.body_part,
            'study_date': study.study_date.strftime('%Y-%m-%d'),
            'status': study.status
        } for study in studies]
        
        patient_data = {
            'id': patient.id,
            'mrn': patient.mrn,
            'first_name': patient.first_name,
            'last_name': patient.last_name,
            'dob': patient.dob.strftime('%Y-%m-%d') if patient.dob else None,
            'gender': patient.gender,
            'phone': patient.phone,
            'appointments': appointments_data,
            'studies': studies_data
        }
        
        print(f"Successfully fetched details for patient {patient_id}")
        return jsonify({
            'success': True,
            'data': patient_data
        })
        
    except Exception as e:
        # Log the error for debugging
        print(f"Error fetching patient details for ID {patient_id}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/patients', methods=['POST'])
def create_patient():
    try:
        data = request.get_json()
        
        # Create new patient
        new_patient = Patient(
            mrn=data['mrn'],
            first_name=data['first_name'],
            last_name=data['last_name'],
            dob=datetime.strptime(data['dob'], '%Y-%m-%d'),
            gender=data['gender'],
            phone=data.get('phone', '')
        )
        
        Ris_db.session.add(new_patient)
        Ris_db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Patient created successfully',
            'data': {
                'id': new_patient.id,
                'mrn': new_patient.mrn
            }
        })
        
    except Exception as e:
        Ris_db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/patients/<int:patient_id>', methods=['PUT'])
def update_patient(patient_id):
    try:
        data = request.get_json()
        patient = Patient.query.get_or_404(patient_id)
        
        # Update patient data
        if 'first_name' in data:
            patient.first_name = data['first_name']
        if 'last_name' in data:
            patient.last_name = data['last_name']
        if 'dob' in data:
            patient.dob = datetime.strptime(data['dob'], '%Y-%m-%d')
        if 'gender' in data:
            patient.gender = data['gender']
        if 'phone' in data:
            patient.phone = data['phone']
        
        Ris_db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Patient updated successfully'
        })
        
    except Exception as e:
        Ris_db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/patients/<int:patient_id>', methods=['DELETE'])
def delete_patient(patient_id):
    try:
        patient = Patient.query.get_or_404(patient_id)
        
        # Check if patient has any appointments or studies
        has_appointments = Appointment.query.filter_by(patient_id=patient_id).first() is not None
        has_studies = ImagingStudy.query.filter_by(patient_id=patient_id).first() is not None
        
        if has_appointments or has_studies:
            return jsonify({
                'success': False,
                'error': 'Cannot delete patient with existing appointments or studies. Please archive the patient instead.'
            }), 400
        
        # Instead of deleting, mark as inactive
        patient.status = 'inactive'
        Ris_db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Patient archived successfully'
        })
        
    except Exception as e:
        Ris_db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# API Routes for Appointments
@app.route('/api/appointments', methods=['GET'])
def get_appointments():
    try:
        # Get search parameters from the frontend
        date = request.args.get('date')
        type = request.args.get('type')
        status = request.args.get('status')
        patient_name = request.args.get('patient_name')

        # Log received search parameters
        print(f"Received search parameters for appointments: date={date}, type={type}, status={status}, patient_name={patient_name}")

        # Build query
        query = Appointment.query

        if date:
            try:
                date_obj = datetime.strptime(date, '%Y-%m-%d').date()
                query = query.filter(func.date(Appointment.appointment_date) == date_obj)
            except ValueError:
                return jsonify({'success': False, 'error': 'Invalid date format'}), 400

        if type:
            query = query.filter(Appointment.type == type)
        if status:
            query = query.filter(Appointment.status == status)

        if patient_name:
            # Join with Patient table and filter by name
            query = query.join(Patient).filter(
                (Patient.first_name.ilike(f'%{patient_name}%')) |
                (Patient.last_name.ilike(f'%{patient_name}%'))
            )

        # Execute query and order by date
        appointments = query.order_by(Appointment.appointment_date).all()

        # Log the number of appointments found
        print(f"Found {len(appointments)} appointments")

        # Format results for the frontend
        appointments_data = []
        for apt in appointments:
            # Fetch patient details for each appointment
            patient = Patient.query.get(apt.patient_id)
            patient_name_full = f"{patient.first_name} {patient.last_name}" if patient else 'Unknown Patient'

            appointment_data = {
                'id': apt.id,
                'patient_id': apt.patient_id,
                'patient_name': patient_name_full, # Provide patient_name for the list view
                'appointment_date': apt.appointment_date.strftime('%Y-%m-%d'),
                'appointment_time': apt.appointment_date.strftime('%H:%M'), # Provide 24-hour format for internal use/frontend parsing
                'type': apt.type,
                'period': apt.period, # Assuming 'period' is still relevant, though not used in frontend HTML
                'status': apt.status
            }
            appointments_data.append(appointment_data)

        return jsonify({
            'success': True,
            'data': appointments_data
        })
    except Exception as e:
        # Log the error for debugging
        print(f"Error fetching appointments: {e}")
        # Correct error response format
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/appointments/<int:appointment_id>', methods=['GET'])
def get_appointment_details(appointment_id):
    try:
        appointment = Appointment.query.get_or_404(appointment_id)

        # Fetch patient details
        patient = Patient.query.get(appointment.patient_id)
        patient_data = {
            'id': patient.id,
            'name': f"{patient.first_name} {patient.last_name}",
            'mrn': patient.mrn,
            'dob': patient.dob.strftime('%Y-%m-%d') if patient.dob else None,
            'gender': patient.gender,
            'phone': patient.phone
        } if patient else None

        appointment_data = {
            'id': appointment.id,
            'patient_id': appointment.patient_id,
            'patient': patient_data, # Include patient data for details view
            'date': appointment.appointment_date.strftime('%Y-%m-%d'), # Provide date as 'date'
            'time': appointment.appointment_date.strftime('%I:%M %p'), # Provide time in 12-hour format with AM/PM for details view
            'type': appointment.type,
            'status': appointment.status,
            'duration_minutes': appointment.duration_minutes,
            'period': appointment.period,
            'notes': appointment.notes
        }

        return jsonify({
            'success': True,
            'data': appointment_data
        })

    except Exception as e:
        print(f"Error fetching appointment details for ID {appointment_id}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/appointments', methods=['POST'])
def create_appointment():
    try:
        data = request.get_json()
        print("Received data for creating appointment:", data)
        
        # Validate required fields
        required_fields = ['patient_id', 'appointment_date', 'appointment_time', 'type', 'period']
        for field in required_fields:
            if field not in data or not data[field]:
                 print(f"Missing or empty required field: {field}")
                 return jsonify({
                    'success': False,
                    'error': f'Missing or empty required field: {field}'
                }), 400

        # Combine date and time
        appointment_datetime_str = f"{data['appointment_date']} {data['appointment_time']}"
        try:
            appointment_datetime = datetime.strptime(
                appointment_datetime_str, 
                '%Y-%m-%d %H:%M'
            )
        except ValueError as e:
             print(f"ValueError parsing datetime '{appointment_datetime_str}': {e}")
             return jsonify({
                'success': False,
                'error': f'Invalid date or time format: {e}'
            }), 400
        
        # Validate patient_id exists
        patient = Patient.query.get(data['patient_id'])
        if not patient:
             print(f"Patient with ID {data['patient_id']} not found")
             return jsonify({
                'success': False,
                'error': f'Patient with ID {data["patient_id"]} not found'
            }), 404

        # Validate 'type' and 'period' if they are Enum types in models.py
        allowed_types = ['xray', 'ct', 'mri', 'ultrasound', 'mammography']
        if data['type'] not in allowed_types:
             print(f"Invalid modality value: {data['type']}") # Should be 'type' not 'modality'
             return jsonify({
                'success': False,
                "error": f"Invalid appointment type: {data['type']}"
            }), 400

        allowed_periods = ['morning', 'evening']
        if data['period'] not in allowed_periods:
             print(f"Invalid period value: {data['period']}") # Corrected log message
             return jsonify({
                'success': False,
                "error": f"Invalid appointment period: {data['period']}"
            }), 400

        # --- Add Conflict Checking ---
        # Check for existing appointments at the same date and time that are not cancelled
        existing_appointment = Appointment.query.filter(
            Appointment.appointment_date == appointment_datetime,
            Appointment.status != 'cancelled'
        ).first()

        if existing_appointment:
            # Optionally fetch conflicting patient name for better error message
            conflicting_patient = Patient.query.get(existing_appointment.patient_id)
            conflicting_patient_name = f"{conflicting_patient.first_name} {conflicting_patient.last_name}" if conflicting_patient else 'another patient'

            return jsonify({
                'success': False,
                'error': f'Time slot is already booked by {conflicting_patient_name} for appointment ID {existing_appointment.id}'
            }), 409 # 409 Conflict status code
        # --- End Conflict Checking ---

        new_appointment = Appointment(
            patient_id=data['patient_id'],
            appointment_date=appointment_datetime,
            type=data['type'],
            period=data['period'],
            status='scheduled' # Default status
        )
        
        Ris_db.session.add(new_appointment)
        Ris_db.session.commit()
        print("Imaging order created successfully in database") # Should be Appointment created...

        return jsonify({
            'success': True,
            'message': 'Appointment created successfully',
            'data': {
                'id': new_appointment.id,
                'date': new_appointment.appointment_date.strftime('%Y-%m-%d'),
                'time': new_appointment.appointment_date.strftime('%H:%M')
            }
        }), 201 # 201 Created status code

    except Exception as e:
        Ris_db.session.rollback()
        print(f"Error creating appointment: {e}")
        return jsonify({
            'success': False,
            'error': f'An unexpected error occurred: {str(e)}'
        }), 500

@app.route('/api/appointments/<int:appointment_id>', methods=['PUT'])
def update_appointment(appointment_id):
    try:
        data = request.get_json()
        appointment = Appointment.query.get_or_404(appointment_id)

        # Store original date and time for conflict checking if they are changed
        original_datetime = appointment.appointment_date
        new_datetime = None

        # Update appointment data based on provided fields
        if 'patient_id' in data:
            appointment.patient_id = data['patient_id']

        if 'date' in data and 'time' in data:
             # Combine date and time from frontend (expecting YYYY-MM-DD and HH:MM)
            try:
                appointment_datetime_str = f"{data['date']} {data['time']}"
                new_datetime = datetime.strptime(appointment_datetime_str, '%Y-%m-%d %H:%M')
                # Don't update yet, check for conflicts first
                # appointment.appointment_date = new_datetime
            except ValueError:
                 return jsonify({'success': False, 'error': 'Invalid date or time format'}), 400

        # Handle date and time updates separately if only one is provided (optional, but good practice)
        elif 'date' in data:
             try:
                 date_obj = datetime.strptime(data['date'], '%Y-%m-%d').date()
                 # Keep existing time, update date
                 new_datetime = datetime.combine(date_obj, appointment.appointment_date.time())
                 # Don't update yet
             except ValueError:
                 return jsonify({'success': False, 'error': 'Invalid date format'}), 400

        elif 'time' in data:
             try:
                 time_obj = datetime.strptime(data['time'], '%H:%M').time()
                 # Keep existing date, update time
                 new_datetime = datetime.combine(appointment.appointment_date.date(), time_obj)
                 # Don't update yet
             except ValueError:
                 return jsonify({'success': False, 'error': 'Invalid time format'}), 400

        if 'type' in data:
            appointment.type = data['type']
        if 'status' in data:
            if data['status'] not in ['scheduled', 'in-progress', 'completed', 'cancelled', 'no-show']:
                return jsonify({'success': False, 'error': 'Invalid status value'}), 400
            appointment.status = data['status']
        if 'duration_minutes' in data:
            appointment.duration_minutes = data['duration_minutes']
        if 'period' in data:
            appointment.period = data['period']
        if 'notes' in data:
            appointment.notes = data['notes']

        # --- Add Conflict Checking for Updates ---
        # Check for existing appointments at the *new* date and time,
        # excluding the current appointment being updated, that are not cancelled.
        if new_datetime and new_datetime != original_datetime:
            existing_appointment = Appointment.query.filter(
                Appointment.appointment_date == new_datetime,
                Appointment.id != appointment_id, # Exclude the current appointment
                Appointment.status != 'cancelled'
            ).first()

            if existing_appointment:
                 # Optionally fetch conflicting patient name for better error message
                conflicting_patient = Patient.query.get(existing_appointment.patient_id)
                conflicting_patient_name = f"{conflicting_patient.first_name} {conflicting_patient.last_name}" if conflicting_patient else 'another patient'

                return jsonify({
                    'success': False,
                    'error': f'Time slot is already booked by {conflicting_patient_name} for appointment ID {existing_appointment.id}'
                }), 409 # 409 Conflict status code

            # If no conflict, update the appointment date
            appointment.appointment_date = new_datetime
        # --- End Conflict Checking ---

        Ris_db.session.commit()

        return jsonify({
            'success': True,
            'message': 'Appointment updated successfully',
            'data': {
                 'id': appointment.id,
                 'date': appointment.appointment_date.strftime('%Y-%m-%d'),
                 'time': appointment.appointment_date.strftime('%I:%M %p'),
                 'type': appointment.type,
                 'status': appointment.status
             }
        })

    except Exception as e:
        Ris_db.session.rollback()
        print(f"Error updating appointment with ID {appointment_id}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/appointments/<int:appointment_id>', methods=['DELETE'])
def delete_appointment(appointment_id):
    try:
        appointment = Appointment.query.get_or_404(appointment_id)

        # As per previous logic, mark as cancelled instead of deleting
        appointment.status = 'cancelled'
        Ris_db.session.commit()

        return jsonify({
            'success': True,
            'message': 'Appointment cancelled successfully'
        })

    except Exception as e:
        Ris_db.session.rollback()
        print(f"Error cancelling appointment with ID {appointment_id}: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# Image Viewer API Routes
@app.route('/api/imaging/studies', methods=['GET'])
def get_imaging_studies():
    try:
        # Get search parameters
        patient_id = request.args.get('patient_id')
        modality = request.args.get('modality')
        body_part = request.args.get('body_part')
        study_date = request.args.get('study_date')
        status = request.args.get('status')
        
        # Build query
        query = ImagingStudy.query
        
        if patient_id:
            query = query.filter(ImagingStudy.patient_id == patient_id)
        if modality:
            query = query.filter(ImagingStudy.modality == modality)
        if body_part:
            query = query.filter(ImagingStudy.body_part.ilike(f'%{body_part}%'))
        if study_date:
            query = query.filter(func.date(ImagingStudy.study_date) == study_date)
        if status:
            query = query.filter(ImagingStudy.status == status)
        
        # Execute query
        studies = query.order_by(ImagingStudy.study_date.desc()).all()
        
        # Format results
        results = []
        for study in studies:
            study_data = {
                'id': study.id,
                'study_uid': study.study_uid,
                'patient': {
                    'id': study.patient.id,
                    'name': f"{study.patient.first_name} {study.patient.last_name}",
                    'mrn': study.patient.mrn,
                    'dob': study.patient.dob.strftime('%Y-%m-%d'),
                    'gender': study.patient.gender
                },
                'study_date': study.study_date.strftime('%Y-%m-%d %H:%M'),
                'modality': study.modality,
                'body_part': study.body_part,
                'description': study.description,
                'referring_physician': study.referring_physician,
                'status': study.status,
                'appointments': [{
                    'id': apt.id,
                    'date': apt.appointment_date.strftime('%Y-%m-%d'),
                    'time': apt.appointment_date.strftime('%I:%M %p'),
                    'period': apt.period,
                    'type': apt.type,
                    'status': apt.status
                } for apt in study.appointments]
            }
            results.append(study_data)
        
        return jsonify({
            'success': True,
            'data': results
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/imaging/studies/<int:study_id>', methods=['GET'])
def get_imaging_study(study_id):
    try:
        study = ImagingStudy.query.get_or_404(study_id)
        
        study_data = {
            'id': study.id,
            'study_uid': study.study_uid,
            'patient': {
                'id': study.patient.id,
                'name': f"{study.patient.first_name} {study.patient.last_name}",
                'mrn': study.patient.mrn,
                'dob': study.patient.dob.strftime('%Y-%m-%d'),
                'gender': study.patient.gender,
                'phone': study.patient.phone,
                'email': study.patient.email,
                'address': study.patient.address,
                'insurance_provider': study.patient.insurance_provider,
                'insurance_number': study.patient.insurance_number
            },
            'study_date': study.study_date.strftime('%Y-%m-%d %H:%M'),
            'modality': study.modality,
            'body_part': study.body_part,
            'description': study.description,
            'referring_physician': study.referring_physician,
            'status': study.status,
            'appointments': [{
                'id': apt.id,
                'date': apt.appointment_date.strftime('%Y-%m-%d'),
                'time': apt.appointment_date.strftime('%I:%M %p'),
                'period': apt.period,
                'type': apt.type,
                'status': apt.status,
                'duration_minutes': apt.duration_minutes,
                'notes': apt.notes
            } for apt in study.appointments]
        }
        
        return jsonify({
            'success': True,
            'data': study_data
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/imaging/studies/<int:study_id>/status', methods=['PUT'])
def update_study_status(study_id):
    try:
        data = request.get_json()
        study = ImagingStudy.query.get_or_404(study_id)
        
        if 'status' in data:
            if data['status'] not in ['scheduled', 'in-progress', 'completed', 'cancelled']:
                return jsonify({
                    'success': False,
                    'error': 'Invalid status value'
                }), 400
            study.status = data['status']
            
        if 'description' in data:
            study.description = data['description']
            
        if 'referring_physician' in data:
            study.referring_physician = data['referring_physician']
            
        Ris_db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Study updated successfully',
            'data': {
                'id': study.id,
                'status': study.status,
                'description': study.description,
                'referring_physician': study.referring_physician
            }
        })
        
    except Exception as e:
        Ris_db.session.rollback()
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/imaging/studies/<int:study_id>/images', methods=['GET'])
def get_study_images(study_id):
    try:
        study = ImagingStudy.query.get_or_404(study_id)
        
        # In a real application, this would fetch actual image data
        # For now, we'll return a placeholder based on modality
        images = [
            {
                'id': 1,
                'url': f'/static/images/{study.modality}/placeholder.jpg',
                'description': f'{study.body_part} - {study.modality.upper()} Image',
                'sequence': 1,
                'modality': study.modality,
                'body_part': study.body_part,
                'study_date': study.study_date.strftime('%Y-%m-%d %H:%M')
            }
        ]
        
        return jsonify({
            'success': True,
            'data': {
                'study_id': study.id,
                'study_uid': study.study_uid,
                'modality': study.modality,
                'body_part': study.body_part,
                'images': images
            }
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/imaging/body-parts', methods=['GET'])
def get_body_parts():
    body_parts = {
        'head': 'Head',
        'neck': 'Neck',
        'chest': 'Chest',
        'abdomen': 'Abdomen',
        'pelvis': 'Pelvis',
        'spine': 'Spine',
        'upper_limb': 'Upper Limb',
        'lower_limb': 'Lower Limb',
        'breast': 'Breast',
        'heart': 'Heart',
        'brain': 'Brain',
        'liver': 'Liver',
        'kidney': 'Kidney',
        'thyroid': 'Thyroid',
        'prostate': 'Prostate',
        'uterus': 'Uterus',
        'ovary': 'Ovary',
        'testis': 'Testis',
        'joint': 'Joint',
        'muscle': 'Muscle',
        'bone': 'Bone',
        'vessel': 'Vessel',
        'other': 'Other'
    }
    
    return jsonify({
        'success': True,
        'data': body_parts
    })

@app.route('/api/imaging/studies/search', methods=['POST'])
def search_imaging_studies():
    try:
        data = request.get_json()
        
        # Build query based on search parameters
        query = ImagingStudy.query
        
        if data.get('patient_id'):
            query = query.filter(ImagingStudy.patient_id == data['patient_id'])
        
        if data.get('modality'):
            if data['modality'] not in ['xray', 'ct', 'mri', 'ultrasound', 'mammography']:
                return jsonify({
                    'success': False,
                    'error': 'Invalid modality value'
                }), 400
            query = query.filter(ImagingStudy.modality == data['modality'])
            
        if data.get('body_part'):
            valid_body_parts = [
                'head', 'neck', 'chest', 'abdomen', 'pelvis', 'spine', 'upper_limb', 'lower_limb',
                'breast', 'heart', 'brain', 'liver', 'kidney', 'thyroid', 'prostate', 'uterus',
                'ovary', 'testis', 'joint', 'muscle', 'bone', 'vessel', 'other'
            ]
            if data['body_part'] not in valid_body_parts:
                return jsonify({
                    'success': False,
                    'error': 'Invalid body part value'
                }), 400
            query = query.filter(ImagingStudy.body_part == data['body_part'])
            
        if data.get('study_date'):
            study_date = datetime.strptime(data['study_date'], '%Y-%m-%d')
            query = query.filter(func.date(ImagingStudy.study_date) == study_date)
            
        if data.get('status'):
            if data['status'] not in ['scheduled', 'in-progress', 'completed', 'cancelled']:
                return jsonify({
                    'success': False,
                    'error': 'Invalid status value'
                }), 400
            query = query.filter(ImagingStudy.status == data['status'])
        
        # Execute query and get results
        studies = query.order_by(ImagingStudy.study_date.desc()).all()
        
        # Format results
        results = []
        for study in studies:
            study_data = {
                'id': study.id,
                'study_uid': study.study_uid,
                'patient': {
                    'id': study.patient.id,
                    'name': f"{study.patient.first_name} {study.patient.last_name}",
                    'mrn': study.patient.mrn,
                    'dob': study.patient.dob.strftime('%Y-%m-%d'),
                    'gender': study.patient.gender
                },
                'study_date': study.study_date.strftime('%Y-%m-%d %H:%M'),
                'modality': study.modality,
                'body_part': study.body_part,
                'body_part_display': study.body_part.replace('_', ' ').title(),
                'description': study.description,
                'referring_physician': study.referring_physician,
                'status': study.status,
                'appointments': [{
                    'id': apt.id,
                    'date': apt.appointment_date.strftime('%Y-%m-%d'),
                    'time': apt.appointment_date.strftime('%I:%M %p'),
                    'period': apt.period,
                    'type': apt.type,
                    'status': apt.status
                } for apt in study.appointments]
            }
            results.append(study_data)
        
        return jsonify({
            'success': True,
            'data': results
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

# API Routes for Imaging Orders
@app.route('/api/orders', methods=['GET'])
def get_imaging_orders():
    try:
        # Get search parameters from frontend
        date = request.args.get('date')
        modality = request.args.get('type') # 'type' in frontend maps to 'modality' in backend
        status = request.args.get('status')
        patient_name = request.args.get('patient_name')

        # Build query for ImagingStudy model
        query = ImagingStudy.query

        if date:
            try:
                date_obj = datetime.strptime(date, '%Y-%m-%d').date()
                query = query.filter(func.date(ImagingStudy.study_date) == date_obj)
            except ValueError:
                return jsonify({'success': False, 'error': 'Invalid date format'}), 400

        if modality:
            # Validate modality against allowed values if necessary
            # allowed_modalities = [...] # Add validation if needed
            query = query.filter(ImagingStudy.modality == modality)

        if status:
            # Validate status against allowed values if necessary
            # allowed_statuses = [...] # Add validation if needed
            query = query.filter(ImagingStudy.status == status)

        if patient_name:
            # Join with Patient table and filter by name
            query = query.join(Patient).filter(
                (Patient.first_name.ilike(f'%{patient_name}%')) |
                (Patient.last_name.ilike(f'%{patient_name}%'))
            )

        # Execute query and order by study date
        orders = query.order_by(ImagingStudy.study_date.desc()).all()

        # Format results for frontend
        orders_data = []
        for order in orders:
            # Fetch patient details
            patient = Patient.query.get(order.patient_id)
            patient_name_full = f"{patient.first_name} {patient.last_name}" if patient else 'Unknown Patient'

            # Map backend fields to frontend expected fields
            order_data = {
                'id': order.id,
                'orderId': order.study_uid, # Using study_uid as orderId
                'patientId': order.patient_id,
                'patientName': patient_name_full,
                'modality': order.modality,
                'bodyPart': order.body_part,
                'priority': 'N/A', # 'priority' field does not exist in ImagingStudy, using N/A
                'status': order.status,
                'orderedBy': order.referring_physician if order.referring_physician else 'N/A', # Using referring_physician as orderedBy
                'orderedDate': order.study_date.strftime('%Y-%m-%d') if order.study_date else 'N/A'
            }
            orders_data.append(order_data)

        return jsonify({'success': True, 'data': orders_data})

    except Exception as e:
        print(f"Error fetching imaging orders: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/orders', methods=['POST'])
def create_imaging_order():
    try:
        data = request.get_json()

        # Validate required fields for creating an imaging study (order)
        required_fields = ['patientId', 'modality', 'bodyPart', 'orderedBy'] # Using frontend names for clarity initially
        for field in required_fields:
            if field not in data or not data[field]:
                 print(f"Missing or empty required field: {field}") # Log validation failure
                 return jsonify({
                    'success': False,
                    'error': f'Missing or empty required field: {field}'
                }), 400

        # Map frontend data to backend model fields
        # Generate a simple study_uid (can be improved later)
        study_uid = f"ORD-{datetime.now().timestamp()}"
        patient_id = data['patientId']
        modality = data['modality']
        body_part = data['bodyPart']
        referring_physician = data['orderedBy']
        status = data.get('status', 'scheduled') # Default status to scheduled if not provided

        # Validate patient_id exists
        patient = Patient.query.get(patient_id)
        if not patient:
             print(f"Patient with ID {patient_id} not found") # Log patient not found
             return jsonify({
                'success': False,
                'error': f'Patient with ID {patient_id} not found'
            }), 404

        # Validate 'type' and 'period' if they are Enum types in models.py
        # (Add similar checks if other fields have specific allowed values)
        allowed_modalities = ['xray', 'ct', 'mri', 'ultrasound', 'mammography']
        if modality not in allowed_modalities:
             print(f"Invalid modality value: {modality}") # Log invalid modality
             return jsonify({
                'success': False,
                "error": f"Invalid modality value: {modality}"
            }), 400

        # Validate body_part (assuming it's an Enum or has allowed values)
        # Based on your models.py, body_part is just a String(128), so no specific enum validation needed here unless added later.
        # If you had specific allowed body parts, you'd add validation similar to modality/status.

        # Validate status
        allowed_statuses = ['scheduled', 'in-progress', 'completed', 'cancelled'] # Based on ImagingStudy model
        if status not in allowed_statuses:
             print(f"Invalid status value: {status}") # Log invalid status
             return jsonify({
                'success': False,
                'error': f'Invalid status value: {status}'
            }), 400

        # Create new ImagingStudy instance
        new_order = ImagingStudy(
            study_uid=study_uid,
            patient_id=patient_id,
            study_date=datetime.utcnow(), # Use current time as study date
            modality=modality,
            body_part=body_part,
            referring_physician=referring_physician,
            status=status
        )

        Ris_db.session.add(new_order)
        Ris_db.session.commit()

        return jsonify({
            'success': True,
            'message': 'Imaging order created successfully',
            'data': {
                'id': new_order.id,
                'orderId': new_order.study_uid
            }
        }), 201 # 201 Created status code

    except Exception as e:
        Ris_db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/orders/<int:order_id>/status', methods=['PUT'])
def update_imaging_order_status(order_id):
    try:
        data = request.get_json()

        if 'status' not in data or not data['status']:
            return jsonify({'success': False, 'error': 'Status field is required'}), 400

        order = ImagingStudy.query.get_or_404(order_id)

        # Validate the new status against allowed values in ImagingStudy model
        allowed_statuses = ['scheduled', 'in-progress', 'completed', 'cancelled'] # Based on ImagingStudy model
        if data['status'] not in allowed_statuses:
             return jsonify({
                'success': False,
                "error": f"Invalid status value: {data['status']}"
            }), 400

        order.status = data['status']
        Ris_db.session.commit()

        return jsonify({
            'success': True,
            'message': 'Imaging order status updated successfully',
            'data': {
                'id': order.id,
                'status': order.status
            }
        })

    except Exception as e:
        Ris_db.session.rollback()
        print(f"Error updating imaging order status for ID {order_id}: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/test/create-patient', methods=['POST'])
def create_test_patient():
    try:
        # Create a test patient
        test_patient = Patient(
            mrn='12345',
            first_name='John',
            last_name='Doe',
            dob=datetime.strptime('1990-01-01', '%Y-%m-%d'),
            gender='Male',
            phone='123-456-7890'
        )
        
        Ris_db.session.add(test_patient)
        Ris_db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Test patient created successfully',
            'data': {
                'id': test_patient.id,
                'mrn': test_patient.mrn,
                'name': f"{test_patient.first_name} {test_patient.last_name}"
            }
        })
        
    except Exception as e:
        Ris_db.session.rollback()
        print(f"Error creating test patient: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/test/check-patients', methods=['GET'])
def check_patients():
    try:
        patients = Patient.query.all()
        return jsonify({
            'success': True,
            'count': len(patients),
            'patients': [{
                'id': p.id,
                'mrn': p.mrn,
                'name': f"{p.first_name} {p.last_name}"
            } for p in patients]
        })
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500

@app.route('/api/init-db', methods=['POST'])
def initialize_database():
    try:
        # Create test patients
        test_patients = [
            Patient(
                mrn='12345',
                first_name='John',
                last_name='Doe',
                dob=datetime.strptime('1990-01-01', '%Y-%m-%d'),
                gender='Male',
                phone='123-456-7890'
            ),
            Patient(
                mrn='67890',
                first_name='Jane',
                last_name='Smith',
                dob=datetime.strptime('1985-05-15', '%Y-%m-%d'),
                gender='Female',
                phone='987-654-3210'
            )
        ]
        
        # Add patients to database
        for patient in test_patients:
            Ris_db.session.add(patient)
        
        Ris_db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Database initialized with test data',
            'data': {
                'patients_added': len(test_patients)
            }
        })
        
    except Exception as e:
        Ris_db.session.rollback()
        print(f"Error initializing database: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500



def sync_all_patients_to_fhir():
    print("Starting RIS -> PACS -> FHIR sync...")

    # Step 1: Get all patients from PACS
    patients = requests.get(f"{PACS_API}/api/patients").json()

    for patient in patients:
        mrn = patient["mrn"]
        print(f"Syncing patient MRN={mrn}...")

        # Step 2: Get all studies/images for this patient
        study_response = requests.get(f"{PACS_API}/by-patient/{mrn}")
        if study_response.status_code != 200:
            print(f"Failed to fetch studies for patient MRN={mrn}")
            continue

        studies_data = study_response.json()
        for study_bundle in studies_data:
            study = study_bundle["study"]
            images = study_bundle["images"]

            imaging_study = {
                "resourceType": "ImagingStudy",
                "status": "available",
                "subject": {
                    "identifier": {
                        
                        "value": mrn
                    }
                },
                "started": study["study_date"],
                "modality": [{
                    
                    "code": study["modality"]
                }],
                "description": study["description"],
                "identifier": [{
                    "system": "urn:dicom:uid",
                    "value": study["study_uid"]
                }],
                "series": [{
                    "uid": study["study_uid"],
                    "instance": [
                        {"uid": f"{study['study_uid']}.{img['sop_instance_uid']}"}
                        for img in images
                    ]
                }]
            }

            fhir_response = requests.post(f"{FHIR_SERVER}/ImagingStudy", json=imaging_study)
            print(f"Uploaded ImagingStudy for MRN={mrn}: {fhir_response.status_code}")

            # Step 4: Upload images as Media
            for img in images:
                media_resource = {
                    "resourceType": "Media",
                    "status": "completed",
                    "subject": {
                        "identifier": {
                            "value": mrn
                        }
                    },
                    "content": {
                        "contentType": "image/jpeg",
                        "url": img["url"]  # assumes PACS includes `url` in JSON
                    }
                }
                media_response = requests.post(f"{FHIR_SERVER}/Media", json=media_resource)
                print(f"Uploaded Media for SOP UID {img['sop_instance_uid']} MRN={mrn}: {media_response.status_code}")

# @app.route('/sync', methods=['POST'])
# def sync_all_patients_to_fhir(identifier):
#     print("Starting RIS -> PACS -> FHIR sync...")

#     # Step 1: Get all patients from PACS
#     patients = requests.get(f"{PACS_API}/api/patients").json()

#     for patient in patients:
#         mrn = patient["mrn"]
#         print(f"Syncing patient MRN={mrn}...")

#         # Step 2: Get all studies/images for this patient
#         study_response = requests.get(f"{PACS_API}/by-patient/{mrn}")
#         if study_response.status_code != 200:
#             print(f"Failed to fetch studies for patient MRN={mrn}")
#             continue

#         studies_data = study_response.json()
#         for study_bundle in studies_data:
#             study = study_bundle["study"]
#             images = study_bundle["images"]

#             imaging_study = {
#                 "resourceType": "ImagingStudy",
#                 "status": "available",
#                 "subject": {
#                     "identifier": {
#                         "value": mrn
#                     }
#                 },
#                 "started": study["study_date"],
#                 "modality": [{
#                     "code": study["modality"]
#                 }],
#                 "description": study["description"],
#                 "identifier": [{
#                     "system": "urn:dicom:uid",
#                     "value": study["study_uid"]
#                 }],
#                 "series": [{
#                     "uid": study["study_uid"],
#                     "instance": [
#                         {"uid": f"{study['study_uid']}.{img['sop_instance_uid']}"}
#                         for img in images
#                     ]
#                 }]
#             }

#             fhir_response = requests.post(f"{FHIR_SERVER}", json=imaging_study)
#             print(f"Uploaded ImagingStudy for MRN={mrn}: {fhir_response.status_code}")

#             # Step 4: Upload images as Media
#             for img in images:
#                 media_resource = {
#                     "resourceType": "Media",
#                     "status": "completed",
#                     "subject": {
#                         "identifier": {
#                             "value": mrn
#                         }
#                     },
#                     "identifier": [  # Add the identifier for easy lookup and matching
#                         {
#                             "system": "urn:dicom:sop",
#                             "value": img["sop_instance_uid"]
#                         }
#                     ],
#                     "content": {
#                         "contentType": "image/jpeg",
#                         "url": img["url"]
#                     }
#                 }
#                 media_response = requests.post(f"{FHIR_SERVER}", json=media_resource)
#                 print(f"Uploaded Media for SOP UID {img['sop_instance_uid']} MRN={mrn}: {media_response.status_code}")
#                 if media_response.ok:
#                     media_data = media_response.json()
#                     # If a target_identifier is given, return the id if it matches
#                     if (
#                         identifier 
#                         and any(
#                             ident.get("value") == identifier 
#                             for ident in media_resource.get("identifier", [])
#                         )
#                     ):
#                         return media_data.get("id")
#     return None



if __name__ == '__main__':
    from threading import Thread
    from time import sleep

    def delayed_sync():
        # Give the server a few seconds to start before syncing
        sleep(3)

        sync_all_patients_to_fhir()

    Thread(target=delayed_sync).start()
    app.run(debug=True, port=5002)


# if __name__ == '__main__':
#     app.run(debug=True) 