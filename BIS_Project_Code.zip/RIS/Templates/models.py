# models.py
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

Ris_db = SQLAlchemy()

class User(Ris_db.Model):
    __tablename__ = 'users'
    
    id = Ris_db.Column(Ris_db.Integer, primary_key=True)
    username = Ris_db.Column(Ris_db.String(64), unique=True, nullable=False)
    password_hash = Ris_db.Column(Ris_db.String(128), nullable=False)
    name = Ris_db.Column(Ris_db.String(128), nullable=False)
    email = Ris_db.Column(Ris_db.String(128), unique=True, nullable=False)
    role = Ris_db.Column(Ris_db.Enum('admin', 'radiologist', 'technician', 'receptionist'), nullable=False)
    status = Ris_db.Column(Ris_db.Enum('active', 'inactive'), nullable=False, default='active')
    last_login = Ris_db.Column(Ris_db.DateTime)
    created_at = Ris_db.Column(Ris_db.DateTime, default=datetime.utcnow)


class Patient(Ris_db.Model):
    __tablename__ = 'patients'

    id = Ris_db.Column(Ris_db.Integer, primary_key=True)
    identifier = Ris_db.Column(Ris_db.String(64), unique=True, nullable=False)
    first_name = Ris_db.Column(Ris_db.String(64), nullable=False)
    last_name = Ris_db.Column(Ris_db.String(64), nullable=False)
    dob = Ris_db.Column(Ris_db.Date, nullable=False)
    gender = Ris_db.Column(Ris_db.Enum('male', 'female', 'other'))
    phone = Ris_db.Column(Ris_db.String(20))
    email = Ris_db.Column(Ris_db.String(128))
    address = Ris_db.Column(Ris_db.String(255))
    insurance_provider = Ris_db.Column(Ris_db.String(128))
    insurance_number = Ris_db.Column(Ris_db.String(64))
    created_at = Ris_db.Column(Ris_db.DateTime, default=datetime.utcnow)

    studies = Ris_db.relationship('ImagingStudy', backref='patient', cascade='all, delete-orphan')
    appointments = Ris_db.relationship('Appointment', backref='patient', cascade='all, delete-orphan')


class ImagingStudy(Ris_db.Model):
    __tablename__ = 'imaging_studies'

    id = Ris_db.Column(Ris_db.Integer, primary_key=True)
    study_uid = Ris_db.Column(Ris_db.String(128), unique=True, nullable=False)
    patient_id = Ris_db.Column(Ris_db.Integer, Ris_db.ForeignKey('patients.id'), nullable=False)
    study_date = Ris_db.Column(Ris_db.DateTime, nullable=False)
    modality = Ris_db.Column(Ris_db.Enum('xray', 'ct', 'mri', 'ultrasound', 'mammography'), nullable=False)
    body_part = Ris_db.Column(Ris_db.String(128), nullable=False)
    description = Ris_db.Column(Ris_db.String(255))
    referring_physician = Ris_db.Column(Ris_db.String(128))
    status = Ris_db.Column(Ris_db.Enum('scheduled', 'in-progress', 'completed', 'cancelled'), nullable=False)

    appointments = Ris_db.relationship('Appointment', backref='study', cascade='all, delete-orphan')


class Appointment(Ris_db.Model):
    __tablename__ = 'appointments'

    id = Ris_db.Column(Ris_db.Integer, primary_key=True)
    patient_id = Ris_db.Column(Ris_db.Integer, Ris_db.ForeignKey('patients.id'), nullable=False)
    study_id = Ris_db.Column(Ris_db.Integer, Ris_db.ForeignKey('imaging_studies.id'), nullable=True)
    appointment_date = Ris_db.Column(Ris_db.DateTime, nullable=False)
    duration_minutes = Ris_db.Column(Ris_db.Integer, default=30)
    period = Ris_db.Column(Ris_db.Enum('morning', 'evening'), nullable=False, default='morning')
    type = Ris_db.Column(Ris_db.Enum('xray', 'ct', 'mri', 'ultrasound', 'mammography'), nullable=False, default='xray')
    status = Ris_db.Column(Ris_db.Enum('scheduled', 'completed', 'cancelled', 'no-show'), nullable=False)
    notes = Ris_db.Column(Ris_db.Text)

