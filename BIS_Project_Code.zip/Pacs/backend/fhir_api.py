# from flask import Blueprint, jsonify, request, g
# from .extensions import db, auth
# from .imaging_studies import ImagingStudy
# from .patients import Patient
# from fhir.resources.imagingstudy import ImagingStudy as FHIRImagingStudy
# from fhir.resources.patient import Patient as FHIRPatient
# from datetime import datetime

# fhir_bp = Blueprint('fhir', __name__)

# @fhir_bp.route('/fhir/ImagingStudy/<study_id>', methods=['GET'])
# @auth.login_required
# def get_imaging_study(study_id):
#     study = ImagingStudy.query.get_or_404(study_id)
    
#     fhir_study = FHIRImagingStudy(
#         id=str(study.id),
#         status="available",
#         subject={"reference": f"Patient/{study.patient_id}"},
#         started=study.study_date.isoformat(),
#         numberOfSeries=len(study.series),
#         description=study.description
#     )
    
#     return jsonify(fhir_study.dict())

# @fhir_bp.route('/fhir/Patient/<patient_id>', methods=['GET'])
# @auth.login_required
# def get_patient(patient_id):
#     patient = Patient.query.get_or_404(patient_id)
    
#     fhir_patient = FHIRPatient(
#         id=str(patient.id),
#         name=[{
#             "use": "official",
#             "family": patient.last_name,
#             "given": [patient.first_name]
#         }],
#         birthDate=patient.date_of_birth.isoformat(),
#         gender=patient.gender
#     )
    
#     return jsonify(fhir_patient.dict())






# @app.route('/api/users', methods=['POST'])
# # @auth.login_required
# def create_user():
#     if g.current_user.role != 'admin':
#         return jsonify({'error': 'Unauthorized'}), 403
#     data = request.json
#     if not data:
#         return jsonify({'error': 'Missing JSON data'}), 400
#     try:
#         password_hash = bcrypt.generate_password_hash(data['password']).decode('utf-8')
#         user = User()
#         user.username = data['username']
#         setattr(user, 'password_hash', password_hash)
#         user.name = data['name']
#         user.email = data['email']
#         user.role = data['role']
#         user.status = data.get('status', 'active')
#         db.session.add(user)
#         db.session.commit()
#         return jsonify({'message': 'User created', 'user_id': user.id}), 201
#     except IntegrityError:
#         db.session.rollback()
#         return jsonify({'error': 'Username or email already exists'}), 400

# @app.route('/api/users', methods=['GET'])
# @auth.login_required
# def list_users():
#     if g.current_user.role != 'admin':
#         return jsonify({'error': 'Unauthorized'}), 403
#     users = User.query.all()
#     result = []
#     for user in users:
#         result.append({
#             'id': user.id,
#             'username': user.username,
#             'name': user.name,
#             'email': user.email,
#             'role': user.role,
#             'status': user.status,
#             'last_login': user.last_login,
#             'created_at': user.created_at
#         })
#     return jsonify(result)
