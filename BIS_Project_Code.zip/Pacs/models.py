from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date, time
import enum
import io

pacs_db = SQLAlchemy()

class Gender(enum.Enum):
    M = "Male"
    F = "Female"
    O = "Other"

    @classmethod
    def _missing_(cls, value):
        """Handle string values for gender"""
        if isinstance(value, str):
            value = value.upper()
            if value in ['M', 'MALE', 'MALE']:
                return cls.M
            elif value in ['F', 'FEMALE', 'FEMALE']:
                return cls.F
            elif value in ['O', 'OTHER', 'OTHER']:
                return cls.O
        return None

    def __str__(self):
        return self.value

    @classmethod
    def from_string(cls, value):
        """Convert string to Gender enum"""
        if not value:
            return None
        value = str(value).upper()
        if value in ['M', 'MALE', 'MALE']:
            return cls.M
        elif value in ['F', 'FEMALE', 'FEMALE']:
            return cls.F
        elif value in ['O', 'OTHER', 'OTHER']:
            return cls.O
        return None

# PRACTITIONER
class Practitioner(pacs_db.Model):
    __tablename__ = 'practitioners'
    id = pacs_db.Column(pacs_db.Integer, primary_key=True)
    name = pacs_db.Column(pacs_db.String(100), nullable=False)
    email = pacs_db.Column(pacs_db.String(100), unique=True)
    contact_number = pacs_db.Column(pacs_db.String(11), unique=True)
    password = pacs_db.Column(pacs_db.String(255), nullable=False)
    created_at = pacs_db.Column(pacs_db.DateTime, default=datetime.utcnow)
    last_login = pacs_db.Column(pacs_db.DateTime)

class Patient(pacs_db.Model):
    __tablename__ = 'patients'
    id = pacs_db.Column(pacs_db.Integer, primary_key=True)
    mrn = pacs_db.Column(pacs_db.String(50), unique=True, nullable=False)
    first_name = pacs_db.Column(pacs_db.String(50), nullable=False)
    last_name = pacs_db.Column(pacs_db.String(50), nullable=False)
    dob = pacs_db.Column(pacs_db.Date, nullable=False)
    _gender = pacs_db.Column('gender', pacs_db.String(10), nullable=False)
    email = pacs_db.Column(pacs_db.String(100))
    phone = pacs_db.Column(pacs_db.String(20))
    address = pacs_db.Column(pacs_db.String(200))
    created_at = pacs_db.Column(pacs_db.DateTime, default=datetime.utcnow)
    updated_at = pacs_db.Column(pacs_db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    imaging_studies = pacs_db.relationship('ImagingStudy', backref='patient', lazy=True)

    @property
    def gender(self):
        """Get gender as enum"""
        if not self._gender:
            return Gender.O
        value = str(self._gender).upper()
        if value in ['M', 'MALE', 'MALE']:
            return Gender.M
        elif value in ['F', 'FEMALE', 'FEMALE']:
            return Gender.F
        elif value in ['O', 'OTHER', 'OTHER']:
            return Gender.O
        return Gender.O

    @gender.setter
    def gender(self, value):
        """Set gender from enum or string"""
        if isinstance(value, Gender):
            self._gender = value.name
        elif isinstance(value, str):
            value = value.upper()
            if value in ['M', 'MALE', 'MALE']:
                self._gender = 'M'
            elif value in ['F', 'FEMALE', 'FEMALE']:
                self._gender = 'F'
            elif value in ['O', 'OTHER', 'OTHER']:
                self._gender = 'O'
            else:
                self._gender = 'O'
        else:
            self._gender = 'O'

class ImagingStudy(pacs_db.Model):
    __tablename__ = 'imaging_studies'
    id = pacs_db.Column(pacs_db.Integer, primary_key=True)
    patient_id = pacs_db.Column(pacs_db.Integer, pacs_db.ForeignKey('patients.id'), nullable=False)
    study_uid = pacs_db.Column(pacs_db.String(64), unique=True, nullable=False)
    study_date = pacs_db.Column(pacs_db.DateTime, nullable=False)
    modality = pacs_db.Column(pacs_db.String(10), nullable=False)
    study_description = pacs_db.Column(pacs_db.String(200))
    referring_physician = pacs_db.Column(pacs_db.String(100))
    created_at = pacs_db.Column(pacs_db.DateTime, default=datetime.utcnow)
    images = pacs_db.relationship('DicomImage', backref='study', lazy=True)

class DicomImage(pacs_db.Model):
    __tablename__ = 'dicom_images'
    id = pacs_db.Column(pacs_db.Integer, primary_key=True)
    study_id = pacs_db.Column(pacs_db.Integer, pacs_db.ForeignKey('imaging_studies.id'), nullable=False)
    compressed_data = pacs_db.Column(pacs_db.LargeBinary, nullable=False)  # Store compressed binary data
    sop_instance_uid = pacs_db.Column(pacs_db.String(255), unique=True, nullable=False)
    
    # Compression related fields
    compression_method = pacs_db.Column(pacs_db.String(50), nullable=True)
    original_size = pacs_db.Column(pacs_db.BigInteger, nullable=True)
    compressed_size = pacs_db.Column(pacs_db.BigInteger, nullable=True)
    compression_ratio = pacs_db.Column(pacs_db.Float, nullable=True)
    compression_date = pacs_db.Column(pacs_db.Date, nullable=True)
    compression_time = pacs_db.Column(pacs_db.Time, nullable=True)
    
    # DICOM metadata
    series_number = pacs_db.Column(pacs_db.Integer)
    instance_number = pacs_db.Column(pacs_db.Integer)
    image_type = pacs_db.Column(pacs_db.String(50))
    acquisition_date = pacs_db.Column(pacs_db.DateTime)
    
    # Additional DICOM metadata
    rows = pacs_db.Column(pacs_db.Integer)
    columns = pacs_db.Column(pacs_db.Integer)
    samples_per_pixel = pacs_db.Column(pacs_db.Integer)
    photometric_interpretation = pacs_db.Column(pacs_db.String(50))
    bits_allocated = pacs_db.Column(pacs_db.Integer)
    bits_stored = pacs_db.Column(pacs_db.Integer)
    high_bit = pacs_db.Column(pacs_db.Integer)
    
    # Processing status
    processed = pacs_db.Column(pacs_db.Boolean, default=False)
    processing_results = pacs_db.Column(pacs_db.JSON)
    created_at = pacs_db.Column(pacs_db.DateTime, default=datetime.utcnow)
    
    def get_compression_info(self):
        """Get compression information as dictionary"""
        return {
            'method': self.compression_method,
            'original_size': self.original_size,
            'compressed_size': self.compressed_size,
            'ratio': self.compression_ratio,
            'date': self.compression_date.strftime('%Y-%m-%d') if self.compression_date else None,
            'time': self.compression_time.strftime('%H:%M:%S') if self.compression_time else None
        }
    
    def is_compressed(self):
        """Check if image is compressed"""
        return self.compression_method is not None and self.compressed_size is not None



