import pydicom
import numpy as np
from compact import compact_compress, compact_decompress
import os
import io
import uuid
from datetime import datetime
import zlib

class CompressionError(Exception):
    """Custom exception for compression errors"""
    pass

def get_compression_ratio(original_size, compressed_size):
    """Calculate compression ratio"""
    if compressed_size == 0:
        return 0
    return (original_size - compressed_size) / original_size * 100

def compress_dicom(dicom_data):
    """
    Compress DICOM data and return compressed binary data
    Args:
        dicom_data: Binary DICOM data or file path
    Returns:
        dict containing compressed data and metadata
    """
    try:
        # Read DICOM data
        if isinstance(dicom_data, str):
            ds = pydicom.dcmread(dicom_data)
            original_size = os.path.getsize(dicom_data)
        else:
            ds = pydicom.dcmread(io.BytesIO(dicom_data))
            original_size = len(dicom_data)
            
        print("DICOM data read successfully")
        
        # Get pixel array and metadata
        image = ds.pixel_array.astype(np.uint16)
        shape = image.shape
        dtype = str(image.dtype)
        
        # Apply Hilbert curve transformation
        from compact import hilbert_ordering, apply_hilbert, delta_encode, encode_to_bytes
        
        h_image = apply_hilbert(image).flatten()
        
        # Delta encoding
        encoded = delta_encode(h_image)
        byte_stream = encode_to_bytes(encoded)
        
        # Compress the data
        compressed = zlib.compress(byte_stream)
        compressed_size = len(compressed)
        
        # Create compressed data structure
        header = {
            'shape': shape,
            'dtype': dtype,
            'rows': ds.Rows,
            'columns': ds.Columns,
            'samples_per_pixel': ds.SamplesPerPixel,
            'photometric_interpretation': ds.PhotometricInterpretation,
            'bits_allocated': ds.BitsAllocated,
            'bits_stored': ds.BitsStored,
            'high_bit': ds.HighBit
        }
        
        # Convert header to bytes
        header_bytes = str(header).encode('utf-8')
        header_size = len(header_bytes).to_bytes(4, 'big')
        
        # Combine header and compressed data
        final_data = header_size + header_bytes + compressed
        
        compression_ratio = get_compression_ratio(original_size, compressed_size)
        print(f"Compression completed. Ratio: {compression_ratio:.2f}%")
        
        return {
            'compressed_data': final_data,
            'original_size': original_size,
            'compressed_size': compressed_size,
            'compression_ratio': compression_ratio,
            'metadata': header
        }
        
    except Exception as e:
        print(f"Compression error: {str(e)}")
        import traceback
        print(f"Traceback: {traceback.format_exc()}")
        raise CompressionError(f"Error compressing DICOM data: {str(e)}")

def decompress_dicom(compressed_data):
    """
    Decompress DICOM data from binary format
    Args:
        compressed_data: Binary compressed data
    Returns:
        numpy array of pixel data and metadata dictionary
    """
    try:
        # Read header size and header
        header_size = int.from_bytes(compressed_data[:4], 'big')
        header_str = compressed_data[4:4+header_size].decode('utf-8')
        header = eval(header_str)  # Convert string back to dictionary
        
        # Get compressed data
        compressed = compressed_data[4+header_size:]
        
        # Decompress data
        from compact import decode_from_bytes, delta_decode, reverse_hilbert
        
        byte_stream = zlib.decompress(compressed)
        encoded_stream = decode_from_bytes(byte_stream)
        flat_pixels = delta_decode(encoded_stream)
        
        # Reverse Hilbert curve transformation
        recovered_image = reverse_hilbert(flat_pixels, header['shape'])
        
        # Ensure correct data type
        recovered_image = recovered_image.astype(header['dtype'])
        
        return recovered_image, header
        
    except Exception as e:
        raise CompressionError(f"Error decompressing DICOM data: {str(e)}")

def get_compression_info(compressed_data):
    """
    Get compression information from compressed data
    """
    try:
        header_size = int.from_bytes(compressed_data[:4], 'big')
        header_str = compressed_data[4:4+header_size].decode('utf-8')
        header = eval(header_str)
        
        return header
        
    except Exception as e:
        raise CompressionError(f"Error getting compression info: {str(e)}")

def cleanup_temp_files(file_paths):
    """
    Clean up temporary files
    """
    for path in file_paths:
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception as e:
            print(f"Error cleaning up file {path}: {str(e)}") 