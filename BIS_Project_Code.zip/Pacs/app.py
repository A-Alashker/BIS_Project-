from flask import Flask, jsonify, render_template, request, redirect, url_for, flash, send_file
from datetime import datetime, timedelta
from flask import session
from flask_migrate import Migrate
from models import pacs_db, Patient, DicomImage, Practitioner, ImagingStudy, Gender
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from typing import Optional, cast
from werkzeug.utils import secure_filename
import os
import uuid
import pydicom
from PIL import Image
import io
import numpy as np
from config import Config
from compression import CompressionError, compress_dicom, decompress_dicom, cleanup_temp_files
from flask_session import Session
from flask_cors import CORS

# Configure upload folder
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
ALLOWED_EXTENSIONS = {'.dcm'}
MAX_CONTENT_LENGTH = 32 * 1024 * 1024  # 32MB max file size

PACS_API = "http://localhost:5001"

app = Flask(__name__, template_folder='frontend')
app.config.from_object(Config)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['SECRET_KEY'] = os.urandom(24)  # Generate a secure secret key
app.config['SESSION_TYPE'] = 'filesystem'
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=1)
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH
CORS(app)

# Create necessary directories
try:
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    print(f"Upload directory created/verified at: {UPLOAD_FOLDER}")
except Exception as e:
    print(f"Error creating upload directory: {str(e)}")
    raise

pacs_db.init_app(app)
migrate = Migrate(app, pacs_db)

# Initialize session
Session(app)

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Please log in first.', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def home():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name: Optional[str] = request.form.get('name')
        email: Optional[str] = request.form.get('email')
        password: Optional[str] = request.form.get('password')
        contact_number: Optional[str] = request.form.get('contact_number')

        if not all([name, email, password, contact_number]):
            flash('All fields are required', 'error')
            return redirect(url_for('signup'))

        if Practitioner.query.filter_by(email=email).first():
            flash('Email already registered', 'error')
            return redirect(url_for('signup'))

        # Cast Optional types to str since we've verified they're not None
        name_str = cast(str, name)
        email_str = cast(str, email)
        password_str = cast(str, password)
        contact_number_str = cast(str, contact_number)

        try:
            new_practitioner = Practitioner()
            new_practitioner.name = name_str
            new_practitioner.email = email_str
            new_practitioner.password = generate_password_hash(password_str)
            new_practitioner.contact_number = contact_number_str

            pacs_db.session.add(new_practitioner)
            pacs_db.session.commit()
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('login'))
        except Exception as e:
            pacs_db.session.rollback()
            flash('An error occurred. Please try again.', 'error')
            return redirect(url_for('signup'))

    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        try:
            print("Login attempt started")
            email: Optional[str] = request.form.get('email')
            password: Optional[str] = request.form.get('password')
            
            print(f"Login attempt for email: {email}")
            
            if not all([email, password]):
                print("Missing email or password")
                flash('Email and password are required', 'error')
                return redirect(url_for('login'))
            
            practitioner = Practitioner.query.filter_by(email=email).first()
            
            if not practitioner:
                print(f"No practitioner found for email: {email}")
                flash('Invalid email or password', 'error')
                return redirect(url_for('login'))
            
            print(f"Found practitioner: {practitioner.name}")
            
            # Cast password to str since we've verified it's not None
            password_str = cast(str, password)
            
            if check_password_hash(practitioner.password, password_str):
                print("Password verified successfully")
                session['user_id'] = practitioner.id
                session['user_name'] = practitioner.name
                practitioner.last_login = datetime.utcnow()
                pacs_db.session.commit()
                print("Login successful, redirecting to dashboard")
                return redirect(url_for('dashboard'))
            
            print("Invalid password")
            flash('Invalid email or password', 'error')
            return redirect(url_for('login'))
            
        except Exception as e:
            print(f"Login error details: {str(e)}")
            print(f"Error type: {type(e)}")
            import traceback
            print(f"Traceback: {traceback.format_exc()}")
            pacs_db.session.rollback()
            flash('An error occurred during login. Please try again.', 'error')
            return redirect(url_for('login'))
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))

@app.route('/dashboard')
@login_required
def dashboard():
    try:
        # Get total counts
        total_patients = Patient.query.count()
        total_studies = ImagingStudy.query.count()
        total_images = DicomImage.query.count()
        
        # Calculate storage used (in GB)
        storage_used = "0 GB"  # This should be implemented based on actual file sizes
        
        # Get recent patients
        recent_patients = Patient.query.order_by(Patient.created_at.desc()).limit(5).all()
        
        # Get recent studies
        recent_studies = ImagingStudy.query.order_by(ImagingStudy.study_date.desc()).limit(5).all()
        
        return render_template('dashboard.html',
                             total_patients=total_patients,
                             total_studies=total_studies,
                             total_images=total_images,
                             storage_used=storage_used,
                             recent_patients=recent_patients,
                             recent_studies=recent_studies)
    except Exception as e:
        print(f"Dashboard error: {str(e)}")
        pacs_db.session.rollback()
        flash('An error occurred while loading the dashboard', 'error')
        return redirect(url_for('login'))

@app.route('/patients')
@login_required
def patients():
    patients = Patient.query.all()
    return render_template('patients.html', patients=patients)

@app.route('/patients', methods=['POST'])
@login_required
def add_patient():
    try:
        data = request.form
        new_patient = Patient()
        
        # Required fields
        new_patient.mrn = data['mrn']
        new_patient.first_name = data['first_name']
        new_patient.last_name = data['last_name']
        new_patient.dob = datetime.strptime(data['dob'], '%Y-%m-%d').date()
        new_patient.gender = Gender[data['gender']]  # Convert string to enum
        
        # Optional fields
        if 'email' in data and data['email']:
            new_patient.email = data['email']
        if 'phone' in data and data['phone']:
            new_patient.phone = data['phone']
        if 'address' in data and data['address']:
            new_patient.address = data['address']
        
        pacs_db.session.add(new_patient)
        pacs_db.session.commit()
        flash('Patient added successfully', 'success')
    except Exception as e:
        pacs_db.session.rollback()
        flash(f'Error adding patient: {str(e)}', 'error')
        print(f"Error adding patient: {str(e)}")
    return redirect(url_for('patients'))

@app.route('/patients/<int:patient_id>', methods=['DELETE'])
@login_required
def delete_patient(patient_id):
    try:
        patient = Patient.query.get_or_404(patient_id)
        pacs_db.session.delete(patient)
        pacs_db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        pacs_db.session.rollback()
        return jsonify({'success': False, 'error': str(e)})

@app.route('/patients/<int:patient_id>', methods=['GET'])
@login_required
def get_patient(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    return jsonify({
        'id': patient.id,
        'mrn': patient.mrn,
        'first_name': patient.first_name,
        'last_name': patient.last_name,
        'dob': patient.dob.strftime('%Y-%m-%d'),
        'gender': patient.gender.value,
        'email': patient.email,
        'phone': patient.phone,
        'address': patient.address
    })

@app.route('/patients/<int:patient_id>', methods=['PUT'])
@login_required
def update_patient(patient_id):
    try:
        patient = Patient.query.get_or_404(patient_id)
        data = request.get_json()
        
        patient.first_name = data.get('first_name', patient.first_name)
        patient.last_name = data.get('last_name', patient.last_name)
        if 'dob' in data:
            patient.dob = datetime.strptime(data['dob'], '%Y-%m-%d').date()
        patient.gender = data.get('gender', patient.gender)
        patient.email = data.get('email', patient.email)
        patient.phone = data.get('phone', patient.phone)
        patient.address = data.get('address', patient.address)
        
        pacs_db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        pacs_db.session.rollback()
        return jsonify({'success': False, 'error': str(e)})

@app.route('/images')
@login_required
def images():
    images = DicomImage.query.all()
    return render_template('images.html', images=images)

@app.route('/studies')
@login_required
def studies():
    patient_id = request.args.get('patient_id', type=int)
    if patient_id:
        patient = Patient.query.get_or_404(patient_id)
        studies = ImagingStudy.query.filter_by(patient_id=patient_id).all()
        all_patients = None
    else:
        patient = None
        studies = ImagingStudy.query.all()
        all_patients = Patient.query.all()
    
    return render_template('studies.html',
                         studies=studies,
                         patient=patient,
                         all_patients=all_patients)

@app.route('/studies', methods=['POST'])
@login_required
def add_study():
    try:
        # Validate form data
        if 'patient_id' not in request.form:
            raise ValueError("Missing patient_id in form data")
        if 'study_date' not in request.form:
            raise ValueError("Missing study_date in form data")
        if 'modality' not in request.form:
            raise ValueError("Missing modality in form data")
        if 'dicom_files' not in request.files:
            raise ValueError("No DICOM files uploaded")
            
        files = request.files.getlist('dicom_files')
        if not files or not files[0].filename:
            raise ValueError("No files selected")
            
        print(f"Received {len(files)} files")
        
        # Create new study
        study = ImagingStudy()
        study.patient_id = int(request.form['patient_id'])
        study.study_date = datetime.strptime(request.form['study_date'], '%Y-%m-%dT%H:%M')
        study.modality = request.form['modality']
        study.study_description = request.form.get('study_description', '')
        study.referring_physician = request.form.get('referring_physician', '')
        study.study_uid = f"{study.patient_id}.{uuid.uuid4()}"
        
        print(f"Created study with UID: {study.study_uid}")
        
        # Save study first to get its ID
        pacs_db.session.add(study)
        pacs_db.session.commit()
        print(f"Study saved with ID: {study.id}")
        
        for file in files:
            if file and file.filename:
                filename = file.filename
                print(f"Processing file: {filename}")
                
                if any(filename.endswith(ext) for ext in ALLOWED_EXTENSIONS):
                    try:
                        # Read the file data
                        file_data = file.read()
                        
                        # Compress the DICOM data
                        print("Starting DICOM compression")
                        compression_result = compress_dicom(file_data)
                        print(f"Compression completed with ratio: {compression_result['compression_ratio']}%")
                        
                        # Create image record
                        image = DicomImage()
                        image.study_id = study.id
                        image.compressed_data = compression_result['compressed_data']
                        image.sop_instance_uid = f"{study.study_uid}.{uuid.uuid4()}"
                        
                        # Set compression info
                        image.compression_method = 'COMPACT'
                        image.original_size = compression_result['original_size']
                        image.compressed_size = compression_result['compressed_size']
                        image.compression_ratio = compression_result['compression_ratio']
                        image.compression_date = datetime.now().date()
                        image.compression_time = datetime.now().time()
                        
                        # Set DICOM metadata
                        metadata = compression_result['metadata']
                        image.rows = metadata['rows']
                        image.columns = metadata['columns']
                        image.samples_per_pixel = metadata['samples_per_pixel']
                        image.photometric_interpretation = metadata['photometric_interpretation']
                        image.bits_allocated = metadata['bits_allocated']
                        image.bits_stored = metadata['bits_stored']
                        image.high_bit = metadata['high_bit']
                        
                        pacs_db.session.add(image)
                        print(f"Image record created for {filename}")
                        
                    except Exception as e:
                        print(f"Error processing file {filename}: {str(e)}")
                        print(f"Error type: {type(e)}")
                        import traceback
                        print(f"Traceback: {traceback.format_exc()}")
                        continue
                else:
                    print(f"Invalid file type: {filename}")
                    flash(f'Invalid file type: {filename}. Only .dcm files are allowed.', 'error')
        
        pacs_db.session.commit()
        flash('Study added successfully', 'success')
        print("Study and images saved successfully")
        
    except Exception as e:
        print(f"Error adding study: {str(e)}")
        print(f"Error type: {type(e)}")
        import traceback
        print(f"Traceback: {traceback.format_exc()}")
        pacs_db.session.rollback()
        flash(f'Error adding study: {str(e)}', 'error')
    
    return redirect(url_for('studies'))

@app.route('/studies/<int:study_id>', methods=['DELETE'])
@login_required
def delete_study(study_id):
    try:
        study = ImagingStudy.query.get_or_404(study_id)
        
        # Delete associated image files
        for image in study.images:
            try:
                os.remove(image.file_path)
            except OSError:
                pass  # File might not exist
        
        pacs_db.session.delete(study)
        pacs_db.session.commit()
        return jsonify({'success': True})
    except Exception as e:
        pacs_db.session.rollback()
        return jsonify({'success': False, 'error': str(e)})

@app.route('/studies/<int:study_id>/view')
@login_required
def view_study(study_id):
    study = ImagingStudy.query.get_or_404(study_id)
    return render_template('view_study.html', study=study)

@app.route('/image/<int:image_id>')
@login_required
def serve_image(image_id):
    image = DicomImage.query.get_or_404(image_id)
    
    try:
        # Decompress the image data
        pixel_array, metadata = decompress_dicom(image.compressed_data)
        
        # Normalize pixel values to 0-255
        pixel_min = pixel_array.min()
        pixel_max = pixel_array.max()
        if pixel_min != pixel_max:
            scaled_array = ((pixel_array - pixel_min) / (pixel_max - pixel_min) * 255).astype(np.uint8)
        else:
            scaled_array = np.zeros_like(pixel_array, dtype=np.uint8)
        
        # Convert to PIL Image
        img = Image.fromarray(scaled_array)
        
        # Convert to RGB if grayscale
        if img.mode != 'RGB':
            img = img.convert('RGB')
        
        # Save to bytes
        img_byte_arr = io.BytesIO()
        img.save(img_byte_arr, format='JPEG', quality=90)
        img_byte_arr.seek(0)
        
        return send_file(
            img_byte_arr,
            mimetype='image/jpeg',
            as_attachment=False
        )
    except Exception as e:
        print(f"Error serving image {image_id}: {str(e)}")
        return jsonify({'error': 'Error loading image'}), 500

@app.route('/upload', methods=['GET', 'POST'])
@login_required
def upload_images():
    print(f"Received {request.method} request to /upload")
    if request.method == 'GET':
        try:
            # Use the test template for now
            return render_template('upload_test.html')
        except Exception as e:
            print(f"Error loading upload page: {str(e)}")
            flash('Error loading upload page', 'error')
            return redirect(url_for('dashboard'))
    
    try:
        print("Starting file upload POST process")
        
        # Check for the test file
        if 'test_file' not in request.files:
            print("No test_file in request.files")
            # If not the test file, continue with normal processing
            pass # Keep the rest of the upload_images function for now
            
        else:
            # Process the test file
            file = request.files['test_file']
            if file and file.filename:
                filename = file.filename
                print(f"Processing test file: {filename}")
                # You can add a simple save or print here to confirm file reception
                
                flash(f'Test file {filename} received successfully', 'success')
                return redirect(url_for('upload_images'))
            else:
                 print("Test file is empty or has no filename")
                 flash('No test file selected or file is empty', 'error')
                 return redirect(url_for('upload_images'))

        # The rest of the original upload logic follows here...
        # Validate required fields (adjust if needed for test)
        if 'patient_id' not in request.form:
            raise ValueError("Patient ID is required")
        if 'study_date' not in request.form:
            raise ValueError("Study date is required")
        if 'modality' not in request.form:
            raise ValueError("Modality is required")
        
        print("Form data validated")

        if 'dicom_files' not in request.files:
            print("No dicom_files in request.files")
            raise ValueError("No files selected")
            
        files = request.files.getlist('dicom_files')
        
        print(f"Found {len(files)} files in request.files")

        if not files or not files[0].filename:
            print("File list is empty or first file has no filename")
            raise ValueError("No files selected")
            
        print(f"Processing {len(files)} files")
        
        # Create new study
        study = ImagingStudy()
        study.patient_id = int(request.form['patient_id'])
        study.study_date = datetime.strptime(request.form['study_date'], '%Y-%m-%dT%H:%M')
        study.modality = request.form['modality']
        study.study_description = request.form.get('study_description', '')
        study.referring_physician = request.form.get('referring_physician', '')
        study.study_uid = f"{study.patient_id}.{uuid.uuid4()}"
        
        print(f"Created study with UID: {study.study_uid}")
        
        # Save study first to get its ID
        pacs_db.session.add(study)
        pacs_db.session.commit()
        
        compression_stats = []
        
        # Handle DICOM files
        for file in files:
            if file and file.filename:
                filename = file.filename
                print(f"Processing file: {filename}")
                
                if any(filename.endswith(ext) for ext in ALLOWED_EXTENSIONS):
                    try:
                        # Generate unique filenames
                        safe_filename = secure_filename(filename)
                        unique_id = str(uuid.uuid4())
                        original_path = os.path.join(app.config['UPLOAD_FOLDER'], f"original_{unique_id}_{safe_filename}")
                        compressed_path = os.path.join(app.config['UPLOAD_FOLDER'], f"compressed_{unique_id}_{safe_filename}")
                        
                        print(f"Saving original file to: {original_path}")
                        # Save original file
                        file.save(original_path)
                        
                        print("Compressing DICOM file")
                        # Compress the DICOM file
                        compression_result = compress_dicom(original_path, compressed_path)
                        
                        print("Creating image record")
                        # Create image record
                        image = DicomImage()
                        image.study_id = study.id
                        image.file_path = compression_result['compressed_path']
                        image.original_file_path = original_path
                        image.sop_instance_uid = f"{study.study_uid}.{uuid.uuid4()}"
                        
                        # Set compression info
                        image.compression_method = 'COMPACT'
                        image.original_size = compression_result['original_size']
                        image.compressed_size = compression_result['compressed_size']
                        image.compression_ratio = (image.original_size - image.compressed_size) / image.original_size * 100
                        image.compression_date = datetime.now().date()
                        image.compression_time = datetime.now().time()
                        
                        # Read DICOM metadata
                        ds = pydicom.dcmread(original_path)
                        image.series_number = getattr(ds, 'SeriesNumber', None)
                        image.instance_number = getattr(ds, 'InstanceNumber', None)
                        image.image_type = getattr(ds, 'ImageType', None)
                        image.acquisition_date = getattr(ds, 'AcquisitionDate', None)
                        
                        pacs_db.session.add(image)
                        
                        # Add compression stats
                        compression_stats.append({
                            'filename': filename,
                            'original_size': round(image.original_size / 1024, 2),  # Convert to KB
                            'compressed_size': round(image.compressed_size / 1024, 2),  # Convert to KB
                            'compression_ratio': round(image.compression_ratio, 2) +
                            '%'
                        })
                        
                        print(f"Successfully processed file: {filename}")
                        
                    except Exception as e:
                        print(f"Error processing file {filename}: {str(e)}")
                        print(f"Error type: {type(e)}")
                        import traceback
                        print(f"Traceback: {traceback.format_exc()}")
                        # Clean up any temporary files
                        cleanup_temp_files([original_path, compressed_path])
                        continue # Continue to next file even if one fails
                else:
                    print(f"Invalid file type: {filename}")
                    flash(f'Invalid file type: {filename}. Only .dcm files are allowed.', 'error')
        
        pacs_db.session.commit()
        flash('Images uploaded successfully', 'success')
        
        # Show compression stats
        patients = Patient.query.all()
        return render_template('upload.html', 
                             patients=patients,
                             compression_stats=compression_stats)
        
    except Exception as e:
        print(f"Upload error: {str(e)}")
        print(f"Error type: {type(e)}")
        import traceback
        print(f"Traceback: {traceback.format_exc()}")
        pacs_db.session.rollback()
        flash(f'Error uploading images: {str(e)}', 'error')
        return redirect(url_for('upload_images'))

def fix_gender_values():
    """Fix gender values in the database"""
    with app.app_context():
        patients = Patient.query.all()
        for patient in patients:
            try:
                if isinstance(patient.gender, str):
                    patient.gender = Gender.from_string(patient.gender)
                elif patient.gender is None:
                    patient.gender = Gender.O  # Default to Other if None
            except Exception as e:
                print(f"Error fixing gender for patient {patient.id}: {str(e)}")
                patient.gender = Gender.O  # Default to Other on error
        try:
            pacs_db.session.commit()
        except Exception as e:
            print(f"Error committing changes: {str(e)}")
            pacs_db.session.rollback()

def create_default_practitioner():
    """Create a default practitioner if none exists"""
    with app.app_context():
        if Practitioner.query.count() == 0:
            try:
                default_practitioner = Practitioner()
                default_practitioner.name = "Admin"
                default_practitioner.email = "admin@example.com"
                default_practitioner.password = generate_password_hash("admin123")
                default_practitioner.contact_number = "1234567890"
                
                pacs_db.session.add(default_practitioner)
                pacs_db.session.commit()
                print("Default practitioner created successfully")
            except Exception as e:
                print(f"Error creating default practitioner: {str(e)}")
                pacs_db.session.rollback()

# Call the function to fix gender values
# fix_gender_values()

# Create default practitioner if none exists
create_default_practitioner()

@app.route('/api/patients', methods=['GET'])
def get_all_patients():
    patients = Patient.query.all()
    return jsonify([{
        "id": patient.id,
        "mrn": patient.mrn,  # use 'mrn' instead of 'identifier'
        "name": patient.first_name
    } for patient in patients])


@app.route('/by-patient/<string:mrn>', methods=['GET'])
def get_studies_for_patient(mrn):
    patient = Patient.query.filter_by(mrn=mrn).first()
    if not patient:
        return jsonify([]), 200

    studies = ImagingStudy.query.filter_by(patient_id=patient.id).all()

    results = []
    for study in studies:
        images = DicomImage.query.filter_by(study_id=study.id).all()
        results.append({
            "study": {
                "study_uid": study.study_uid,
                "modality": study.modality,
                "description": study.study_description,
                "study_date": study.study_date.isoformat() if study.study_date else None
            },
            "images": [
                {
                    "sop_instance_uid": img.sop_instance_uid,
                    "url": f"{PACS_API}/image/{img.id}"  # assuming PACS serves images via URL
                }
                for img in images
            ]
        })

    return jsonify(results), 200


# Create database tables and default practitioner
with app.app_context():
    pacs_db.create_all()
    create_default_practitioner()

if __name__ == '__main__':
    app.run(debug=True, port=5001)