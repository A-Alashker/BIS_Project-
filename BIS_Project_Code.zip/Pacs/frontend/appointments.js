async function fetchAppointments() {
    const response = await fetch('/api/appointments', {
        method: 'GET',
        headers: {
            'Authorization': 'Basic ' + btoa(localStorage.getItem('username') + ':' + localStorage.getItem('password'))
        }
    });
    if (response.ok) {
        const appointments = await response.json();
        const tbody = document.querySelector('#appointmentsTable tbody');
        tbody.innerHTML = '';
        appointments.forEach(app => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${app.id}</td>
                <td>${app.patient_id}</td>
                <td>${app.study_id || ''}</td>
                <td>${app.appointment_date || ''}</td>
                <td>${app.duration_minutes}</td>
                <td>${app.status}</td>
                <td>${app.notes || ''}</td>
            `;
            tbody.appendChild(tr);
        });
    } else {
        alert('Failed to fetch appointments');
    }
}

document.getElementById('addAppointmentForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const patient_id = parseInt(document.getElementById('patient_id').value);
    const study_id = document.getElementById('study_id').value ? parseInt(document.getElementById('study_id').value) : null;
    const appointment_date = document.getElementById('appointment_date').value;
    const duration_minutes = document.getElementById('duration_minutes').value ? parseInt(document.getElementById('duration_minutes').value) : 30;
    const status = document.getElementById('status').value;
    const notes = document.getElementById('notes').value.trim();
    const appointmentMessage = document.getElementById('appointmentMessage');
    appointmentMessage.textContent = '';

    if (!patient_id || !appointment_date || !status) {
        appointmentMessage.textContent = 'Please fill in all required fields.';
        return;
    }

    try {
        const response = await fetch('/api/appointments', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Basic ' + btoa(localStorage.getItem('username') + ':' + localStorage.getItem('password'))
            },
            body: JSON.stringify({ patient_id, study_id, appointment_date, duration_minutes, status, notes })
        });
        if (response.ok) {
            appointmentMessage.textContent = 'Appointment added successfully.';
            fetchAppointments();
            this.reset();
        } else {
            const errorData = await response.json();
            appointmentMessage.textContent = 'Error: ' + (errorData.error || 'Failed to add appointment.');
        }
    } catch (error) {
        appointmentMessage.textContent = 'Error connecting to server.';
    }
});

window.onload = function() {
    fetchAppointments();
};
