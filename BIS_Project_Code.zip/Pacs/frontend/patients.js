async function fetchPatients() {
    const response = await fetch('/api/patients', {
        method: 'GET',
        headers: {
            'Authorization': 'Basic ' + btoa(localStorage.getItem('username') + ':' + localStorage.getItem('password'))
        }
    });
    if (response.ok) {
        const patients = await response.json();
        const patientsList = document.getElementById('patientsList');
        patientsList.innerHTML = '';
        patients.forEach(patient => {
            const patientCard = document.createElement('a');
            patientCard.href = `patient_profile.html?mrn=${encodeURIComponent(patient.mrn)}`;
            patientCard.className = 'block bg-gray-800 rounded-lg shadow-lg p-6 flex flex-col hover:bg-gray-700 transition';
            patientCard.setAttribute('data-first-name', patient.first_name);
            patientCard.setAttribute('data-last-name', patient.last_name);
            patientCard.setAttribute('data-mrn', patient.mrn);
            patientCard.innerHTML = `
                <img alt="Patient image" class="rounded-lg mb-4 object-cover h-48 w-full" src="${patient.image_url || 'https://via.placeholder.com/400x250?text=No+Image'}" />
                <h3 class="text-xl font-semibold mb-1">MRN: ${patient.mrn}</h3>
                <p class="mb-1"><span class="font-semibold">Name:</span> ${patient.first_name} ${patient.last_name}</p>
                <p class="mb-1"><span class="font-semibold">DOB:</span> ${patient.dob}</p>
                <p class="mb-1"><span class="font-semibold">Gender:</span> ${patient.gender || ''}</p>
                <p class="mb-1"><span class="font-semibold">Phone:</span> ${patient.phone || ''}</p>
                <p class="mb-1"><span class="font-semibold">Email:</span> ${patient.email || ''}</p>
                <p class="mb-1"><span class="font-semibold">Address:</span> ${patient.address || ''}</p>
                <p class="mb-1"><span class="font-semibold">Insurance:</span> ${patient.insurance_provider || ''}</p>
                <p class="mb-1"><span class="font-semibold">Insurance Number:</span> ${patient.insurance_number || ''}</p>
            `;
            patientsList.appendChild(patientCard);
        });
    } else {
        alert('Failed to fetch patients');
    }
}

window.onload = function() {
    fetchPatients();
};
