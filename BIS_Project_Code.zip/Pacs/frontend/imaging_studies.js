async function fetchStudies() {
    const response = await fetch('/api/imaging_studies', {
        method: 'GET',
        headers: {
            'Authorization': 'Basic ' + btoa(localStorage.getItem('username') + ':' + localStorage.getItem('password'))
        }
    });
    if (response.ok) {
        const studies = await response.json();
        const tbody = document.querySelector('#studiesTable tbody');
        tbody.innerHTML = '';
        studies.forEach(study => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${study.id}</td>
                <td>${study.study_uid}</td>
                <td>${study.patient_id}</td>
                <td>${study.study_date || ''}</td>
                <td>${study.modality}</td>
                <td>${study.body_part}</td>
                <td>${study.description || ''}</td>
                <td>${study.referring_physician || ''}</td>
                <td>${study.status}</td>
            `;
            tbody.appendChild(tr);
        });
    } else {
        alert('Failed to fetch imaging studies');
    }
}

document.getElementById('addStudyForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const study_uid = document.getElementById('study_uid').value.trim();
    const patient_id = parseInt(document.getElementById('patient_id').value);
    const study_date = document.getElementById('study_date').value;
    const modality = document.getElementById('modality').value;
    const body_part = document.getElementById('body_part').value.trim();
    const description = document.getElementById('description').value.trim();
    const referring_physician = document.getElementById('referring_physician').value.trim();
    const status = document.getElementById('status').value;
    const studyMessage = document.getElementById('studyMessage');
    studyMessage.textContent = '';

    if (!study_uid || !patient_id || !study_date || !modality || !body_part || !status) {
        studyMessage.textContent = 'Please fill in all required fields.';
        return;
    }

    try {
        const response = await fetch('/api/imaging_studies', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Basic ' + btoa(localStorage.getItem('username') + ':' + localStorage.getItem('password'))
            },
            body: JSON.stringify({ study_uid, patient_id, study_date, modality, body_part, description, referring_physician, status })
        });
        if (response.ok) {
            studyMessage.textContent = 'Imaging study added successfully.';
            fetchStudies();
            this.reset();
        } else {
            const errorData = await response.json();
            studyMessage.textContent = 'Error: ' + (errorData.error || 'Failed to add imaging study.');
        }
    } catch (error) {
        studyMessage.textContent = 'Error connecting to server.';
    }
});

window.onload = function() {
    fetchStudies();
};
