async function fetchReports() {
    const response = await fetch('/api/reports', {
        method: 'GET',
        headers: {
            'Authorization': 'Basic ' + btoa(localStorage.getItem('username') + ':' + localStorage.getItem('password'))
        }
    });
    if (response.ok) {
        const reports = await response.json();
        const tbody = document.querySelector('#reportsTable tbody');
        tbody.innerHTML = '';
        reports.forEach(report => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${report.id}</td>
                <td>${report.study_id}</td>
                <td>${report.radiologist_id}</td>
                <td>${report.report_date || ''}</td>
                <td>${report.findings || ''}</td>
                <td>${report.impression || ''}</td>
                <td>${report.status}</td>
            `;
            tbody.appendChild(tr);
        });
    } else {
        alert('Failed to fetch reports');
    }
}

document.getElementById('addReportForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const study_id = parseInt(document.getElementById('study_id').value);
    const report_date = document.getElementById('report_date').value;
    const findings = document.getElementById('findings').value.trim();
    const impression = document.getElementById('impression').value.trim();
    const status = document.getElementById('status').value;
    const reportMessage = document.getElementById('reportMessage');
    reportMessage.textContent = '';

    if (!study_id || !status) {
        reportMessage.textContent = 'Please fill in all required fields.';
        return;
    }

    try {
        const response = await fetch('/api/reports', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Basic ' + btoa(localStorage.getItem('username') + ':' + localStorage.getItem('password'))
            },
            body: JSON.stringify({ study_id, report_date, findings, impression, status })
        });
        if (response.ok) {
            reportMessage.textContent = 'Report added successfully.';
            fetchReports();
            this.reset();
        } else {
            const errorData = await response.json();
            reportMessage.textContent = 'Error: ' + (errorData.error || 'Failed to add report.');
        }
    } catch (error) {
        reportMessage.textContent = 'Error connecting to server.';
    }
});

window.onload = function() {
    fetchReports();
};
