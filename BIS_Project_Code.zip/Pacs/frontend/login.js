document.getElementById('loginForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    const loginError = document.getElementById('loginError');
    loginError.textContent = '';

    if (!username || !password) {
        loginError.textContent = 'Please enter username and password.';
        return;
    }

    try {
        const response = await fetch('/api/users', {
            method: 'GET',
            headers: {
                'Authorization': 'Basic ' + btoa(username + ':' + password)
            }
        });

        if (response.ok) {
            // Save credentials or token as needed (for demo, just redirect)
            window.location.href = 'dashboard.html';
        } else {
            loginError.textContent = 'Invalid username or password.';
        }
    } catch (error) {
        loginError.textContent = 'Error connecting to server.';
    }
});
