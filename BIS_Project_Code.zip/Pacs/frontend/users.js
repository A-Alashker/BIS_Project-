async function fetchUsers() {
    const response = await fetch('/api/users', {
        method: 'GET',
        headers: {
            'Authorization': 'Basic ' + btoa(localStorage.getItem('username') + ':' + localStorage.getItem('password'))
        }
    });
    if (response.ok) {
        const users = await response.json();
        const tbody = document.querySelector('#usersTable tbody');
        tbody.innerHTML = '';
        users.forEach(user => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${user.id}</td>
                <td>${user.username}</td>
                <td>${user.name}</td>
                <td>${user.email}</td>
                <td>${user.role}</td>
                <td>${user.status}</td>
            `;
            tbody.appendChild(tr);
        });
    } else {
        alert('Failed to fetch users');
    }
}

document.getElementById('addUserForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const role = document.getElementById('role').value;
    const status = document.getElementById('status').value;
    const userMessage = document.getElementById('userMessage');
    userMessage.textContent = '';

    if (!username || !password || !name || !email) {
        userMessage.textContent = 'Please fill in all required fields.';
        return;
    }

    try {
        const response = await fetch('/api/users', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Basic ' + btoa(localStorage.getItem('username') + ':' + localStorage.getItem('password'))
            },
            body: JSON.stringify({ username, password, name, email, role, status })
        });
        if (response.ok) {
            userMessage.textContent = 'User added successfully.';
            fetchUsers();
            this.reset();
        } else {
            const errorData = await response.json();
            userMessage.textContent = 'Error: ' + (errorData.error || 'Failed to add user.');
        }
    } catch (error) {
        userMessage.textContent = 'Error connecting to server.';
    }
});

window.onload = function() {
    fetchUsers();
};
