async function fetchDicomImages() {
    const response = await fetch('/api/dicom_images', {
        method: 'GET',
        headers: {
            'Authorization': 'Basic ' + btoa(localStorage.getItem('username') + ':' + localStorage.getItem('password'))
        }
    });
    if (response.ok) {
        const images = await response.json();
        const tbody = document.querySelector('#dicomTable tbody');
        tbody.innerHTML = '';
        images.forEach(img => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${img.id}</td>
                <td>${img.study_id}</td>
                <td>${img.sop_instance_uid}</td>
                <td>${img.file_path}</td>
                <td>${img.series_number || ''}</td>
                <td>${img.instance_number || ''}</td>
                <td>${img.image_type || ''}</td>
                <td>${img.acquisition_date || ''}</td>
                <td>${img.processed ? 'Yes' : 'No'}</td>
                <td>${img.processing_results || ''}</td>
            `;
            tbody.appendChild(tr);
        });
    } else {
        alert('Failed to fetch DICOM images');
    }
}

document.getElementById('addDicomForm').addEventListener('submit', async function(event) {
    event.preventDefault();
    const study_id = parseInt(document.getElementById('study_id').value);
    const sop_instance_uid = document.getElementById('sop_instance_uid').value.trim();
    const file_path = document.getElementById('file_path').value.trim();
    const series_number = document.getElementById('series_number').value ? parseInt(document.getElementById('series_number').value) : null;
    const instance_number = document.getElementById('instance_number').value ? parseInt(document.getElementById('instance_number').value) : null;
    const image_type = document.getElementById('image_type').value.trim();
    const acquisition_date = document.getElementById('acquisition_date').value;
    const processed = document.getElementById('processed').value === 'true';
    const processing_results = document.getElementById('processing_results').value.trim();
    const dicomMessage = document.getElementById('dicomMessage');
    dicomMessage.textContent = '';

    if (!study_id || !sop_instance_uid || !file_path) {
        dicomMessage.textContent = 'Please fill in all required fields.';
        return;
    }

    try {
        const response = await fetch('/api/dicom_images', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Basic ' + btoa(localStorage.getItem('username') + ':' + localStorage.getItem('password'))
            },
            body: JSON.stringify({ study_id, sop_instance_uid, file_path, series_number, instance_number, image_type, acquisition_date, processed, processing_results })
        });
        if (response.ok) {
            dicomMessage.textContent = 'DICOM image added successfully.';
            fetchDicomImages();
            this.reset();
        } else {
            const errorData = await response.json();
            dicomMessage.textContent = 'Error: ' + (errorData.error || 'Failed to add DICOM image.');
        }
    } catch (error) {
        dicomMessage.textContent = 'Error connecting to server.';
    }
});

window.onload = function() {
    fetchDicomImages();
};
